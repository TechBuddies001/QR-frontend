(function(){const s=document.createElement("link").relList;if(s&&s.supports&&s.supports("modulepreload"))return;for(const f of document.querySelectorAll('link[rel="modulepreload"]'))c(f);new MutationObserver(f=>{for(const p of f)if(p.type==="childList")for(const h of p.addedNodes)h.tagName==="LINK"&&h.rel==="modulepreload"&&c(h)}).observe(document,{childList:!0,subtree:!0});function u(f){const p={};return f.integrity&&(p.integrity=f.integrity),f.referrerPolicy&&(p.referrerPolicy=f.referrerPolicy),f.crossOrigin==="use-credentials"?p.credentials="include":f.crossOrigin==="anonymous"?p.credentials="omit":p.credentials="same-origin",p}function c(f){if(f.ep)return;f.ep=!0;const p=u(f);fetch(f.href,p)}})();function fy(i){return i&&i.__esModule&&Object.prototype.hasOwnProperty.call(i,"default")?i.default:i}var ju={exports:{}},Hl={};var U0;function hy(){if(U0)return Hl;U0=1;var i=Symbol.for("react.transitional.element"),s=Symbol.for("react.fragment");function u(c,f,p){var h=null;if(p!==void 0&&(h=""+p),f.key!==void 0&&(h=""+f.key),"key"in f){p={};for(var v in f)v!=="key"&&(p[v]=f[v])}else p=f;return f=p.ref,{$$typeof:i,type:c,key:h,ref:f!==void 0?f:null,props:p}}return Hl.Fragment=s,Hl.jsx=u,Hl.jsxs=u,Hl}var B0;function py(){return B0||(B0=1,ju.exports=hy()),ju.exports}var l=py(),Su={exports:{}},oe={};var L0;function my(){if(L0)return oe;L0=1;var i=Symbol.for("react.transitional.element"),s=Symbol.for("react.portal"),u=Symbol.for("react.fragment"),c=Symbol.for("react.strict_mode"),f=Symbol.for("react.profiler"),p=Symbol.for("react.consumer"),h=Symbol.for("react.context"),v=Symbol.for("react.forward_ref"),x=Symbol.for("react.suspense"),g=Symbol.for("react.memo"),b=Symbol.for("react.lazy"),y=Symbol.for("react.activity"),k=Symbol.iterator;function D(w){return w===null||typeof w!="object"?null:(w=k&&w[k]||w["@@iterator"],typeof w=="function"?w:null)}var _={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},q=Object.assign,Y={};function U(w,H,W){this.props=w,this.context=H,this.refs=Y,this.updater=W||_}U.prototype.isReactComponent={},U.prototype.setState=function(w,H){if(typeof w!="object"&&typeof w!="function"&&w!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,w,H,"setState")},U.prototype.forceUpdate=function(w){this.updater.enqueueForceUpdate(this,w,"forceUpdate")};function Q(){}Q.prototype=U.prototype;function Z(w,H,W){this.props=w,this.context=H,this.refs=Y,this.updater=W||_}var V=Z.prototype=new Q;V.constructor=Z,q(V,U.prototype),V.isPureReactComponent=!0;var te=Array.isArray;function ee(){}var $={H:null,A:null,T:null,S:null},J=Object.prototype.hasOwnProperty;function he(w,H,W){var F=W.ref;return{$$typeof:i,type:w,key:H,ref:F!==void 0?F:null,props:W}}function Oe(w,H){return he(w.type,H,w.props)}function G(w){return typeof w=="object"&&w!==null&&w.$$typeof===i}function K(w){var H={"=":"=0",":":"=2"};return"$"+w.replace(/[=:]/g,function(W){return H[W]})}var ze=/\/+/g;function Me(w,H){return typeof w=="object"&&w!==null&&w.key!=null?K(""+w.key):H.toString(36)}function be(w){switch(w.status){case"fulfilled":return w.value;case"rejected":throw w.reason;default:switch(typeof w.status=="string"?w.then(ee,ee):(w.status="pending",w.then(function(H){w.status==="pending"&&(w.status="fulfilled",w.value=H)},function(H){w.status==="pending"&&(w.status="rejected",w.reason=H)})),w.status){case"fulfilled":return w.value;case"rejected":throw w.reason}}throw w}function M(w,H,W,F,re){var ce=typeof w;(ce==="undefined"||ce==="boolean")&&(w=null);var ve=!1;if(w===null)ve=!0;else switch(ce){case"bigint":case"string":case"number":ve=!0;break;case"object":switch(w.$$typeof){case i:case s:ve=!0;break;case b:return ve=w._init,M(ve(w._payload),H,W,F,re)}}if(ve)return re=re(w),ve=F===""?"."+Me(w,0):F,te(re)?(W="",ve!=null&&(W=ve.replace(ze,"$&/")+"/"),M(re,H,W,"",function(la){return la})):re!=null&&(G(re)&&(re=Oe(re,W+(re.key==null||w&&w.key===re.key?"":(""+re.key).replace(ze,"$&/")+"/")+ve)),H.push(re)),1;ve=0;var We=F===""?".":F+":";if(te(w))for(var Ne=0;Ne<w.length;Ne++)F=w[Ne],ce=We+Me(F,Ne),ve+=M(F,H,W,ce,re);else if(Ne=D(w),typeof Ne=="function")for(w=Ne.call(w),Ne=0;!(F=w.next()).done;)F=F.value,ce=We+Me(F,Ne++),ve+=M(F,H,W,ce,re);else if(ce==="object"){if(typeof w.then=="function")return M(be(w),H,W,F,re);throw H=String(w),Error("Objects are not valid as a React child (found: "+(H==="[object Object]"?"object with keys {"+Object.keys(w).join(", ")+"}":H)+"). If you meant to render a collection of children, use an array instead.")}return ve}function X(w,H,W){if(w==null)return w;var F=[],re=0;return M(w,F,"","",function(ce){return H.call(W,ce,re++)}),F}function ie(w){if(w._status===-1){var H=w._result;H=H(),H.then(function(W){(w._status===0||w._status===-1)&&(w._status=1,w._result=W)},function(W){(w._status===0||w._status===-1)&&(w._status=2,w._result=W)}),w._status===-1&&(w._status=0,w._result=H)}if(w._status===1)return w._result.default;throw w._result}var fe=typeof reportError=="function"?reportError:function(w){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var H=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof w=="object"&&w!==null&&typeof w.message=="string"?String(w.message):String(w),error:w});if(!window.dispatchEvent(H))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",w);return}console.error(w)},je={map:X,forEach:function(w,H,W){X(w,function(){H.apply(this,arguments)},W)},count:function(w){var H=0;return X(w,function(){H++}),H},toArray:function(w){return X(w,function(H){return H})||[]},only:function(w){if(!G(w))throw Error("React.Children.only expected to receive a single React element child.");return w}};return oe.Activity=y,oe.Children=je,oe.Component=U,oe.Fragment=u,oe.Profiler=f,oe.PureComponent=Z,oe.StrictMode=c,oe.Suspense=x,oe.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=$,oe.__COMPILER_RUNTIME={__proto__:null,c:function(w){return $.H.useMemoCache(w)}},oe.cache=function(w){return function(){return w.apply(null,arguments)}},oe.cacheSignal=function(){return null},oe.cloneElement=function(w,H,W){if(w==null)throw Error("The argument must be a React element, but you passed "+w+".");var F=q({},w.props),re=w.key;if(H!=null)for(ce in H.key!==void 0&&(re=""+H.key),H)!J.call(H,ce)||ce==="key"||ce==="__self"||ce==="__source"||ce==="ref"&&H.ref===void 0||(F[ce]=H[ce]);var ce=arguments.length-2;if(ce===1)F.children=W;else if(1<ce){for(var ve=Array(ce),We=0;We<ce;We++)ve[We]=arguments[We+2];F.children=ve}return he(w.type,re,F)},oe.createContext=function(w){return w={$$typeof:h,_currentValue:w,_currentValue2:w,_threadCount:0,Provider:null,Consumer:null},w.Provider=w,w.Consumer={$$typeof:p,_context:w},w},oe.createElement=function(w,H,W){var F,re={},ce=null;if(H!=null)for(F in H.key!==void 0&&(ce=""+H.key),H)J.call(H,F)&&F!=="key"&&F!=="__self"&&F!=="__source"&&(re[F]=H[F]);var ve=arguments.length-2;if(ve===1)re.children=W;else if(1<ve){for(var We=Array(ve),Ne=0;Ne<ve;Ne++)We[Ne]=arguments[Ne+2];re.children=We}if(w&&w.defaultProps)for(F in ve=w.defaultProps,ve)re[F]===void 0&&(re[F]=ve[F]);return he(w,ce,re)},oe.createRef=function(){return{current:null}},oe.forwardRef=function(w){return{$$typeof:v,render:w}},oe.isValidElement=G,oe.lazy=function(w){return{$$typeof:b,_payload:{_status:-1,_result:w},_init:ie}},oe.memo=function(w,H){return{$$typeof:g,type:w,compare:H===void 0?null:H}},oe.startTransition=function(w){var H=$.T,W={};$.T=W;try{var F=w(),re=$.S;re!==null&&re(W,F),typeof F=="object"&&F!==null&&typeof F.then=="function"&&F.then(ee,fe)}catch(ce){fe(ce)}finally{H!==null&&W.types!==null&&(H.types=W.types),$.T=H}},oe.unstable_useCacheRefresh=function(){return $.H.useCacheRefresh()},oe.use=function(w){return $.H.use(w)},oe.useActionState=function(w,H,W){return $.H.useActionState(w,H,W)},oe.useCallback=function(w,H){return $.H.useCallback(w,H)},oe.useContext=function(w){return $.H.useContext(w)},oe.useDebugValue=function(){},oe.useDeferredValue=function(w,H){return $.H.useDeferredValue(w,H)},oe.useEffect=function(w,H){return $.H.useEffect(w,H)},oe.useEffectEvent=function(w){return $.H.useEffectEvent(w)},oe.useId=function(){return $.H.useId()},oe.useImperativeHandle=function(w,H,W){return $.H.useImperativeHandle(w,H,W)},oe.useInsertionEffect=function(w,H){return $.H.useInsertionEffect(w,H)},oe.useLayoutEffect=function(w,H){return $.H.useLayoutEffect(w,H)},oe.useMemo=function(w,H){return $.H.useMemo(w,H)},oe.useOptimistic=function(w,H){return $.H.useOptimistic(w,H)},oe.useReducer=function(w,H,W){return $.H.useReducer(w,H,W)},oe.useRef=function(w){return $.H.useRef(w)},oe.useState=function(w){return $.H.useState(w)},oe.useSyncExternalStore=function(w,H,W){return $.H.useSyncExternalStore(w,H,W)},oe.useTransition=function(){return $.H.useTransition()},oe.version="19.2.4",oe}var q0;function md(){return q0||(q0=1,Su.exports=my()),Su.exports}var A=md();const Ve=fy(A);var wu={exports:{}},Ul={},Cu={exports:{}},Au={};var Y0;function gy(){return Y0||(Y0=1,(function(i){function s(M,X){var ie=M.length;M.push(X);e:for(;0<ie;){var fe=ie-1>>>1,je=M[fe];if(0<f(je,X))M[fe]=X,M[ie]=je,ie=fe;else break e}}function u(M){return M.length===0?null:M[0]}function c(M){if(M.length===0)return null;var X=M[0],ie=M.pop();if(ie!==X){M[0]=ie;e:for(var fe=0,je=M.length,w=je>>>1;fe<w;){var H=2*(fe+1)-1,W=M[H],F=H+1,re=M[F];if(0>f(W,ie))F<je&&0>f(re,W)?(M[fe]=re,M[F]=ie,fe=F):(M[fe]=W,M[H]=ie,fe=H);else if(F<je&&0>f(re,ie))M[fe]=re,M[F]=ie,fe=F;else break e}}return X}function f(M,X){var ie=M.sortIndex-X.sortIndex;return ie!==0?ie:M.id-X.id}if(i.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var p=performance;i.unstable_now=function(){return p.now()}}else{var h=Date,v=h.now();i.unstable_now=function(){return h.now()-v}}var x=[],g=[],b=1,y=null,k=3,D=!1,_=!1,q=!1,Y=!1,U=typeof setTimeout=="function"?setTimeout:null,Q=typeof clearTimeout=="function"?clearTimeout:null,Z=typeof setImmediate<"u"?setImmediate:null;function V(M){for(var X=u(g);X!==null;){if(X.callback===null)c(g);else if(X.startTime<=M)c(g),X.sortIndex=X.expirationTime,s(x,X);else break;X=u(g)}}function te(M){if(q=!1,V(M),!_)if(u(x)!==null)_=!0,ee||(ee=!0,K());else{var X=u(g);X!==null&&be(te,X.startTime-M)}}var ee=!1,$=-1,J=5,he=-1;function Oe(){return Y?!0:!(i.unstable_now()-he<J)}function G(){if(Y=!1,ee){var M=i.unstable_now();he=M;var X=!0;try{e:{_=!1,q&&(q=!1,Q($),$=-1),D=!0;var ie=k;try{t:{for(V(M),y=u(x);y!==null&&!(y.expirationTime>M&&Oe());){var fe=y.callback;if(typeof fe=="function"){y.callback=null,k=y.priorityLevel;var je=fe(y.expirationTime<=M);if(M=i.unstable_now(),typeof je=="function"){y.callback=je,V(M),X=!0;break t}y===u(x)&&c(x),V(M)}else c(x);y=u(x)}if(y!==null)X=!0;else{var w=u(g);w!==null&&be(te,w.startTime-M),X=!1}}break e}finally{y=null,k=ie,D=!1}X=void 0}}finally{X?K():ee=!1}}}var K;if(typeof Z=="function")K=function(){Z(G)};else if(typeof MessageChannel<"u"){var ze=new MessageChannel,Me=ze.port2;ze.port1.onmessage=G,K=function(){Me.postMessage(null)}}else K=function(){U(G,0)};function be(M,X){$=U(function(){M(i.unstable_now())},X)}i.unstable_IdlePriority=5,i.unstable_ImmediatePriority=1,i.unstable_LowPriority=4,i.unstable_NormalPriority=3,i.unstable_Profiling=null,i.unstable_UserBlockingPriority=2,i.unstable_cancelCallback=function(M){M.callback=null},i.unstable_forceFrameRate=function(M){0>M||125<M?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):J=0<M?Math.floor(1e3/M):5},i.unstable_getCurrentPriorityLevel=function(){return k},i.unstable_next=function(M){switch(k){case 1:case 2:case 3:var X=3;break;default:X=k}var ie=k;k=X;try{return M()}finally{k=ie}},i.unstable_requestPaint=function(){Y=!0},i.unstable_runWithPriority=function(M,X){switch(M){case 1:case 2:case 3:case 4:case 5:break;default:M=3}var ie=k;k=M;try{return X()}finally{k=ie}},i.unstable_scheduleCallback=function(M,X,ie){var fe=i.unstable_now();switch(typeof ie=="object"&&ie!==null?(ie=ie.delay,ie=typeof ie=="number"&&0<ie?fe+ie:fe):ie=fe,M){case 1:var je=-1;break;case 2:je=250;break;case 5:je=1073741823;break;case 4:je=1e4;break;default:je=5e3}return je=ie+je,M={id:b++,callback:X,priorityLevel:M,startTime:ie,expirationTime:je,sortIndex:-1},ie>fe?(M.sortIndex=ie,s(g,M),u(x)===null&&M===u(g)&&(q?(Q($),$=-1):q=!0,be(te,ie-fe))):(M.sortIndex=je,s(x,M),_||D||(_=!0,ee||(ee=!0,K()))),M},i.unstable_shouldYield=Oe,i.unstable_wrapCallback=function(M){var X=k;return function(){var ie=k;k=X;try{return M.apply(this,arguments)}finally{k=ie}}}})(Au)),Au}var $0;function xy(){return $0||($0=1,Cu.exports=gy()),Cu.exports}var zu={exports:{}},ht={};var G0;function yy(){if(G0)return ht;G0=1;var i=md();function s(x){var g="https://react.dev/errors/"+x;if(1<arguments.length){g+="?args[]="+encodeURIComponent(arguments[1]);for(var b=2;b<arguments.length;b++)g+="&args[]="+encodeURIComponent(arguments[b])}return"Minified React error #"+x+"; visit "+g+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function u(){}var c={d:{f:u,r:function(){throw Error(s(522))},D:u,C:u,L:u,m:u,X:u,S:u,M:u},p:0,findDOMNode:null},f=Symbol.for("react.portal");function p(x,g,b){var y=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:f,key:y==null?null:""+y,children:x,containerInfo:g,implementation:b}}var h=i.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function v(x,g){if(x==="font")return"";if(typeof g=="string")return g==="use-credentials"?g:""}return ht.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=c,ht.createPortal=function(x,g){var b=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!g||g.nodeType!==1&&g.nodeType!==9&&g.nodeType!==11)throw Error(s(299));return p(x,g,null,b)},ht.flushSync=function(x){var g=h.T,b=c.p;try{if(h.T=null,c.p=2,x)return x()}finally{h.T=g,c.p=b,c.d.f()}},ht.preconnect=function(x,g){typeof x=="string"&&(g?(g=g.crossOrigin,g=typeof g=="string"?g==="use-credentials"?g:"":void 0):g=null,c.d.C(x,g))},ht.prefetchDNS=function(x){typeof x=="string"&&c.d.D(x)},ht.preinit=function(x,g){if(typeof x=="string"&&g&&typeof g.as=="string"){var b=g.as,y=v(b,g.crossOrigin),k=typeof g.integrity=="string"?g.integrity:void 0,D=typeof g.fetchPriority=="string"?g.fetchPriority:void 0;b==="style"?c.d.S(x,typeof g.precedence=="string"?g.precedence:void 0,{crossOrigin:y,integrity:k,fetchPriority:D}):b==="script"&&c.d.X(x,{crossOrigin:y,integrity:k,fetchPriority:D,nonce:typeof g.nonce=="string"?g.nonce:void 0})}},ht.preinitModule=function(x,g){if(typeof x=="string")if(typeof g=="object"&&g!==null){if(g.as==null||g.as==="script"){var b=v(g.as,g.crossOrigin);c.d.M(x,{crossOrigin:b,integrity:typeof g.integrity=="string"?g.integrity:void 0,nonce:typeof g.nonce=="string"?g.nonce:void 0})}}else g==null&&c.d.M(x)},ht.preload=function(x,g){if(typeof x=="string"&&typeof g=="object"&&g!==null&&typeof g.as=="string"){var b=g.as,y=v(b,g.crossOrigin);c.d.L(x,b,{crossOrigin:y,integrity:typeof g.integrity=="string"?g.integrity:void 0,nonce:typeof g.nonce=="string"?g.nonce:void 0,type:typeof g.type=="string"?g.type:void 0,fetchPriority:typeof g.fetchPriority=="string"?g.fetchPriority:void 0,referrerPolicy:typeof g.referrerPolicy=="string"?g.referrerPolicy:void 0,imageSrcSet:typeof g.imageSrcSet=="string"?g.imageSrcSet:void 0,imageSizes:typeof g.imageSizes=="string"?g.imageSizes:void 0,media:typeof g.media=="string"?g.media:void 0})}},ht.preloadModule=function(x,g){if(typeof x=="string")if(g){var b=v(g.as,g.crossOrigin);c.d.m(x,{as:typeof g.as=="string"&&g.as!=="script"?g.as:void 0,crossOrigin:b,integrity:typeof g.integrity=="string"?g.integrity:void 0})}else c.d.m(x)},ht.requestFormReset=function(x){c.d.r(x)},ht.unstable_batchedUpdates=function(x,g){return x(g)},ht.useFormState=function(x,g,b){return h.H.useFormState(x,g,b)},ht.useFormStatus=function(){return h.H.useHostTransitionStatus()},ht.version="19.2.4",ht}var Q0;function by(){if(Q0)return zu.exports;Q0=1;function i(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(i)}catch(s){console.error(s)}}return i(),zu.exports=yy(),zu.exports}var V0;function vy(){if(V0)return Ul;V0=1;var i=xy(),s=md(),u=by();function c(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var a=2;a<arguments.length;a++)t+="&args[]="+encodeURIComponent(arguments[a])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function f(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function p(e){var t=e,a=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,(t.flags&4098)!==0&&(a=t.return),e=t.return;while(e)}return t.tag===3?a:null}function h(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function v(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function x(e){if(p(e)!==e)throw Error(c(188))}function g(e){var t=e.alternate;if(!t){if(t=p(e),t===null)throw Error(c(188));return t!==e?null:e}for(var a=e,n=t;;){var r=a.return;if(r===null)break;var o=r.alternate;if(o===null){if(n=r.return,n!==null){a=n;continue}break}if(r.child===o.child){for(o=r.child;o;){if(o===a)return x(r),e;if(o===n)return x(r),t;o=o.sibling}throw Error(c(188))}if(a.return!==n.return)a=r,n=o;else{for(var d=!1,m=r.child;m;){if(m===a){d=!0,a=r,n=o;break}if(m===n){d=!0,n=r,a=o;break}m=m.sibling}if(!d){for(m=o.child;m;){if(m===a){d=!0,a=o,n=r;break}if(m===n){d=!0,n=o,a=r;break}m=m.sibling}if(!d)throw Error(c(189))}}if(a.alternate!==n)throw Error(c(190))}if(a.tag!==3)throw Error(c(188));return a.stateNode.current===a?e:t}function b(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=b(e),t!==null)return t;e=e.sibling}return null}var y=Object.assign,k=Symbol.for("react.element"),D=Symbol.for("react.transitional.element"),_=Symbol.for("react.portal"),q=Symbol.for("react.fragment"),Y=Symbol.for("react.strict_mode"),U=Symbol.for("react.profiler"),Q=Symbol.for("react.consumer"),Z=Symbol.for("react.context"),V=Symbol.for("react.forward_ref"),te=Symbol.for("react.suspense"),ee=Symbol.for("react.suspense_list"),$=Symbol.for("react.memo"),J=Symbol.for("react.lazy"),he=Symbol.for("react.activity"),Oe=Symbol.for("react.memo_cache_sentinel"),G=Symbol.iterator;function K(e){return e===null||typeof e!="object"?null:(e=G&&e[G]||e["@@iterator"],typeof e=="function"?e:null)}var ze=Symbol.for("react.client.reference");function Me(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===ze?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case q:return"Fragment";case U:return"Profiler";case Y:return"StrictMode";case te:return"Suspense";case ee:return"SuspenseList";case he:return"Activity"}if(typeof e=="object")switch(e.$$typeof){case _:return"Portal";case Z:return e.displayName||"Context";case Q:return(e._context.displayName||"Context")+".Consumer";case V:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case $:return t=e.displayName||null,t!==null?t:Me(e.type)||"Memo";case J:t=e._payload,e=e._init;try{return Me(e(t))}catch{}}return null}var be=Array.isArray,M=s.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,X=u.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,ie={pending:!1,data:null,method:null,action:null},fe=[],je=-1;function w(e){return{current:e}}function H(e){0>je||(e.current=fe[je],fe[je]=null,je--)}function W(e,t){je++,fe[je]=e.current,e.current=t}var F=w(null),re=w(null),ce=w(null),ve=w(null);function We(e,t){switch(W(ce,t),W(re,e),W(F,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?r0(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=r0(t),e=o0(t,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}H(F),W(F,e)}function Ne(){H(F),H(re),H(ce)}function la(e){e.memoizedState!==null&&W(ve,e);var t=F.current,a=o0(t,e.type);t!==a&&(W(re,e),W(F,a))}function ra(e){re.current===e&&(H(F),H(re)),ve.current===e&&(H(ve),_l._currentValue=ie)}var wt,Gn;function Ot(e){if(wt===void 0)try{throw Error()}catch(a){var t=a.stack.trim().match(/\n( *(at )?)/);wt=t&&t[1]||"",Gn=-1<a.stack.indexOf(`
    at`)?" (<anonymous>)":-1<a.stack.indexOf("@")?"@unknown:0:0":""}return`
`+wt+e+Gn}var oa=!1;function ls(e,t){if(!e||oa)return"";oa=!0;var a=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var n={DetermineComponentFrameRoot:function(){try{if(t){var L=function(){throw Error()};if(Object.defineProperty(L.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(L,[])}catch(R){var N=R}Reflect.construct(e,[],L)}else{try{L.call()}catch(R){N=R}e.call(L.prototype)}}else{try{throw Error()}catch(R){N=R}(L=e())&&typeof L.catch=="function"&&L.catch(function(){})}}catch(R){if(R&&N&&typeof R.stack=="string")return[R.stack,N.stack]}return[null,null]}};n.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var r=Object.getOwnPropertyDescriptor(n.DetermineComponentFrameRoot,"name");r&&r.configurable&&Object.defineProperty(n.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var o=n.DetermineComponentFrameRoot(),d=o[0],m=o[1];if(d&&m){var j=d.split(`
`),T=m.split(`
`);for(r=n=0;n<j.length&&!j[n].includes("DetermineComponentFrameRoot");)n++;for(;r<T.length&&!T[r].includes("DetermineComponentFrameRoot");)r++;if(n===j.length||r===T.length)for(n=j.length-1,r=T.length-1;1<=n&&0<=r&&j[n]!==T[r];)r--;for(;1<=n&&0<=r;n--,r--)if(j[n]!==T[r]){if(n!==1||r!==1)do if(n--,r--,0>r||j[n]!==T[r]){var O=`
`+j[n].replace(" at new "," at ");return e.displayName&&O.includes("<anonymous>")&&(O=O.replace("<anonymous>",e.displayName)),O}while(1<=n&&0<=r);break}}}finally{oa=!1,Error.prepareStackTrace=a}return(a=e?e.displayName||e.name:"")?Ot(a):""}function Gg(e,t){switch(e.tag){case 26:case 27:case 5:return Ot(e.type);case 16:return Ot("Lazy");case 13:return e.child!==t&&t!==null?Ot("Suspense Fallback"):Ot("Suspense");case 19:return Ot("SuspenseList");case 0:case 15:return ls(e.type,!1);case 11:return ls(e.type.render,!1);case 1:return ls(e.type,!0);case 31:return Ot("Activity");default:return""}}function Hd(e){try{var t="",a=null;do t+=Gg(e,a),a=e,e=e.return;while(e);return t}catch(n){return`
Error generating stack: `+n.message+`
`+n.stack}}var rs=Object.prototype.hasOwnProperty,os=i.unstable_scheduleCallback,ss=i.unstable_cancelCallback,Qg=i.unstable_shouldYield,Vg=i.unstable_requestPaint,Ct=i.unstable_now,Xg=i.unstable_getCurrentPriorityLevel,Ud=i.unstable_ImmediatePriority,Bd=i.unstable_UserBlockingPriority,nr=i.unstable_NormalPriority,Kg=i.unstable_LowPriority,Ld=i.unstable_IdlePriority,Zg=i.log,Wg=i.unstable_setDisableYieldValue,Qi=null,At=null;function Ba(e){if(typeof Zg=="function"&&Wg(e),At&&typeof At.setStrictMode=="function")try{At.setStrictMode(Qi,e)}catch{}}var zt=Math.clz32?Math.clz32:Ig,Jg=Math.log,Fg=Math.LN2;function Ig(e){return e>>>=0,e===0?32:31-(Jg(e)/Fg|0)|0}var ir=256,lr=262144,rr=4194304;function yn(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function or(e,t,a){var n=e.pendingLanes;if(n===0)return 0;var r=0,o=e.suspendedLanes,d=e.pingedLanes;e=e.warmLanes;var m=n&134217727;return m!==0?(n=m&~o,n!==0?r=yn(n):(d&=m,d!==0?r=yn(d):a||(a=m&~e,a!==0&&(r=yn(a))))):(m=n&~o,m!==0?r=yn(m):d!==0?r=yn(d):a||(a=n&~e,a!==0&&(r=yn(a)))),r===0?0:t!==0&&t!==r&&(t&o)===0&&(o=r&-r,a=t&-t,o>=a||o===32&&(a&4194048)!==0)?t:r}function Vi(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function Pg(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function qd(){var e=rr;return rr<<=1,(rr&62914560)===0&&(rr=4194304),e}function cs(e){for(var t=[],a=0;31>a;a++)t.push(e);return t}function Xi(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function e1(e,t,a,n,r,o){var d=e.pendingLanes;e.pendingLanes=a,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=a,e.entangledLanes&=a,e.errorRecoveryDisabledLanes&=a,e.shellSuspendCounter=0;var m=e.entanglements,j=e.expirationTimes,T=e.hiddenUpdates;for(a=d&~a;0<a;){var O=31-zt(a),L=1<<O;m[O]=0,j[O]=-1;var N=T[O];if(N!==null)for(T[O]=null,O=0;O<N.length;O++){var R=N[O];R!==null&&(R.lane&=-536870913)}a&=~L}n!==0&&Yd(e,n,0),o!==0&&r===0&&e.tag!==0&&(e.suspendedLanes|=o&~(d&~t))}function Yd(e,t,a){e.pendingLanes|=t,e.suspendedLanes&=~t;var n=31-zt(t);e.entangledLanes|=t,e.entanglements[n]=e.entanglements[n]|1073741824|a&261930}function $d(e,t){var a=e.entangledLanes|=t;for(e=e.entanglements;a;){var n=31-zt(a),r=1<<n;r&t|e[n]&t&&(e[n]|=t),a&=~r}}function Gd(e,t){var a=t&-t;return a=(a&42)!==0?1:us(a),(a&(e.suspendedLanes|t))!==0?0:a}function us(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function ds(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function Qd(){var e=X.p;return e!==0?e:(e=window.event,e===void 0?32:k0(e.type))}function Vd(e,t){var a=X.p;try{return X.p=e,t()}finally{X.p=a}}var La=Math.random().toString(36).slice(2),rt="__reactFiber$"+La,mt="__reactProps$"+La,Qn="__reactContainer$"+La,fs="__reactEvents$"+La,t1="__reactListeners$"+La,a1="__reactHandles$"+La,Xd="__reactResources$"+La,Ki="__reactMarker$"+La;function hs(e){delete e[rt],delete e[mt],delete e[fs],delete e[t1],delete e[a1]}function Vn(e){var t=e[rt];if(t)return t;for(var a=e.parentNode;a;){if(t=a[Qn]||a[rt]){if(a=t.alternate,t.child!==null||a!==null&&a.child!==null)for(e=p0(e);e!==null;){if(a=e[rt])return a;e=p0(e)}return t}e=a,a=e.parentNode}return null}function Xn(e){if(e=e[rt]||e[Qn]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function Zi(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(c(33))}function Kn(e){var t=e[Xd];return t||(t=e[Xd]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function nt(e){e[Ki]=!0}var Kd=new Set,Zd={};function bn(e,t){Zn(e,t),Zn(e+"Capture",t)}function Zn(e,t){for(Zd[e]=t,e=0;e<t.length;e++)Kd.add(t[e])}var n1=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),Wd={},Jd={};function i1(e){return rs.call(Jd,e)?!0:rs.call(Wd,e)?!1:n1.test(e)?Jd[e]=!0:(Wd[e]=!0,!1)}function sr(e,t,a){if(i1(t))if(a===null)e.removeAttribute(t);else{switch(typeof a){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var n=t.toLowerCase().slice(0,5);if(n!=="data-"&&n!=="aria-"){e.removeAttribute(t);return}}e.setAttribute(t,""+a)}}function cr(e,t,a){if(a===null)e.removeAttribute(t);else{switch(typeof a){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,""+a)}}function ha(e,t,a,n){if(n===null)e.removeAttribute(a);else{switch(typeof n){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(a);return}e.setAttributeNS(t,a,""+n)}}function Ht(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Fd(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function l1(e,t,a){var n=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&typeof n<"u"&&typeof n.get=="function"&&typeof n.set=="function"){var r=n.get,o=n.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return r.call(this)},set:function(d){a=""+d,o.call(this,d)}}),Object.defineProperty(e,t,{enumerable:n.enumerable}),{getValue:function(){return a},setValue:function(d){a=""+d},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function ps(e){if(!e._valueTracker){var t=Fd(e)?"checked":"value";e._valueTracker=l1(e,t,""+e[t])}}function Id(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var a=t.getValue(),n="";return e&&(n=Fd(e)?e.checked?"true":"false":e.value),e=n,e!==a?(t.setValue(e),!0):!1}function ur(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}var r1=/[\n"\\]/g;function Ut(e){return e.replace(r1,function(t){return"\\"+t.charCodeAt(0).toString(16)+" "})}function ms(e,t,a,n,r,o,d,m){e.name="",d!=null&&typeof d!="function"&&typeof d!="symbol"&&typeof d!="boolean"?e.type=d:e.removeAttribute("type"),t!=null?d==="number"?(t===0&&e.value===""||e.value!=t)&&(e.value=""+Ht(t)):e.value!==""+Ht(t)&&(e.value=""+Ht(t)):d!=="submit"&&d!=="reset"||e.removeAttribute("value"),t!=null?gs(e,d,Ht(t)):a!=null?gs(e,d,Ht(a)):n!=null&&e.removeAttribute("value"),r==null&&o!=null&&(e.defaultChecked=!!o),r!=null&&(e.checked=r&&typeof r!="function"&&typeof r!="symbol"),m!=null&&typeof m!="function"&&typeof m!="symbol"&&typeof m!="boolean"?e.name=""+Ht(m):e.removeAttribute("name")}function Pd(e,t,a,n,r,o,d,m){if(o!=null&&typeof o!="function"&&typeof o!="symbol"&&typeof o!="boolean"&&(e.type=o),t!=null||a!=null){if(!(o!=="submit"&&o!=="reset"||t!=null)){ps(e);return}a=a!=null?""+Ht(a):"",t=t!=null?""+Ht(t):a,m||t===e.value||(e.value=t),e.defaultValue=t}n=n??r,n=typeof n!="function"&&typeof n!="symbol"&&!!n,e.checked=m?e.checked:!!n,e.defaultChecked=!!n,d!=null&&typeof d!="function"&&typeof d!="symbol"&&typeof d!="boolean"&&(e.name=d),ps(e)}function gs(e,t,a){t==="number"&&ur(e.ownerDocument)===e||e.defaultValue===""+a||(e.defaultValue=""+a)}function Wn(e,t,a,n){if(e=e.options,t){t={};for(var r=0;r<a.length;r++)t["$"+a[r]]=!0;for(a=0;a<e.length;a++)r=t.hasOwnProperty("$"+e[a].value),e[a].selected!==r&&(e[a].selected=r),r&&n&&(e[a].defaultSelected=!0)}else{for(a=""+Ht(a),t=null,r=0;r<e.length;r++){if(e[r].value===a){e[r].selected=!0,n&&(e[r].defaultSelected=!0);return}t!==null||e[r].disabled||(t=e[r])}t!==null&&(t.selected=!0)}}function ef(e,t,a){if(t!=null&&(t=""+Ht(t),t!==e.value&&(e.value=t),a==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=a!=null?""+Ht(a):""}function tf(e,t,a,n){if(t==null){if(n!=null){if(a!=null)throw Error(c(92));if(be(n)){if(1<n.length)throw Error(c(93));n=n[0]}a=n}a==null&&(a=""),t=a}a=Ht(t),e.defaultValue=a,n=e.textContent,n===a&&n!==""&&n!==null&&(e.value=n),ps(e)}function Jn(e,t){if(t){var a=e.firstChild;if(a&&a===e.lastChild&&a.nodeType===3){a.nodeValue=t;return}}e.textContent=t}var o1=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function af(e,t,a){var n=t.indexOf("--")===0;a==null||typeof a=="boolean"||a===""?n?e.setProperty(t,""):t==="float"?e.cssFloat="":e[t]="":n?e.setProperty(t,a):typeof a!="number"||a===0||o1.has(t)?t==="float"?e.cssFloat=a:e[t]=(""+a).trim():e[t]=a+"px"}function nf(e,t,a){if(t!=null&&typeof t!="object")throw Error(c(62));if(e=e.style,a!=null){for(var n in a)!a.hasOwnProperty(n)||t!=null&&t.hasOwnProperty(n)||(n.indexOf("--")===0?e.setProperty(n,""):n==="float"?e.cssFloat="":e[n]="");for(var r in t)n=t[r],t.hasOwnProperty(r)&&a[r]!==n&&af(e,r,n)}else for(var o in t)t.hasOwnProperty(o)&&af(e,o,t[o])}function xs(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var s1=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),c1=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function dr(e){return c1.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function pa(){}var ys=null;function bs(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var Fn=null,In=null;function lf(e){var t=Xn(e);if(t&&(e=t.stateNode)){var a=e[mt]||null;e:switch(e=t.stateNode,t.type){case"input":if(ms(e,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name),t=a.name,a.type==="radio"&&t!=null){for(a=e;a.parentNode;)a=a.parentNode;for(a=a.querySelectorAll('input[name="'+Ut(""+t)+'"][type="radio"]'),t=0;t<a.length;t++){var n=a[t];if(n!==e&&n.form===e.form){var r=n[mt]||null;if(!r)throw Error(c(90));ms(n,r.value,r.defaultValue,r.defaultValue,r.checked,r.defaultChecked,r.type,r.name)}}for(t=0;t<a.length;t++)n=a[t],n.form===e.form&&Id(n)}break e;case"textarea":ef(e,a.value,a.defaultValue);break e;case"select":t=a.value,t!=null&&Wn(e,!!a.multiple,t,!1)}}}var vs=!1;function rf(e,t,a){if(vs)return e(t,a);vs=!0;try{var n=e(t);return n}finally{if(vs=!1,(Fn!==null||In!==null)&&(Ir(),Fn&&(t=Fn,e=In,In=Fn=null,lf(t),e)))for(t=0;t<e.length;t++)lf(e[t])}}function Wi(e,t){var a=e.stateNode;if(a===null)return null;var n=a[mt]||null;if(n===null)return null;a=n[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(n=!n.disabled)||(e=e.type,n=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!n;break e;default:e=!1}if(e)return null;if(a&&typeof a!="function")throw Error(c(231,t,typeof a));return a}var ma=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),js=!1;if(ma)try{var Ji={};Object.defineProperty(Ji,"passive",{get:function(){js=!0}}),window.addEventListener("test",Ji,Ji),window.removeEventListener("test",Ji,Ji)}catch{js=!1}var qa=null,Ss=null,fr=null;function of(){if(fr)return fr;var e,t=Ss,a=t.length,n,r="value"in qa?qa.value:qa.textContent,o=r.length;for(e=0;e<a&&t[e]===r[e];e++);var d=a-e;for(n=1;n<=d&&t[a-n]===r[o-n];n++);return fr=r.slice(e,1<n?1-n:void 0)}function hr(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function pr(){return!0}function sf(){return!1}function gt(e){function t(a,n,r,o,d){this._reactName=a,this._targetInst=r,this.type=n,this.nativeEvent=o,this.target=d,this.currentTarget=null;for(var m in e)e.hasOwnProperty(m)&&(a=e[m],this[m]=a?a(o):o[m]);return this.isDefaultPrevented=(o.defaultPrevented!=null?o.defaultPrevented:o.returnValue===!1)?pr:sf,this.isPropagationStopped=sf,this}return y(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():typeof a.returnValue!="unknown"&&(a.returnValue=!1),this.isDefaultPrevented=pr)},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():typeof a.cancelBubble!="unknown"&&(a.cancelBubble=!0),this.isPropagationStopped=pr)},persist:function(){},isPersistent:pr}),t}var vn={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},mr=gt(vn),Fi=y({},vn,{view:0,detail:0}),u1=gt(Fi),ws,Cs,Ii,gr=y({},Fi,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:zs,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==Ii&&(Ii&&e.type==="mousemove"?(ws=e.screenX-Ii.screenX,Cs=e.screenY-Ii.screenY):Cs=ws=0,Ii=e),ws)},movementY:function(e){return"movementY"in e?e.movementY:Cs}}),cf=gt(gr),d1=y({},gr,{dataTransfer:0}),f1=gt(d1),h1=y({},Fi,{relatedTarget:0}),As=gt(h1),p1=y({},vn,{animationName:0,elapsedTime:0,pseudoElement:0}),m1=gt(p1),g1=y({},vn,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),x1=gt(g1),y1=y({},vn,{data:0}),uf=gt(y1),b1={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},v1={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},j1={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function S1(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=j1[e])?!!t[e]:!1}function zs(){return S1}var w1=y({},Fi,{key:function(e){if(e.key){var t=b1[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=hr(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?v1[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:zs,charCode:function(e){return e.type==="keypress"?hr(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?hr(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),C1=gt(w1),A1=y({},gr,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),df=gt(A1),z1=y({},Fi,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:zs}),E1=gt(z1),T1=y({},vn,{propertyName:0,elapsedTime:0,pseudoElement:0}),N1=gt(T1),k1=y({},gr,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),R1=gt(k1),_1=y({},vn,{newState:0,oldState:0}),M1=gt(_1),D1=[9,13,27,32],Es=ma&&"CompositionEvent"in window,Pi=null;ma&&"documentMode"in document&&(Pi=document.documentMode);var O1=ma&&"TextEvent"in window&&!Pi,ff=ma&&(!Es||Pi&&8<Pi&&11>=Pi),hf=" ",pf=!1;function mf(e,t){switch(e){case"keyup":return D1.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function gf(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var Pn=!1;function H1(e,t){switch(e){case"compositionend":return gf(t);case"keypress":return t.which!==32?null:(pf=!0,hf);case"textInput":return e=t.data,e===hf&&pf?null:e;default:return null}}function U1(e,t){if(Pn)return e==="compositionend"||!Es&&mf(e,t)?(e=of(),fr=Ss=qa=null,Pn=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return ff&&t.locale!=="ko"?null:t.data;default:return null}}var B1={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function xf(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!B1[e.type]:t==="textarea"}function yf(e,t,a,n){Fn?In?In.push(n):In=[n]:Fn=n,t=lo(t,"onChange"),0<t.length&&(a=new mr("onChange","change",null,a,n),e.push({event:a,listeners:t}))}var el=null,tl=null;function L1(e){e0(e,0)}function xr(e){var t=Zi(e);if(Id(t))return e}function bf(e,t){if(e==="change")return t}var vf=!1;if(ma){var Ts;if(ma){var Ns="oninput"in document;if(!Ns){var jf=document.createElement("div");jf.setAttribute("oninput","return;"),Ns=typeof jf.oninput=="function"}Ts=Ns}else Ts=!1;vf=Ts&&(!document.documentMode||9<document.documentMode)}function Sf(){el&&(el.detachEvent("onpropertychange",wf),tl=el=null)}function wf(e){if(e.propertyName==="value"&&xr(tl)){var t=[];yf(t,tl,e,bs(e)),rf(L1,t)}}function q1(e,t,a){e==="focusin"?(Sf(),el=t,tl=a,el.attachEvent("onpropertychange",wf)):e==="focusout"&&Sf()}function Y1(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return xr(tl)}function $1(e,t){if(e==="click")return xr(t)}function G1(e,t){if(e==="input"||e==="change")return xr(t)}function Q1(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var Et=typeof Object.is=="function"?Object.is:Q1;function al(e,t){if(Et(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var a=Object.keys(e),n=Object.keys(t);if(a.length!==n.length)return!1;for(n=0;n<a.length;n++){var r=a[n];if(!rs.call(t,r)||!Et(e[r],t[r]))return!1}return!0}function Cf(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Af(e,t){var a=Cf(e);e=0;for(var n;a;){if(a.nodeType===3){if(n=e+a.textContent.length,e<=t&&n>=t)return{node:a,offset:t-e};e=n}e:{for(;a;){if(a.nextSibling){a=a.nextSibling;break e}a=a.parentNode}a=void 0}a=Cf(a)}}function zf(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?zf(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Ef(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=ur(e.document);t instanceof e.HTMLIFrameElement;){try{var a=typeof t.contentWindow.location.href=="string"}catch{a=!1}if(a)e=t.contentWindow;else break;t=ur(e.document)}return t}function ks(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}var V1=ma&&"documentMode"in document&&11>=document.documentMode,ei=null,Rs=null,nl=null,_s=!1;function Tf(e,t,a){var n=a.window===a?a.document:a.nodeType===9?a:a.ownerDocument;_s||ei==null||ei!==ur(n)||(n=ei,"selectionStart"in n&&ks(n)?n={start:n.selectionStart,end:n.selectionEnd}:(n=(n.ownerDocument&&n.ownerDocument.defaultView||window).getSelection(),n={anchorNode:n.anchorNode,anchorOffset:n.anchorOffset,focusNode:n.focusNode,focusOffset:n.focusOffset}),nl&&al(nl,n)||(nl=n,n=lo(Rs,"onSelect"),0<n.length&&(t=new mr("onSelect","select",null,t,a),e.push({event:t,listeners:n}),t.target=ei)))}function jn(e,t){var a={};return a[e.toLowerCase()]=t.toLowerCase(),a["Webkit"+e]="webkit"+t,a["Moz"+e]="moz"+t,a}var ti={animationend:jn("Animation","AnimationEnd"),animationiteration:jn("Animation","AnimationIteration"),animationstart:jn("Animation","AnimationStart"),transitionrun:jn("Transition","TransitionRun"),transitionstart:jn("Transition","TransitionStart"),transitioncancel:jn("Transition","TransitionCancel"),transitionend:jn("Transition","TransitionEnd")},Ms={},Nf={};ma&&(Nf=document.createElement("div").style,"AnimationEvent"in window||(delete ti.animationend.animation,delete ti.animationiteration.animation,delete ti.animationstart.animation),"TransitionEvent"in window||delete ti.transitionend.transition);function Sn(e){if(Ms[e])return Ms[e];if(!ti[e])return e;var t=ti[e],a;for(a in t)if(t.hasOwnProperty(a)&&a in Nf)return Ms[e]=t[a];return e}var kf=Sn("animationend"),Rf=Sn("animationiteration"),_f=Sn("animationstart"),X1=Sn("transitionrun"),K1=Sn("transitionstart"),Z1=Sn("transitioncancel"),Mf=Sn("transitionend"),Df=new Map,Ds="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");Ds.push("scrollEnd");function Ft(e,t){Df.set(e,t),bn(t,[e])}var yr=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},Bt=[],ai=0,Os=0;function br(){for(var e=ai,t=Os=ai=0;t<e;){var a=Bt[t];Bt[t++]=null;var n=Bt[t];Bt[t++]=null;var r=Bt[t];Bt[t++]=null;var o=Bt[t];if(Bt[t++]=null,n!==null&&r!==null){var d=n.pending;d===null?r.next=r:(r.next=d.next,d.next=r),n.pending=r}o!==0&&Of(a,r,o)}}function vr(e,t,a,n){Bt[ai++]=e,Bt[ai++]=t,Bt[ai++]=a,Bt[ai++]=n,Os|=n,e.lanes|=n,e=e.alternate,e!==null&&(e.lanes|=n)}function Hs(e,t,a,n){return vr(e,t,a,n),jr(e)}function wn(e,t){return vr(e,null,null,t),jr(e)}function Of(e,t,a){e.lanes|=a;var n=e.alternate;n!==null&&(n.lanes|=a);for(var r=!1,o=e.return;o!==null;)o.childLanes|=a,n=o.alternate,n!==null&&(n.childLanes|=a),o.tag===22&&(e=o.stateNode,e===null||e._visibility&1||(r=!0)),e=o,o=o.return;return e.tag===3?(o=e.stateNode,r&&t!==null&&(r=31-zt(a),e=o.hiddenUpdates,n=e[r],n===null?e[r]=[t]:n.push(t),t.lane=a|536870912),o):null}function jr(e){if(50<Al)throw Al=0,Vc=null,Error(c(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var ni={};function W1(e,t,a,n){this.tag=e,this.key=a,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=n,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Tt(e,t,a,n){return new W1(e,t,a,n)}function Us(e){return e=e.prototype,!(!e||!e.isReactComponent)}function ga(e,t){var a=e.alternate;return a===null?(a=Tt(e.tag,t,e.key,e.mode),a.elementType=e.elementType,a.type=e.type,a.stateNode=e.stateNode,a.alternate=e,e.alternate=a):(a.pendingProps=t,a.type=e.type,a.flags=0,a.subtreeFlags=0,a.deletions=null),a.flags=e.flags&65011712,a.childLanes=e.childLanes,a.lanes=e.lanes,a.child=e.child,a.memoizedProps=e.memoizedProps,a.memoizedState=e.memoizedState,a.updateQueue=e.updateQueue,t=e.dependencies,a.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},a.sibling=e.sibling,a.index=e.index,a.ref=e.ref,a.refCleanup=e.refCleanup,a}function Hf(e,t){e.flags&=65011714;var a=e.alternate;return a===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=a.childLanes,e.lanes=a.lanes,e.child=a.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=a.memoizedProps,e.memoizedState=a.memoizedState,e.updateQueue=a.updateQueue,e.type=a.type,t=a.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function Sr(e,t,a,n,r,o){var d=0;if(n=e,typeof e=="function")Us(e)&&(d=1);else if(typeof e=="string")d=ey(e,a,F.current)?26:e==="html"||e==="head"||e==="body"?27:5;else e:switch(e){case he:return e=Tt(31,a,t,r),e.elementType=he,e.lanes=o,e;case q:return Cn(a.children,r,o,t);case Y:d=8,r|=24;break;case U:return e=Tt(12,a,t,r|2),e.elementType=U,e.lanes=o,e;case te:return e=Tt(13,a,t,r),e.elementType=te,e.lanes=o,e;case ee:return e=Tt(19,a,t,r),e.elementType=ee,e.lanes=o,e;default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case Z:d=10;break e;case Q:d=9;break e;case V:d=11;break e;case $:d=14;break e;case J:d=16,n=null;break e}d=29,a=Error(c(130,e===null?"null":typeof e,"")),n=null}return t=Tt(d,a,t,r),t.elementType=e,t.type=n,t.lanes=o,t}function Cn(e,t,a,n){return e=Tt(7,e,n,t),e.lanes=a,e}function Bs(e,t,a){return e=Tt(6,e,null,t),e.lanes=a,e}function Uf(e){var t=Tt(18,null,null,0);return t.stateNode=e,t}function Ls(e,t,a){return t=Tt(4,e.children!==null?e.children:[],e.key,t),t.lanes=a,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var Bf=new WeakMap;function Lt(e,t){if(typeof e=="object"&&e!==null){var a=Bf.get(e);return a!==void 0?a:(t={value:e,source:t,stack:Hd(t)},Bf.set(e,t),t)}return{value:e,source:t,stack:Hd(t)}}var ii=[],li=0,wr=null,il=0,qt=[],Yt=0,Ya=null,sa=1,ca="";function xa(e,t){ii[li++]=il,ii[li++]=wr,wr=e,il=t}function Lf(e,t,a){qt[Yt++]=sa,qt[Yt++]=ca,qt[Yt++]=Ya,Ya=e;var n=sa;e=ca;var r=32-zt(n)-1;n&=~(1<<r),a+=1;var o=32-zt(t)+r;if(30<o){var d=r-r%5;o=(n&(1<<d)-1).toString(32),n>>=d,r-=d,sa=1<<32-zt(t)+r|a<<r|n,ca=o+e}else sa=1<<o|a<<r|n,ca=e}function qs(e){e.return!==null&&(xa(e,1),Lf(e,1,0))}function Ys(e){for(;e===wr;)wr=ii[--li],ii[li]=null,il=ii[--li],ii[li]=null;for(;e===Ya;)Ya=qt[--Yt],qt[Yt]=null,ca=qt[--Yt],qt[Yt]=null,sa=qt[--Yt],qt[Yt]=null}function qf(e,t){qt[Yt++]=sa,qt[Yt++]=ca,qt[Yt++]=Ya,sa=t.id,ca=t.overflow,Ya=e}var ot=null,He=null,ye=!1,$a=null,$t=!1,$s=Error(c(519));function Ga(e){var t=Error(c(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw ll(Lt(t,e)),$s}function Yf(e){var t=e.stateNode,a=e.type,n=e.memoizedProps;switch(t[rt]=e,t[mt]=n,a){case"dialog":me("cancel",t),me("close",t);break;case"iframe":case"object":case"embed":me("load",t);break;case"video":case"audio":for(a=0;a<El.length;a++)me(El[a],t);break;case"source":me("error",t);break;case"img":case"image":case"link":me("error",t),me("load",t);break;case"details":me("toggle",t);break;case"input":me("invalid",t),Pd(t,n.value,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name,!0);break;case"select":me("invalid",t);break;case"textarea":me("invalid",t),tf(t,n.value,n.defaultValue,n.children)}a=n.children,typeof a!="string"&&typeof a!="number"&&typeof a!="bigint"||t.textContent===""+a||n.suppressHydrationWarning===!0||i0(t.textContent,a)?(n.popover!=null&&(me("beforetoggle",t),me("toggle",t)),n.onScroll!=null&&me("scroll",t),n.onScrollEnd!=null&&me("scrollend",t),n.onClick!=null&&(t.onclick=pa),t=!0):t=!1,t||Ga(e,!0)}function $f(e){for(ot=e.return;ot;)switch(ot.tag){case 5:case 31:case 13:$t=!1;return;case 27:case 3:$t=!0;return;default:ot=ot.return}}function ri(e){if(e!==ot)return!1;if(!ye)return $f(e),ye=!0,!1;var t=e.tag,a;if((a=t!==3&&t!==27)&&((a=t===5)&&(a=e.type,a=!(a!=="form"&&a!=="button")||ru(e.type,e.memoizedProps)),a=!a),a&&He&&Ga(e),$f(e),t===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(c(317));He=h0(e)}else if(t===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(c(317));He=h0(e)}else t===27?(t=He,nn(e.type)?(e=du,du=null,He=e):He=t):He=ot?Qt(e.stateNode.nextSibling):null;return!0}function An(){He=ot=null,ye=!1}function Gs(){var e=$a;return e!==null&&(vt===null?vt=e:vt.push.apply(vt,e),$a=null),e}function ll(e){$a===null?$a=[e]:$a.push(e)}var Qs=w(null),zn=null,ya=null;function Qa(e,t,a){W(Qs,t._currentValue),t._currentValue=a}function ba(e){e._currentValue=Qs.current,H(Qs)}function Vs(e,t,a){for(;e!==null;){var n=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,n!==null&&(n.childLanes|=t)):n!==null&&(n.childLanes&t)!==t&&(n.childLanes|=t),e===a)break;e=e.return}}function Xs(e,t,a,n){var r=e.child;for(r!==null&&(r.return=e);r!==null;){var o=r.dependencies;if(o!==null){var d=r.child;o=o.firstContext;e:for(;o!==null;){var m=o;o=r;for(var j=0;j<t.length;j++)if(m.context===t[j]){o.lanes|=a,m=o.alternate,m!==null&&(m.lanes|=a),Vs(o.return,a,e),n||(d=null);break e}o=m.next}}else if(r.tag===18){if(d=r.return,d===null)throw Error(c(341));d.lanes|=a,o=d.alternate,o!==null&&(o.lanes|=a),Vs(d,a,e),d=null}else d=r.child;if(d!==null)d.return=r;else for(d=r;d!==null;){if(d===e){d=null;break}if(r=d.sibling,r!==null){r.return=d.return,d=r;break}d=d.return}r=d}}function oi(e,t,a,n){e=null;for(var r=t,o=!1;r!==null;){if(!o){if((r.flags&524288)!==0)o=!0;else if((r.flags&262144)!==0)break}if(r.tag===10){var d=r.alternate;if(d===null)throw Error(c(387));if(d=d.memoizedProps,d!==null){var m=r.type;Et(r.pendingProps.value,d.value)||(e!==null?e.push(m):e=[m])}}else if(r===ve.current){if(d=r.alternate,d===null)throw Error(c(387));d.memoizedState.memoizedState!==r.memoizedState.memoizedState&&(e!==null?e.push(_l):e=[_l])}r=r.return}e!==null&&Xs(t,e,a,n),t.flags|=262144}function Cr(e){for(e=e.firstContext;e!==null;){if(!Et(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function En(e){zn=e,ya=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function st(e){return Gf(zn,e)}function Ar(e,t){return zn===null&&En(e),Gf(e,t)}function Gf(e,t){var a=t._currentValue;if(t={context:t,memoizedValue:a,next:null},ya===null){if(e===null)throw Error(c(308));ya=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else ya=ya.next=t;return a}var J1=typeof AbortController<"u"?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(a,n){e.push(n)}};this.abort=function(){t.aborted=!0,e.forEach(function(a){return a()})}},F1=i.unstable_scheduleCallback,I1=i.unstable_NormalPriority,Je={$$typeof:Z,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Ks(){return{controller:new J1,data:new Map,refCount:0}}function rl(e){e.refCount--,e.refCount===0&&F1(I1,function(){e.controller.abort()})}var ol=null,Zs=0,si=0,ci=null;function P1(e,t){if(ol===null){var a=ol=[];Zs=0,si=Fc(),ci={status:"pending",value:void 0,then:function(n){a.push(n)}}}return Zs++,t.then(Qf,Qf),t}function Qf(){if(--Zs===0&&ol!==null){ci!==null&&(ci.status="fulfilled");var e=ol;ol=null,si=0,ci=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function ex(e,t){var a=[],n={status:"pending",value:null,reason:null,then:function(r){a.push(r)}};return e.then(function(){n.status="fulfilled",n.value=t;for(var r=0;r<a.length;r++)(0,a[r])(t)},function(r){for(n.status="rejected",n.reason=r,r=0;r<a.length;r++)(0,a[r])(void 0)}),n}var Vf=M.S;M.S=function(e,t){Tp=Ct(),typeof t=="object"&&t!==null&&typeof t.then=="function"&&P1(e,t),Vf!==null&&Vf(e,t)};var Tn=w(null);function Ws(){var e=Tn.current;return e!==null?e:De.pooledCache}function zr(e,t){t===null?W(Tn,Tn.current):W(Tn,t.pool)}function Xf(){var e=Ws();return e===null?null:{parent:Je._currentValue,pool:e}}var ui=Error(c(460)),Js=Error(c(474)),Er=Error(c(542)),Tr={then:function(){}};function Kf(e){return e=e.status,e==="fulfilled"||e==="rejected"}function Zf(e,t,a){switch(a=e[a],a===void 0?e.push(t):a!==t&&(t.then(pa,pa),t=a),t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,Jf(e),e;default:if(typeof t.status=="string")t.then(pa,pa);else{if(e=De,e!==null&&100<e.shellSuspendCounter)throw Error(c(482));e=t,e.status="pending",e.then(function(n){if(t.status==="pending"){var r=t;r.status="fulfilled",r.value=n}},function(n){if(t.status==="pending"){var r=t;r.status="rejected",r.reason=n}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,Jf(e),e}throw kn=t,ui}}function Nn(e){try{var t=e._init;return t(e._payload)}catch(a){throw a!==null&&typeof a=="object"&&typeof a.then=="function"?(kn=a,ui):a}}var kn=null;function Wf(){if(kn===null)throw Error(c(459));var e=kn;return kn=null,e}function Jf(e){if(e===ui||e===Er)throw Error(c(483))}var di=null,sl=0;function Nr(e){var t=sl;return sl+=1,di===null&&(di=[]),Zf(di,e,t)}function cl(e,t){t=t.props.ref,e.ref=t!==void 0?t:null}function kr(e,t){throw t.$$typeof===k?Error(c(525)):(e=Object.prototype.toString.call(t),Error(c(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)))}function Ff(e){function t(z,S){if(e){var E=z.deletions;E===null?(z.deletions=[S],z.flags|=16):E.push(S)}}function a(z,S){if(!e)return null;for(;S!==null;)t(z,S),S=S.sibling;return null}function n(z){for(var S=new Map;z!==null;)z.key!==null?S.set(z.key,z):S.set(z.index,z),z=z.sibling;return S}function r(z,S){return z=ga(z,S),z.index=0,z.sibling=null,z}function o(z,S,E){return z.index=E,e?(E=z.alternate,E!==null?(E=E.index,E<S?(z.flags|=67108866,S):E):(z.flags|=67108866,S)):(z.flags|=1048576,S)}function d(z){return e&&z.alternate===null&&(z.flags|=67108866),z}function m(z,S,E,B){return S===null||S.tag!==6?(S=Bs(E,z.mode,B),S.return=z,S):(S=r(S,E),S.return=z,S)}function j(z,S,E,B){var ne=E.type;return ne===q?O(z,S,E.props.children,B,E.key):S!==null&&(S.elementType===ne||typeof ne=="object"&&ne!==null&&ne.$$typeof===J&&Nn(ne)===S.type)?(S=r(S,E.props),cl(S,E),S.return=z,S):(S=Sr(E.type,E.key,E.props,null,z.mode,B),cl(S,E),S.return=z,S)}function T(z,S,E,B){return S===null||S.tag!==4||S.stateNode.containerInfo!==E.containerInfo||S.stateNode.implementation!==E.implementation?(S=Ls(E,z.mode,B),S.return=z,S):(S=r(S,E.children||[]),S.return=z,S)}function O(z,S,E,B,ne){return S===null||S.tag!==7?(S=Cn(E,z.mode,B,ne),S.return=z,S):(S=r(S,E),S.return=z,S)}function L(z,S,E){if(typeof S=="string"&&S!==""||typeof S=="number"||typeof S=="bigint")return S=Bs(""+S,z.mode,E),S.return=z,S;if(typeof S=="object"&&S!==null){switch(S.$$typeof){case D:return E=Sr(S.type,S.key,S.props,null,z.mode,E),cl(E,S),E.return=z,E;case _:return S=Ls(S,z.mode,E),S.return=z,S;case J:return S=Nn(S),L(z,S,E)}if(be(S)||K(S))return S=Cn(S,z.mode,E,null),S.return=z,S;if(typeof S.then=="function")return L(z,Nr(S),E);if(S.$$typeof===Z)return L(z,Ar(z,S),E);kr(z,S)}return null}function N(z,S,E,B){var ne=S!==null?S.key:null;if(typeof E=="string"&&E!==""||typeof E=="number"||typeof E=="bigint")return ne!==null?null:m(z,S,""+E,B);if(typeof E=="object"&&E!==null){switch(E.$$typeof){case D:return E.key===ne?j(z,S,E,B):null;case _:return E.key===ne?T(z,S,E,B):null;case J:return E=Nn(E),N(z,S,E,B)}if(be(E)||K(E))return ne!==null?null:O(z,S,E,B,null);if(typeof E.then=="function")return N(z,S,Nr(E),B);if(E.$$typeof===Z)return N(z,S,Ar(z,E),B);kr(z,E)}return null}function R(z,S,E,B,ne){if(typeof B=="string"&&B!==""||typeof B=="number"||typeof B=="bigint")return z=z.get(E)||null,m(S,z,""+B,ne);if(typeof B=="object"&&B!==null){switch(B.$$typeof){case D:return z=z.get(B.key===null?E:B.key)||null,j(S,z,B,ne);case _:return z=z.get(B.key===null?E:B.key)||null,T(S,z,B,ne);case J:return B=Nn(B),R(z,S,E,B,ne)}if(be(B)||K(B))return z=z.get(E)||null,O(S,z,B,ne,null);if(typeof B.then=="function")return R(z,S,E,Nr(B),ne);if(B.$$typeof===Z)return R(z,S,E,Ar(S,B),ne);kr(S,B)}return null}function P(z,S,E,B){for(var ne=null,Se=null,ae=S,ue=S=0,xe=null;ae!==null&&ue<E.length;ue++){ae.index>ue?(xe=ae,ae=null):xe=ae.sibling;var we=N(z,ae,E[ue],B);if(we===null){ae===null&&(ae=xe);break}e&&ae&&we.alternate===null&&t(z,ae),S=o(we,S,ue),Se===null?ne=we:Se.sibling=we,Se=we,ae=xe}if(ue===E.length)return a(z,ae),ye&&xa(z,ue),ne;if(ae===null){for(;ue<E.length;ue++)ae=L(z,E[ue],B),ae!==null&&(S=o(ae,S,ue),Se===null?ne=ae:Se.sibling=ae,Se=ae);return ye&&xa(z,ue),ne}for(ae=n(ae);ue<E.length;ue++)xe=R(ae,z,ue,E[ue],B),xe!==null&&(e&&xe.alternate!==null&&ae.delete(xe.key===null?ue:xe.key),S=o(xe,S,ue),Se===null?ne=xe:Se.sibling=xe,Se=xe);return e&&ae.forEach(function(cn){return t(z,cn)}),ye&&xa(z,ue),ne}function le(z,S,E,B){if(E==null)throw Error(c(151));for(var ne=null,Se=null,ae=S,ue=S=0,xe=null,we=E.next();ae!==null&&!we.done;ue++,we=E.next()){ae.index>ue?(xe=ae,ae=null):xe=ae.sibling;var cn=N(z,ae,we.value,B);if(cn===null){ae===null&&(ae=xe);break}e&&ae&&cn.alternate===null&&t(z,ae),S=o(cn,S,ue),Se===null?ne=cn:Se.sibling=cn,Se=cn,ae=xe}if(we.done)return a(z,ae),ye&&xa(z,ue),ne;if(ae===null){for(;!we.done;ue++,we=E.next())we=L(z,we.value,B),we!==null&&(S=o(we,S,ue),Se===null?ne=we:Se.sibling=we,Se=we);return ye&&xa(z,ue),ne}for(ae=n(ae);!we.done;ue++,we=E.next())we=R(ae,z,ue,we.value,B),we!==null&&(e&&we.alternate!==null&&ae.delete(we.key===null?ue:we.key),S=o(we,S,ue),Se===null?ne=we:Se.sibling=we,Se=we);return e&&ae.forEach(function(dy){return t(z,dy)}),ye&&xa(z,ue),ne}function _e(z,S,E,B){if(typeof E=="object"&&E!==null&&E.type===q&&E.key===null&&(E=E.props.children),typeof E=="object"&&E!==null){switch(E.$$typeof){case D:e:{for(var ne=E.key;S!==null;){if(S.key===ne){if(ne=E.type,ne===q){if(S.tag===7){a(z,S.sibling),B=r(S,E.props.children),B.return=z,z=B;break e}}else if(S.elementType===ne||typeof ne=="object"&&ne!==null&&ne.$$typeof===J&&Nn(ne)===S.type){a(z,S.sibling),B=r(S,E.props),cl(B,E),B.return=z,z=B;break e}a(z,S);break}else t(z,S);S=S.sibling}E.type===q?(B=Cn(E.props.children,z.mode,B,E.key),B.return=z,z=B):(B=Sr(E.type,E.key,E.props,null,z.mode,B),cl(B,E),B.return=z,z=B)}return d(z);case _:e:{for(ne=E.key;S!==null;){if(S.key===ne)if(S.tag===4&&S.stateNode.containerInfo===E.containerInfo&&S.stateNode.implementation===E.implementation){a(z,S.sibling),B=r(S,E.children||[]),B.return=z,z=B;break e}else{a(z,S);break}else t(z,S);S=S.sibling}B=Ls(E,z.mode,B),B.return=z,z=B}return d(z);case J:return E=Nn(E),_e(z,S,E,B)}if(be(E))return P(z,S,E,B);if(K(E)){if(ne=K(E),typeof ne!="function")throw Error(c(150));return E=ne.call(E),le(z,S,E,B)}if(typeof E.then=="function")return _e(z,S,Nr(E),B);if(E.$$typeof===Z)return _e(z,S,Ar(z,E),B);kr(z,E)}return typeof E=="string"&&E!==""||typeof E=="number"||typeof E=="bigint"?(E=""+E,S!==null&&S.tag===6?(a(z,S.sibling),B=r(S,E),B.return=z,z=B):(a(z,S),B=Bs(E,z.mode,B),B.return=z,z=B),d(z)):a(z,S)}return function(z,S,E,B){try{sl=0;var ne=_e(z,S,E,B);return di=null,ne}catch(ae){if(ae===ui||ae===Er)throw ae;var Se=Tt(29,ae,null,z.mode);return Se.lanes=B,Se.return=z,Se}}}var Rn=Ff(!0),If=Ff(!1),Va=!1;function Fs(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function Is(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function Xa(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function Ka(e,t,a){var n=e.updateQueue;if(n===null)return null;if(n=n.shared,(Ce&2)!==0){var r=n.pending;return r===null?t.next=t:(t.next=r.next,r.next=t),n.pending=t,t=jr(e),Of(e,null,a),t}return vr(e,n,t,a),jr(e)}function ul(e,t,a){if(t=t.updateQueue,t!==null&&(t=t.shared,(a&4194048)!==0)){var n=t.lanes;n&=e.pendingLanes,a|=n,t.lanes=a,$d(e,a)}}function Ps(e,t){var a=e.updateQueue,n=e.alternate;if(n!==null&&(n=n.updateQueue,a===n)){var r=null,o=null;if(a=a.firstBaseUpdate,a!==null){do{var d={lane:a.lane,tag:a.tag,payload:a.payload,callback:null,next:null};o===null?r=o=d:o=o.next=d,a=a.next}while(a!==null);o===null?r=o=t:o=o.next=t}else r=o=t;a={baseState:n.baseState,firstBaseUpdate:r,lastBaseUpdate:o,shared:n.shared,callbacks:n.callbacks},e.updateQueue=a;return}e=a.lastBaseUpdate,e===null?a.firstBaseUpdate=t:e.next=t,a.lastBaseUpdate=t}var ec=!1;function dl(){if(ec){var e=ci;if(e!==null)throw e}}function fl(e,t,a,n){ec=!1;var r=e.updateQueue;Va=!1;var o=r.firstBaseUpdate,d=r.lastBaseUpdate,m=r.shared.pending;if(m!==null){r.shared.pending=null;var j=m,T=j.next;j.next=null,d===null?o=T:d.next=T,d=j;var O=e.alternate;O!==null&&(O=O.updateQueue,m=O.lastBaseUpdate,m!==d&&(m===null?O.firstBaseUpdate=T:m.next=T,O.lastBaseUpdate=j))}if(o!==null){var L=r.baseState;d=0,O=T=j=null,m=o;do{var N=m.lane&-536870913,R=N!==m.lane;if(R?(ge&N)===N:(n&N)===N){N!==0&&N===si&&(ec=!0),O!==null&&(O=O.next={lane:0,tag:m.tag,payload:m.payload,callback:null,next:null});e:{var P=e,le=m;N=t;var _e=a;switch(le.tag){case 1:if(P=le.payload,typeof P=="function"){L=P.call(_e,L,N);break e}L=P;break e;case 3:P.flags=P.flags&-65537|128;case 0:if(P=le.payload,N=typeof P=="function"?P.call(_e,L,N):P,N==null)break e;L=y({},L,N);break e;case 2:Va=!0}}N=m.callback,N!==null&&(e.flags|=64,R&&(e.flags|=8192),R=r.callbacks,R===null?r.callbacks=[N]:R.push(N))}else R={lane:N,tag:m.tag,payload:m.payload,callback:m.callback,next:null},O===null?(T=O=R,j=L):O=O.next=R,d|=N;if(m=m.next,m===null){if(m=r.shared.pending,m===null)break;R=m,m=R.next,R.next=null,r.lastBaseUpdate=R,r.shared.pending=null}}while(!0);O===null&&(j=L),r.baseState=j,r.firstBaseUpdate=T,r.lastBaseUpdate=O,o===null&&(r.shared.lanes=0),Ia|=d,e.lanes=d,e.memoizedState=L}}function Pf(e,t){if(typeof e!="function")throw Error(c(191,e));e.call(t)}function eh(e,t){var a=e.callbacks;if(a!==null)for(e.callbacks=null,e=0;e<a.length;e++)Pf(a[e],t)}var fi=w(null),Rr=w(0);function th(e,t){e=Ta,W(Rr,e),W(fi,t),Ta=e|t.baseLanes}function tc(){W(Rr,Ta),W(fi,fi.current)}function ac(){Ta=Rr.current,H(fi),H(Rr)}var Nt=w(null),Gt=null;function Za(e){var t=e.alternate;W(Xe,Xe.current&1),W(Nt,e),Gt===null&&(t===null||fi.current!==null||t.memoizedState!==null)&&(Gt=e)}function nc(e){W(Xe,Xe.current),W(Nt,e),Gt===null&&(Gt=e)}function ah(e){e.tag===22?(W(Xe,Xe.current),W(Nt,e),Gt===null&&(Gt=e)):Wa()}function Wa(){W(Xe,Xe.current),W(Nt,Nt.current)}function kt(e){H(Nt),Gt===e&&(Gt=null),H(Xe)}var Xe=w(0);function _r(e){for(var t=e;t!==null;){if(t.tag===13){var a=t.memoizedState;if(a!==null&&(a=a.dehydrated,a===null||cu(a)||uu(a)))return t}else if(t.tag===19&&(t.memoizedProps.revealOrder==="forwards"||t.memoizedProps.revealOrder==="backwards"||t.memoizedProps.revealOrder==="unstable_legacy-backwards"||t.memoizedProps.revealOrder==="together")){if((t.flags&128)!==0)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var va=0,se=null,ke=null,Fe=null,Mr=!1,hi=!1,_n=!1,Dr=0,hl=0,pi=null,tx=0;function $e(){throw Error(c(321))}function ic(e,t){if(t===null)return!1;for(var a=0;a<t.length&&a<e.length;a++)if(!Et(e[a],t[a]))return!1;return!0}function lc(e,t,a,n,r,o){return va=o,se=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,M.H=e===null||e.memoizedState===null?Lh:vc,_n=!1,o=a(n,r),_n=!1,hi&&(o=ih(t,a,n,r)),nh(e),o}function nh(e){M.H=gl;var t=ke!==null&&ke.next!==null;if(va=0,Fe=ke=se=null,Mr=!1,hl=0,pi=null,t)throw Error(c(300));e===null||Ie||(e=e.dependencies,e!==null&&Cr(e)&&(Ie=!0))}function ih(e,t,a,n){se=e;var r=0;do{if(hi&&(pi=null),hl=0,hi=!1,25<=r)throw Error(c(301));if(r+=1,Fe=ke=null,e.updateQueue!=null){var o=e.updateQueue;o.lastEffect=null,o.events=null,o.stores=null,o.memoCache!=null&&(o.memoCache.index=0)}M.H=qh,o=t(a,n)}while(hi);return o}function ax(){var e=M.H,t=e.useState()[0];return t=typeof t.then=="function"?pl(t):t,e=e.useState()[0],(ke!==null?ke.memoizedState:null)!==e&&(se.flags|=1024),t}function rc(){var e=Dr!==0;return Dr=0,e}function oc(e,t,a){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~a}function sc(e){if(Mr){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}Mr=!1}va=0,Fe=ke=se=null,hi=!1,hl=Dr=0,pi=null}function pt(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Fe===null?se.memoizedState=Fe=e:Fe=Fe.next=e,Fe}function Ke(){if(ke===null){var e=se.alternate;e=e!==null?e.memoizedState:null}else e=ke.next;var t=Fe===null?se.memoizedState:Fe.next;if(t!==null)Fe=t,ke=e;else{if(e===null)throw se.alternate===null?Error(c(467)):Error(c(310));ke=e,e={memoizedState:ke.memoizedState,baseState:ke.baseState,baseQueue:ke.baseQueue,queue:ke.queue,next:null},Fe===null?se.memoizedState=Fe=e:Fe=Fe.next=e}return Fe}function Or(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function pl(e){var t=hl;return hl+=1,pi===null&&(pi=[]),e=Zf(pi,e,t),t=se,(Fe===null?t.memoizedState:Fe.next)===null&&(t=t.alternate,M.H=t===null||t.memoizedState===null?Lh:vc),e}function Hr(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return pl(e);if(e.$$typeof===Z)return st(e)}throw Error(c(438,String(e)))}function cc(e){var t=null,a=se.updateQueue;if(a!==null&&(t=a.memoCache),t==null){var n=se.alternate;n!==null&&(n=n.updateQueue,n!==null&&(n=n.memoCache,n!=null&&(t={data:n.data.map(function(r){return r.slice()}),index:0})))}if(t==null&&(t={data:[],index:0}),a===null&&(a=Or(),se.updateQueue=a),a.memoCache=t,a=t.data[t.index],a===void 0)for(a=t.data[t.index]=Array(e),n=0;n<e;n++)a[n]=Oe;return t.index++,a}function ja(e,t){return typeof t=="function"?t(e):t}function Ur(e){var t=Ke();return uc(t,ke,e)}function uc(e,t,a){var n=e.queue;if(n===null)throw Error(c(311));n.lastRenderedReducer=a;var r=e.baseQueue,o=n.pending;if(o!==null){if(r!==null){var d=r.next;r.next=o.next,o.next=d}t.baseQueue=r=o,n.pending=null}if(o=e.baseState,r===null)e.memoizedState=o;else{t=r.next;var m=d=null,j=null,T=t,O=!1;do{var L=T.lane&-536870913;if(L!==T.lane?(ge&L)===L:(va&L)===L){var N=T.revertLane;if(N===0)j!==null&&(j=j.next={lane:0,revertLane:0,gesture:null,action:T.action,hasEagerState:T.hasEagerState,eagerState:T.eagerState,next:null}),L===si&&(O=!0);else if((va&N)===N){T=T.next,N===si&&(O=!0);continue}else L={lane:0,revertLane:T.revertLane,gesture:null,action:T.action,hasEagerState:T.hasEagerState,eagerState:T.eagerState,next:null},j===null?(m=j=L,d=o):j=j.next=L,se.lanes|=N,Ia|=N;L=T.action,_n&&a(o,L),o=T.hasEagerState?T.eagerState:a(o,L)}else N={lane:L,revertLane:T.revertLane,gesture:T.gesture,action:T.action,hasEagerState:T.hasEagerState,eagerState:T.eagerState,next:null},j===null?(m=j=N,d=o):j=j.next=N,se.lanes|=L,Ia|=L;T=T.next}while(T!==null&&T!==t);if(j===null?d=o:j.next=m,!Et(o,e.memoizedState)&&(Ie=!0,O&&(a=ci,a!==null)))throw a;e.memoizedState=o,e.baseState=d,e.baseQueue=j,n.lastRenderedState=o}return r===null&&(n.lanes=0),[e.memoizedState,n.dispatch]}function dc(e){var t=Ke(),a=t.queue;if(a===null)throw Error(c(311));a.lastRenderedReducer=e;var n=a.dispatch,r=a.pending,o=t.memoizedState;if(r!==null){a.pending=null;var d=r=r.next;do o=e(o,d.action),d=d.next;while(d!==r);Et(o,t.memoizedState)||(Ie=!0),t.memoizedState=o,t.baseQueue===null&&(t.baseState=o),a.lastRenderedState=o}return[o,n]}function lh(e,t,a){var n=se,r=Ke(),o=ye;if(o){if(a===void 0)throw Error(c(407));a=a()}else a=t();var d=!Et((ke||r).memoizedState,a);if(d&&(r.memoizedState=a,Ie=!0),r=r.queue,pc(sh.bind(null,n,r,e),[e]),r.getSnapshot!==t||d||Fe!==null&&Fe.memoizedState.tag&1){if(n.flags|=2048,mi(9,{destroy:void 0},oh.bind(null,n,r,a,t),null),De===null)throw Error(c(349));o||(va&127)!==0||rh(n,t,a)}return a}function rh(e,t,a){e.flags|=16384,e={getSnapshot:t,value:a},t=se.updateQueue,t===null?(t=Or(),se.updateQueue=t,t.stores=[e]):(a=t.stores,a===null?t.stores=[e]:a.push(e))}function oh(e,t,a,n){t.value=a,t.getSnapshot=n,ch(t)&&uh(e)}function sh(e,t,a){return a(function(){ch(t)&&uh(e)})}function ch(e){var t=e.getSnapshot;e=e.value;try{var a=t();return!Et(e,a)}catch{return!0}}function uh(e){var t=wn(e,2);t!==null&&jt(t,e,2)}function fc(e){var t=pt();if(typeof e=="function"){var a=e;if(e=a(),_n){Ba(!0);try{a()}finally{Ba(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:ja,lastRenderedState:e},t}function dh(e,t,a,n){return e.baseState=a,uc(e,ke,typeof n=="function"?n:ja)}function nx(e,t,a,n,r){if(qr(e))throw Error(c(485));if(e=t.action,e!==null){var o={payload:r,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(d){o.listeners.push(d)}};M.T!==null?a(!0):o.isTransition=!1,n(o),a=t.pending,a===null?(o.next=t.pending=o,fh(t,o)):(o.next=a.next,t.pending=a.next=o)}}function fh(e,t){var a=t.action,n=t.payload,r=e.state;if(t.isTransition){var o=M.T,d={};M.T=d;try{var m=a(r,n),j=M.S;j!==null&&j(d,m),hh(e,t,m)}catch(T){hc(e,t,T)}finally{o!==null&&d.types!==null&&(o.types=d.types),M.T=o}}else try{o=a(r,n),hh(e,t,o)}catch(T){hc(e,t,T)}}function hh(e,t,a){a!==null&&typeof a=="object"&&typeof a.then=="function"?a.then(function(n){ph(e,t,n)},function(n){return hc(e,t,n)}):ph(e,t,a)}function ph(e,t,a){t.status="fulfilled",t.value=a,mh(t),e.state=a,t=e.pending,t!==null&&(a=t.next,a===t?e.pending=null:(a=a.next,t.next=a,fh(e,a)))}function hc(e,t,a){var n=e.pending;if(e.pending=null,n!==null){n=n.next;do t.status="rejected",t.reason=a,mh(t),t=t.next;while(t!==n)}e.action=null}function mh(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function gh(e,t){return t}function xh(e,t){if(ye){var a=De.formState;if(a!==null){e:{var n=se;if(ye){if(He){t:{for(var r=He,o=$t;r.nodeType!==8;){if(!o){r=null;break t}if(r=Qt(r.nextSibling),r===null){r=null;break t}}o=r.data,r=o==="F!"||o==="F"?r:null}if(r){He=Qt(r.nextSibling),n=r.data==="F!";break e}}Ga(n)}n=!1}n&&(t=a[0])}}return a=pt(),a.memoizedState=a.baseState=t,n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:gh,lastRenderedState:t},a.queue=n,a=Hh.bind(null,se,n),n.dispatch=a,n=fc(!1),o=bc.bind(null,se,!1,n.queue),n=pt(),r={state:t,dispatch:null,action:e,pending:null},n.queue=r,a=nx.bind(null,se,r,o,a),r.dispatch=a,n.memoizedState=e,[t,a,!1]}function yh(e){var t=Ke();return bh(t,ke,e)}function bh(e,t,a){if(t=uc(e,t,gh)[0],e=Ur(ja)[0],typeof t=="object"&&t!==null&&typeof t.then=="function")try{var n=pl(t)}catch(d){throw d===ui?Er:d}else n=t;t=Ke();var r=t.queue,o=r.dispatch;return a!==t.memoizedState&&(se.flags|=2048,mi(9,{destroy:void 0},ix.bind(null,r,a),null)),[n,o,e]}function ix(e,t){e.action=t}function vh(e){var t=Ke(),a=ke;if(a!==null)return bh(t,a,e);Ke(),t=t.memoizedState,a=Ke();var n=a.queue.dispatch;return a.memoizedState=e,[t,n,!1]}function mi(e,t,a,n){return e={tag:e,create:a,deps:n,inst:t,next:null},t=se.updateQueue,t===null&&(t=Or(),se.updateQueue=t),a=t.lastEffect,a===null?t.lastEffect=e.next=e:(n=a.next,a.next=e,e.next=n,t.lastEffect=e),e}function jh(){return Ke().memoizedState}function Br(e,t,a,n){var r=pt();se.flags|=e,r.memoizedState=mi(1|t,{destroy:void 0},a,n===void 0?null:n)}function Lr(e,t,a,n){var r=Ke();n=n===void 0?null:n;var o=r.memoizedState.inst;ke!==null&&n!==null&&ic(n,ke.memoizedState.deps)?r.memoizedState=mi(t,o,a,n):(se.flags|=e,r.memoizedState=mi(1|t,o,a,n))}function Sh(e,t){Br(8390656,8,e,t)}function pc(e,t){Lr(2048,8,e,t)}function lx(e){se.flags|=4;var t=se.updateQueue;if(t===null)t=Or(),se.updateQueue=t,t.events=[e];else{var a=t.events;a===null?t.events=[e]:a.push(e)}}function wh(e){var t=Ke().memoizedState;return lx({ref:t,nextImpl:e}),function(){if((Ce&2)!==0)throw Error(c(440));return t.impl.apply(void 0,arguments)}}function Ch(e,t){return Lr(4,2,e,t)}function Ah(e,t){return Lr(4,4,e,t)}function zh(e,t){if(typeof t=="function"){e=e();var a=t(e);return function(){typeof a=="function"?a():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function Eh(e,t,a){a=a!=null?a.concat([e]):null,Lr(4,4,zh.bind(null,t,e),a)}function mc(){}function Th(e,t){var a=Ke();t=t===void 0?null:t;var n=a.memoizedState;return t!==null&&ic(t,n[1])?n[0]:(a.memoizedState=[e,t],e)}function Nh(e,t){var a=Ke();t=t===void 0?null:t;var n=a.memoizedState;if(t!==null&&ic(t,n[1]))return n[0];if(n=e(),_n){Ba(!0);try{e()}finally{Ba(!1)}}return a.memoizedState=[n,t],n}function gc(e,t,a){return a===void 0||(va&1073741824)!==0&&(ge&261930)===0?e.memoizedState=t:(e.memoizedState=a,e=kp(),se.lanes|=e,Ia|=e,a)}function kh(e,t,a,n){return Et(a,t)?a:fi.current!==null?(e=gc(e,a,n),Et(e,t)||(Ie=!0),e):(va&42)===0||(va&1073741824)!==0&&(ge&261930)===0?(Ie=!0,e.memoizedState=a):(e=kp(),se.lanes|=e,Ia|=e,t)}function Rh(e,t,a,n,r){var o=X.p;X.p=o!==0&&8>o?o:8;var d=M.T,m={};M.T=m,bc(e,!1,t,a);try{var j=r(),T=M.S;if(T!==null&&T(m,j),j!==null&&typeof j=="object"&&typeof j.then=="function"){var O=ex(j,n);ml(e,t,O,Mt(e))}else ml(e,t,n,Mt(e))}catch(L){ml(e,t,{then:function(){},status:"rejected",reason:L},Mt())}finally{X.p=o,d!==null&&m.types!==null&&(d.types=m.types),M.T=d}}function rx(){}function xc(e,t,a,n){if(e.tag!==5)throw Error(c(476));var r=_h(e).queue;Rh(e,r,t,ie,a===null?rx:function(){return Mh(e),a(n)})}function _h(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:ie,baseState:ie,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:ja,lastRenderedState:ie},next:null};var a={};return t.next={memoizedState:a,baseState:a,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:ja,lastRenderedState:a},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function Mh(e){var t=_h(e);t.next===null&&(t=e.alternate.memoizedState),ml(e,t.next.queue,{},Mt())}function yc(){return st(_l)}function Dh(){return Ke().memoizedState}function Oh(){return Ke().memoizedState}function ox(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var a=Mt();e=Xa(a);var n=Ka(t,e,a);n!==null&&(jt(n,t,a),ul(n,t,a)),t={cache:Ks()},e.payload=t;return}t=t.return}}function sx(e,t,a){var n=Mt();a={lane:n,revertLane:0,gesture:null,action:a,hasEagerState:!1,eagerState:null,next:null},qr(e)?Uh(t,a):(a=Hs(e,t,a,n),a!==null&&(jt(a,e,n),Bh(a,t,n)))}function Hh(e,t,a){var n=Mt();ml(e,t,a,n)}function ml(e,t,a,n){var r={lane:n,revertLane:0,gesture:null,action:a,hasEagerState:!1,eagerState:null,next:null};if(qr(e))Uh(t,r);else{var o=e.alternate;if(e.lanes===0&&(o===null||o.lanes===0)&&(o=t.lastRenderedReducer,o!==null))try{var d=t.lastRenderedState,m=o(d,a);if(r.hasEagerState=!0,r.eagerState=m,Et(m,d))return vr(e,t,r,0),De===null&&br(),!1}catch{}if(a=Hs(e,t,r,n),a!==null)return jt(a,e,n),Bh(a,t,n),!0}return!1}function bc(e,t,a,n){if(n={lane:2,revertLane:Fc(),gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},qr(e)){if(t)throw Error(c(479))}else t=Hs(e,a,n,2),t!==null&&jt(t,e,2)}function qr(e){var t=e.alternate;return e===se||t!==null&&t===se}function Uh(e,t){hi=Mr=!0;var a=e.pending;a===null?t.next=t:(t.next=a.next,a.next=t),e.pending=t}function Bh(e,t,a){if((a&4194048)!==0){var n=t.lanes;n&=e.pendingLanes,a|=n,t.lanes=a,$d(e,a)}}var gl={readContext:st,use:Hr,useCallback:$e,useContext:$e,useEffect:$e,useImperativeHandle:$e,useLayoutEffect:$e,useInsertionEffect:$e,useMemo:$e,useReducer:$e,useRef:$e,useState:$e,useDebugValue:$e,useDeferredValue:$e,useTransition:$e,useSyncExternalStore:$e,useId:$e,useHostTransitionStatus:$e,useFormState:$e,useActionState:$e,useOptimistic:$e,useMemoCache:$e,useCacheRefresh:$e};gl.useEffectEvent=$e;var Lh={readContext:st,use:Hr,useCallback:function(e,t){return pt().memoizedState=[e,t===void 0?null:t],e},useContext:st,useEffect:Sh,useImperativeHandle:function(e,t,a){a=a!=null?a.concat([e]):null,Br(4194308,4,zh.bind(null,t,e),a)},useLayoutEffect:function(e,t){return Br(4194308,4,e,t)},useInsertionEffect:function(e,t){Br(4,2,e,t)},useMemo:function(e,t){var a=pt();t=t===void 0?null:t;var n=e();if(_n){Ba(!0);try{e()}finally{Ba(!1)}}return a.memoizedState=[n,t],n},useReducer:function(e,t,a){var n=pt();if(a!==void 0){var r=a(t);if(_n){Ba(!0);try{a(t)}finally{Ba(!1)}}}else r=t;return n.memoizedState=n.baseState=r,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:r},n.queue=e,e=e.dispatch=sx.bind(null,se,e),[n.memoizedState,e]},useRef:function(e){var t=pt();return e={current:e},t.memoizedState=e},useState:function(e){e=fc(e);var t=e.queue,a=Hh.bind(null,se,t);return t.dispatch=a,[e.memoizedState,a]},useDebugValue:mc,useDeferredValue:function(e,t){var a=pt();return gc(a,e,t)},useTransition:function(){var e=fc(!1);return e=Rh.bind(null,se,e.queue,!0,!1),pt().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,a){var n=se,r=pt();if(ye){if(a===void 0)throw Error(c(407));a=a()}else{if(a=t(),De===null)throw Error(c(349));(ge&127)!==0||rh(n,t,a)}r.memoizedState=a;var o={value:a,getSnapshot:t};return r.queue=o,Sh(sh.bind(null,n,o,e),[e]),n.flags|=2048,mi(9,{destroy:void 0},oh.bind(null,n,o,a,t),null),a},useId:function(){var e=pt(),t=De.identifierPrefix;if(ye){var a=ca,n=sa;a=(n&~(1<<32-zt(n)-1)).toString(32)+a,t="_"+t+"R_"+a,a=Dr++,0<a&&(t+="H"+a.toString(32)),t+="_"}else a=tx++,t="_"+t+"r_"+a.toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:yc,useFormState:xh,useActionState:xh,useOptimistic:function(e){var t=pt();t.memoizedState=t.baseState=e;var a={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=a,t=bc.bind(null,se,!0,a),a.dispatch=t,[e,t]},useMemoCache:cc,useCacheRefresh:function(){return pt().memoizedState=ox.bind(null,se)},useEffectEvent:function(e){var t=pt(),a={impl:e};return t.memoizedState=a,function(){if((Ce&2)!==0)throw Error(c(440));return a.impl.apply(void 0,arguments)}}},vc={readContext:st,use:Hr,useCallback:Th,useContext:st,useEffect:pc,useImperativeHandle:Eh,useInsertionEffect:Ch,useLayoutEffect:Ah,useMemo:Nh,useReducer:Ur,useRef:jh,useState:function(){return Ur(ja)},useDebugValue:mc,useDeferredValue:function(e,t){var a=Ke();return kh(a,ke.memoizedState,e,t)},useTransition:function(){var e=Ur(ja)[0],t=Ke().memoizedState;return[typeof e=="boolean"?e:pl(e),t]},useSyncExternalStore:lh,useId:Dh,useHostTransitionStatus:yc,useFormState:yh,useActionState:yh,useOptimistic:function(e,t){var a=Ke();return dh(a,ke,e,t)},useMemoCache:cc,useCacheRefresh:Oh};vc.useEffectEvent=wh;var qh={readContext:st,use:Hr,useCallback:Th,useContext:st,useEffect:pc,useImperativeHandle:Eh,useInsertionEffect:Ch,useLayoutEffect:Ah,useMemo:Nh,useReducer:dc,useRef:jh,useState:function(){return dc(ja)},useDebugValue:mc,useDeferredValue:function(e,t){var a=Ke();return ke===null?gc(a,e,t):kh(a,ke.memoizedState,e,t)},useTransition:function(){var e=dc(ja)[0],t=Ke().memoizedState;return[typeof e=="boolean"?e:pl(e),t]},useSyncExternalStore:lh,useId:Dh,useHostTransitionStatus:yc,useFormState:vh,useActionState:vh,useOptimistic:function(e,t){var a=Ke();return ke!==null?dh(a,ke,e,t):(a.baseState=e,[e,a.queue.dispatch])},useMemoCache:cc,useCacheRefresh:Oh};qh.useEffectEvent=wh;function jc(e,t,a,n){t=e.memoizedState,a=a(n,t),a=a==null?t:y({},t,a),e.memoizedState=a,e.lanes===0&&(e.updateQueue.baseState=a)}var Sc={enqueueSetState:function(e,t,a){e=e._reactInternals;var n=Mt(),r=Xa(n);r.payload=t,a!=null&&(r.callback=a),t=Ka(e,r,n),t!==null&&(jt(t,e,n),ul(t,e,n))},enqueueReplaceState:function(e,t,a){e=e._reactInternals;var n=Mt(),r=Xa(n);r.tag=1,r.payload=t,a!=null&&(r.callback=a),t=Ka(e,r,n),t!==null&&(jt(t,e,n),ul(t,e,n))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var a=Mt(),n=Xa(a);n.tag=2,t!=null&&(n.callback=t),t=Ka(e,n,a),t!==null&&(jt(t,e,a),ul(t,e,a))}};function Yh(e,t,a,n,r,o,d){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(n,o,d):t.prototype&&t.prototype.isPureReactComponent?!al(a,n)||!al(r,o):!0}function $h(e,t,a,n){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(a,n),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(a,n),t.state!==e&&Sc.enqueueReplaceState(t,t.state,null)}function Mn(e,t){var a=t;if("ref"in t){a={};for(var n in t)n!=="ref"&&(a[n]=t[n])}if(e=e.defaultProps){a===t&&(a=y({},a));for(var r in e)a[r]===void 0&&(a[r]=e[r])}return a}function Gh(e){yr(e)}function Qh(e){console.error(e)}function Vh(e){yr(e)}function Yr(e,t){try{var a=e.onUncaughtError;a(t.value,{componentStack:t.stack})}catch(n){setTimeout(function(){throw n})}}function Xh(e,t,a){try{var n=e.onCaughtError;n(a.value,{componentStack:a.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(r){setTimeout(function(){throw r})}}function wc(e,t,a){return a=Xa(a),a.tag=3,a.payload={element:null},a.callback=function(){Yr(e,t)},a}function Kh(e){return e=Xa(e),e.tag=3,e}function Zh(e,t,a,n){var r=a.type.getDerivedStateFromError;if(typeof r=="function"){var o=n.value;e.payload=function(){return r(o)},e.callback=function(){Xh(t,a,n)}}var d=a.stateNode;d!==null&&typeof d.componentDidCatch=="function"&&(e.callback=function(){Xh(t,a,n),typeof r!="function"&&(Pa===null?Pa=new Set([this]):Pa.add(this));var m=n.stack;this.componentDidCatch(n.value,{componentStack:m!==null?m:""})})}function cx(e,t,a,n,r){if(a.flags|=32768,n!==null&&typeof n=="object"&&typeof n.then=="function"){if(t=a.alternate,t!==null&&oi(t,a,r,!0),a=Nt.current,a!==null){switch(a.tag){case 31:case 13:return Gt===null?Pr():a.alternate===null&&Ge===0&&(Ge=3),a.flags&=-257,a.flags|=65536,a.lanes=r,n===Tr?a.flags|=16384:(t=a.updateQueue,t===null?a.updateQueue=new Set([n]):t.add(n),Zc(e,n,r)),!1;case 22:return a.flags|=65536,n===Tr?a.flags|=16384:(t=a.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([n])},a.updateQueue=t):(a=t.retryQueue,a===null?t.retryQueue=new Set([n]):a.add(n)),Zc(e,n,r)),!1}throw Error(c(435,a.tag))}return Zc(e,n,r),Pr(),!1}if(ye)return t=Nt.current,t!==null?((t.flags&65536)===0&&(t.flags|=256),t.flags|=65536,t.lanes=r,n!==$s&&(e=Error(c(422),{cause:n}),ll(Lt(e,a)))):(n!==$s&&(t=Error(c(423),{cause:n}),ll(Lt(t,a))),e=e.current.alternate,e.flags|=65536,r&=-r,e.lanes|=r,n=Lt(n,a),r=wc(e.stateNode,n,r),Ps(e,r),Ge!==4&&(Ge=2)),!1;var o=Error(c(520),{cause:n});if(o=Lt(o,a),Cl===null?Cl=[o]:Cl.push(o),Ge!==4&&(Ge=2),t===null)return!0;n=Lt(n,a),a=t;do{switch(a.tag){case 3:return a.flags|=65536,e=r&-r,a.lanes|=e,e=wc(a.stateNode,n,e),Ps(a,e),!1;case 1:if(t=a.type,o=a.stateNode,(a.flags&128)===0&&(typeof t.getDerivedStateFromError=="function"||o!==null&&typeof o.componentDidCatch=="function"&&(Pa===null||!Pa.has(o))))return a.flags|=65536,r&=-r,a.lanes|=r,r=Kh(r),Zh(r,e,a,n),Ps(a,r),!1}a=a.return}while(a!==null);return!1}var Cc=Error(c(461)),Ie=!1;function ct(e,t,a,n){t.child=e===null?If(t,null,a,n):Rn(t,e.child,a,n)}function Wh(e,t,a,n,r){a=a.render;var o=t.ref;if("ref"in n){var d={};for(var m in n)m!=="ref"&&(d[m]=n[m])}else d=n;return En(t),n=lc(e,t,a,d,o,r),m=rc(),e!==null&&!Ie?(oc(e,t,r),Sa(e,t,r)):(ye&&m&&qs(t),t.flags|=1,ct(e,t,n,r),t.child)}function Jh(e,t,a,n,r){if(e===null){var o=a.type;return typeof o=="function"&&!Us(o)&&o.defaultProps===void 0&&a.compare===null?(t.tag=15,t.type=o,Fh(e,t,o,n,r)):(e=Sr(a.type,null,n,t,t.mode,r),e.ref=t.ref,e.return=t,t.child=e)}if(o=e.child,!_c(e,r)){var d=o.memoizedProps;if(a=a.compare,a=a!==null?a:al,a(d,n)&&e.ref===t.ref)return Sa(e,t,r)}return t.flags|=1,e=ga(o,n),e.ref=t.ref,e.return=t,t.child=e}function Fh(e,t,a,n,r){if(e!==null){var o=e.memoizedProps;if(al(o,n)&&e.ref===t.ref)if(Ie=!1,t.pendingProps=n=o,_c(e,r))(e.flags&131072)!==0&&(Ie=!0);else return t.lanes=e.lanes,Sa(e,t,r)}return Ac(e,t,a,n,r)}function Ih(e,t,a,n){var r=n.children,o=e!==null?e.memoizedState:null;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),n.mode==="hidden"){if((t.flags&128)!==0){if(o=o!==null?o.baseLanes|a:a,e!==null){for(n=t.child=e.child,r=0;n!==null;)r=r|n.lanes|n.childLanes,n=n.sibling;n=r&~o}else n=0,t.child=null;return Ph(e,t,o,a,n)}if((a&536870912)!==0)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&zr(t,o!==null?o.cachePool:null),o!==null?th(t,o):tc(),ah(t);else return n=t.lanes=536870912,Ph(e,t,o!==null?o.baseLanes|a:a,a,n)}else o!==null?(zr(t,o.cachePool),th(t,o),Wa(),t.memoizedState=null):(e!==null&&zr(t,null),tc(),Wa());return ct(e,t,r,a),t.child}function xl(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function Ph(e,t,a,n,r){var o=Ws();return o=o===null?null:{parent:Je._currentValue,pool:o},t.memoizedState={baseLanes:a,cachePool:o},e!==null&&zr(t,null),tc(),ah(t),e!==null&&oi(e,t,n,!0),t.childLanes=r,null}function $r(e,t){return t=Qr({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function ep(e,t,a){return Rn(t,e.child,null,a),e=$r(t,t.pendingProps),e.flags|=2,kt(t),t.memoizedState=null,e}function ux(e,t,a){var n=t.pendingProps,r=(t.flags&128)!==0;if(t.flags&=-129,e===null){if(ye){if(n.mode==="hidden")return e=$r(t,n),t.lanes=536870912,xl(null,e);if(nc(t),(e=He)?(e=f0(e,$t),e=e!==null&&e.data==="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:Ya!==null?{id:sa,overflow:ca}:null,retryLane:536870912,hydrationErrors:null},a=Uf(e),a.return=t,t.child=a,ot=t,He=null)):e=null,e===null)throw Ga(t);return t.lanes=536870912,null}return $r(t,n)}var o=e.memoizedState;if(o!==null){var d=o.dehydrated;if(nc(t),r)if(t.flags&256)t.flags&=-257,t=ep(e,t,a);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(c(558));else if(Ie||oi(e,t,a,!1),r=(a&e.childLanes)!==0,Ie||r){if(n=De,n!==null&&(d=Gd(n,a),d!==0&&d!==o.retryLane))throw o.retryLane=d,wn(e,d),jt(n,e,d),Cc;Pr(),t=ep(e,t,a)}else e=o.treeContext,He=Qt(d.nextSibling),ot=t,ye=!0,$a=null,$t=!1,e!==null&&qf(t,e),t=$r(t,n),t.flags|=4096;return t}return e=ga(e.child,{mode:n.mode,children:n.children}),e.ref=t.ref,t.child=e,e.return=t,e}function Gr(e,t){var a=t.ref;if(a===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof a!="function"&&typeof a!="object")throw Error(c(284));(e===null||e.ref!==a)&&(t.flags|=4194816)}}function Ac(e,t,a,n,r){return En(t),a=lc(e,t,a,n,void 0,r),n=rc(),e!==null&&!Ie?(oc(e,t,r),Sa(e,t,r)):(ye&&n&&qs(t),t.flags|=1,ct(e,t,a,r),t.child)}function tp(e,t,a,n,r,o){return En(t),t.updateQueue=null,a=ih(t,n,a,r),nh(e),n=rc(),e!==null&&!Ie?(oc(e,t,o),Sa(e,t,o)):(ye&&n&&qs(t),t.flags|=1,ct(e,t,a,o),t.child)}function ap(e,t,a,n,r){if(En(t),t.stateNode===null){var o=ni,d=a.contextType;typeof d=="object"&&d!==null&&(o=st(d)),o=new a(n,o),t.memoizedState=o.state!==null&&o.state!==void 0?o.state:null,o.updater=Sc,t.stateNode=o,o._reactInternals=t,o=t.stateNode,o.props=n,o.state=t.memoizedState,o.refs={},Fs(t),d=a.contextType,o.context=typeof d=="object"&&d!==null?st(d):ni,o.state=t.memoizedState,d=a.getDerivedStateFromProps,typeof d=="function"&&(jc(t,a,d,n),o.state=t.memoizedState),typeof a.getDerivedStateFromProps=="function"||typeof o.getSnapshotBeforeUpdate=="function"||typeof o.UNSAFE_componentWillMount!="function"&&typeof o.componentWillMount!="function"||(d=o.state,typeof o.componentWillMount=="function"&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount=="function"&&o.UNSAFE_componentWillMount(),d!==o.state&&Sc.enqueueReplaceState(o,o.state,null),fl(t,n,o,r),dl(),o.state=t.memoizedState),typeof o.componentDidMount=="function"&&(t.flags|=4194308),n=!0}else if(e===null){o=t.stateNode;var m=t.memoizedProps,j=Mn(a,m);o.props=j;var T=o.context,O=a.contextType;d=ni,typeof O=="object"&&O!==null&&(d=st(O));var L=a.getDerivedStateFromProps;O=typeof L=="function"||typeof o.getSnapshotBeforeUpdate=="function",m=t.pendingProps!==m,O||typeof o.UNSAFE_componentWillReceiveProps!="function"&&typeof o.componentWillReceiveProps!="function"||(m||T!==d)&&$h(t,o,n,d),Va=!1;var N=t.memoizedState;o.state=N,fl(t,n,o,r),dl(),T=t.memoizedState,m||N!==T||Va?(typeof L=="function"&&(jc(t,a,L,n),T=t.memoizedState),(j=Va||Yh(t,a,j,n,N,T,d))?(O||typeof o.UNSAFE_componentWillMount!="function"&&typeof o.componentWillMount!="function"||(typeof o.componentWillMount=="function"&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount=="function"&&o.UNSAFE_componentWillMount()),typeof o.componentDidMount=="function"&&(t.flags|=4194308)):(typeof o.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=n,t.memoizedState=T),o.props=n,o.state=T,o.context=d,n=j):(typeof o.componentDidMount=="function"&&(t.flags|=4194308),n=!1)}else{o=t.stateNode,Is(e,t),d=t.memoizedProps,O=Mn(a,d),o.props=O,L=t.pendingProps,N=o.context,T=a.contextType,j=ni,typeof T=="object"&&T!==null&&(j=st(T)),m=a.getDerivedStateFromProps,(T=typeof m=="function"||typeof o.getSnapshotBeforeUpdate=="function")||typeof o.UNSAFE_componentWillReceiveProps!="function"&&typeof o.componentWillReceiveProps!="function"||(d!==L||N!==j)&&$h(t,o,n,j),Va=!1,N=t.memoizedState,o.state=N,fl(t,n,o,r),dl();var R=t.memoizedState;d!==L||N!==R||Va||e!==null&&e.dependencies!==null&&Cr(e.dependencies)?(typeof m=="function"&&(jc(t,a,m,n),R=t.memoizedState),(O=Va||Yh(t,a,O,n,N,R,j)||e!==null&&e.dependencies!==null&&Cr(e.dependencies))?(T||typeof o.UNSAFE_componentWillUpdate!="function"&&typeof o.componentWillUpdate!="function"||(typeof o.componentWillUpdate=="function"&&o.componentWillUpdate(n,R,j),typeof o.UNSAFE_componentWillUpdate=="function"&&o.UNSAFE_componentWillUpdate(n,R,j)),typeof o.componentDidUpdate=="function"&&(t.flags|=4),typeof o.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof o.componentDidUpdate!="function"||d===e.memoizedProps&&N===e.memoizedState||(t.flags|=4),typeof o.getSnapshotBeforeUpdate!="function"||d===e.memoizedProps&&N===e.memoizedState||(t.flags|=1024),t.memoizedProps=n,t.memoizedState=R),o.props=n,o.state=R,o.context=j,n=O):(typeof o.componentDidUpdate!="function"||d===e.memoizedProps&&N===e.memoizedState||(t.flags|=4),typeof o.getSnapshotBeforeUpdate!="function"||d===e.memoizedProps&&N===e.memoizedState||(t.flags|=1024),n=!1)}return o=n,Gr(e,t),n=(t.flags&128)!==0,o||n?(o=t.stateNode,a=n&&typeof a.getDerivedStateFromError!="function"?null:o.render(),t.flags|=1,e!==null&&n?(t.child=Rn(t,e.child,null,r),t.child=Rn(t,null,a,r)):ct(e,t,a,r),t.memoizedState=o.state,e=t.child):e=Sa(e,t,r),e}function np(e,t,a,n){return An(),t.flags|=256,ct(e,t,a,n),t.child}var zc={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Ec(e){return{baseLanes:e,cachePool:Xf()}}function Tc(e,t,a){return e=e!==null?e.childLanes&~a:0,t&&(e|=_t),e}function ip(e,t,a){var n=t.pendingProps,r=!1,o=(t.flags&128)!==0,d;if((d=o)||(d=e!==null&&e.memoizedState===null?!1:(Xe.current&2)!==0),d&&(r=!0,t.flags&=-129),d=(t.flags&32)!==0,t.flags&=-33,e===null){if(ye){if(r?Za(t):Wa(),(e=He)?(e=f0(e,$t),e=e!==null&&e.data!=="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:Ya!==null?{id:sa,overflow:ca}:null,retryLane:536870912,hydrationErrors:null},a=Uf(e),a.return=t,t.child=a,ot=t,He=null)):e=null,e===null)throw Ga(t);return uu(e)?t.lanes=32:t.lanes=536870912,null}var m=n.children;return n=n.fallback,r?(Wa(),r=t.mode,m=Qr({mode:"hidden",children:m},r),n=Cn(n,r,a,null),m.return=t,n.return=t,m.sibling=n,t.child=m,n=t.child,n.memoizedState=Ec(a),n.childLanes=Tc(e,d,a),t.memoizedState=zc,xl(null,n)):(Za(t),Nc(t,m))}var j=e.memoizedState;if(j!==null&&(m=j.dehydrated,m!==null)){if(o)t.flags&256?(Za(t),t.flags&=-257,t=kc(e,t,a)):t.memoizedState!==null?(Wa(),t.child=e.child,t.flags|=128,t=null):(Wa(),m=n.fallback,r=t.mode,n=Qr({mode:"visible",children:n.children},r),m=Cn(m,r,a,null),m.flags|=2,n.return=t,m.return=t,n.sibling=m,t.child=n,Rn(t,e.child,null,a),n=t.child,n.memoizedState=Ec(a),n.childLanes=Tc(e,d,a),t.memoizedState=zc,t=xl(null,n));else if(Za(t),uu(m)){if(d=m.nextSibling&&m.nextSibling.dataset,d)var T=d.dgst;d=T,n=Error(c(419)),n.stack="",n.digest=d,ll({value:n,source:null,stack:null}),t=kc(e,t,a)}else if(Ie||oi(e,t,a,!1),d=(a&e.childLanes)!==0,Ie||d){if(d=De,d!==null&&(n=Gd(d,a),n!==0&&n!==j.retryLane))throw j.retryLane=n,wn(e,n),jt(d,e,n),Cc;cu(m)||Pr(),t=kc(e,t,a)}else cu(m)?(t.flags|=192,t.child=e.child,t=null):(e=j.treeContext,He=Qt(m.nextSibling),ot=t,ye=!0,$a=null,$t=!1,e!==null&&qf(t,e),t=Nc(t,n.children),t.flags|=4096);return t}return r?(Wa(),m=n.fallback,r=t.mode,j=e.child,T=j.sibling,n=ga(j,{mode:"hidden",children:n.children}),n.subtreeFlags=j.subtreeFlags&65011712,T!==null?m=ga(T,m):(m=Cn(m,r,a,null),m.flags|=2),m.return=t,n.return=t,n.sibling=m,t.child=n,xl(null,n),n=t.child,m=e.child.memoizedState,m===null?m=Ec(a):(r=m.cachePool,r!==null?(j=Je._currentValue,r=r.parent!==j?{parent:j,pool:j}:r):r=Xf(),m={baseLanes:m.baseLanes|a,cachePool:r}),n.memoizedState=m,n.childLanes=Tc(e,d,a),t.memoizedState=zc,xl(e.child,n)):(Za(t),a=e.child,e=a.sibling,a=ga(a,{mode:"visible",children:n.children}),a.return=t,a.sibling=null,e!==null&&(d=t.deletions,d===null?(t.deletions=[e],t.flags|=16):d.push(e)),t.child=a,t.memoizedState=null,a)}function Nc(e,t){return t=Qr({mode:"visible",children:t},e.mode),t.return=e,e.child=t}function Qr(e,t){return e=Tt(22,e,null,t),e.lanes=0,e}function kc(e,t,a){return Rn(t,e.child,null,a),e=Nc(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function lp(e,t,a){e.lanes|=t;var n=e.alternate;n!==null&&(n.lanes|=t),Vs(e.return,t,a)}function Rc(e,t,a,n,r,o){var d=e.memoizedState;d===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:n,tail:a,tailMode:r,treeForkCount:o}:(d.isBackwards=t,d.rendering=null,d.renderingStartTime=0,d.last=n,d.tail=a,d.tailMode=r,d.treeForkCount=o)}function rp(e,t,a){var n=t.pendingProps,r=n.revealOrder,o=n.tail;n=n.children;var d=Xe.current,m=(d&2)!==0;if(m?(d=d&1|2,t.flags|=128):d&=1,W(Xe,d),ct(e,t,n,a),n=ye?il:0,!m&&e!==null&&(e.flags&128)!==0)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&lp(e,a,t);else if(e.tag===19)lp(e,a,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(r){case"forwards":for(a=t.child,r=null;a!==null;)e=a.alternate,e!==null&&_r(e)===null&&(r=a),a=a.sibling;a=r,a===null?(r=t.child,t.child=null):(r=a.sibling,a.sibling=null),Rc(t,!1,r,a,o,n);break;case"backwards":case"unstable_legacy-backwards":for(a=null,r=t.child,t.child=null;r!==null;){if(e=r.alternate,e!==null&&_r(e)===null){t.child=r;break}e=r.sibling,r.sibling=a,a=r,r=e}Rc(t,!0,a,null,o,n);break;case"together":Rc(t,!1,null,null,void 0,n);break;default:t.memoizedState=null}return t.child}function Sa(e,t,a){if(e!==null&&(t.dependencies=e.dependencies),Ia|=t.lanes,(a&t.childLanes)===0)if(e!==null){if(oi(e,t,a,!1),(a&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(c(153));if(t.child!==null){for(e=t.child,a=ga(e,e.pendingProps),t.child=a,a.return=t;e.sibling!==null;)e=e.sibling,a=a.sibling=ga(e,e.pendingProps),a.return=t;a.sibling=null}return t.child}function _c(e,t){return(e.lanes&t)!==0?!0:(e=e.dependencies,!!(e!==null&&Cr(e)))}function dx(e,t,a){switch(t.tag){case 3:We(t,t.stateNode.containerInfo),Qa(t,Je,e.memoizedState.cache),An();break;case 27:case 5:la(t);break;case 4:We(t,t.stateNode.containerInfo);break;case 10:Qa(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,nc(t),null;break;case 13:var n=t.memoizedState;if(n!==null)return n.dehydrated!==null?(Za(t),t.flags|=128,null):(a&t.child.childLanes)!==0?ip(e,t,a):(Za(t),e=Sa(e,t,a),e!==null?e.sibling:null);Za(t);break;case 19:var r=(e.flags&128)!==0;if(n=(a&t.childLanes)!==0,n||(oi(e,t,a,!1),n=(a&t.childLanes)!==0),r){if(n)return rp(e,t,a);t.flags|=128}if(r=t.memoizedState,r!==null&&(r.rendering=null,r.tail=null,r.lastEffect=null),W(Xe,Xe.current),n)break;return null;case 22:return t.lanes=0,Ih(e,t,a,t.pendingProps);case 24:Qa(t,Je,e.memoizedState.cache)}return Sa(e,t,a)}function op(e,t,a){if(e!==null)if(e.memoizedProps!==t.pendingProps)Ie=!0;else{if(!_c(e,a)&&(t.flags&128)===0)return Ie=!1,dx(e,t,a);Ie=(e.flags&131072)!==0}else Ie=!1,ye&&(t.flags&1048576)!==0&&Lf(t,il,t.index);switch(t.lanes=0,t.tag){case 16:e:{var n=t.pendingProps;if(e=Nn(t.elementType),t.type=e,typeof e=="function")Us(e)?(n=Mn(e,n),t.tag=1,t=ap(null,t,e,n,a)):(t.tag=0,t=Ac(null,t,e,n,a));else{if(e!=null){var r=e.$$typeof;if(r===V){t.tag=11,t=Wh(null,t,e,n,a);break e}else if(r===$){t.tag=14,t=Jh(null,t,e,n,a);break e}}throw t=Me(e)||e,Error(c(306,t,""))}}return t;case 0:return Ac(e,t,t.type,t.pendingProps,a);case 1:return n=t.type,r=Mn(n,t.pendingProps),ap(e,t,n,r,a);case 3:e:{if(We(t,t.stateNode.containerInfo),e===null)throw Error(c(387));n=t.pendingProps;var o=t.memoizedState;r=o.element,Is(e,t),fl(t,n,null,a);var d=t.memoizedState;if(n=d.cache,Qa(t,Je,n),n!==o.cache&&Xs(t,[Je],a,!0),dl(),n=d.element,o.isDehydrated)if(o={element:n,isDehydrated:!1,cache:d.cache},t.updateQueue.baseState=o,t.memoizedState=o,t.flags&256){t=np(e,t,n,a);break e}else if(n!==r){r=Lt(Error(c(424)),t),ll(r),t=np(e,t,n,a);break e}else for(e=t.stateNode.containerInfo,e.nodeType===9?e=e.body:e=e.nodeName==="HTML"?e.ownerDocument.body:e,He=Qt(e.firstChild),ot=t,ye=!0,$a=null,$t=!0,a=If(t,null,n,a),t.child=a;a;)a.flags=a.flags&-3|4096,a=a.sibling;else{if(An(),n===r){t=Sa(e,t,a);break e}ct(e,t,n,a)}t=t.child}return t;case 26:return Gr(e,t),e===null?(a=y0(t.type,null,t.pendingProps,null))?t.memoizedState=a:ye||(a=t.type,e=t.pendingProps,n=ro(ce.current).createElement(a),n[rt]=t,n[mt]=e,ut(n,a,e),nt(n),t.stateNode=n):t.memoizedState=y0(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return la(t),e===null&&ye&&(n=t.stateNode=m0(t.type,t.pendingProps,ce.current),ot=t,$t=!0,r=He,nn(t.type)?(du=r,He=Qt(n.firstChild)):He=r),ct(e,t,t.pendingProps.children,a),Gr(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&ye&&((r=n=He)&&(n=Yx(n,t.type,t.pendingProps,$t),n!==null?(t.stateNode=n,ot=t,He=Qt(n.firstChild),$t=!1,r=!0):r=!1),r||Ga(t)),la(t),r=t.type,o=t.pendingProps,d=e!==null?e.memoizedProps:null,n=o.children,ru(r,o)?n=null:d!==null&&ru(r,d)&&(t.flags|=32),t.memoizedState!==null&&(r=lc(e,t,ax,null,null,a),_l._currentValue=r),Gr(e,t),ct(e,t,n,a),t.child;case 6:return e===null&&ye&&((e=a=He)&&(a=$x(a,t.pendingProps,$t),a!==null?(t.stateNode=a,ot=t,He=null,e=!0):e=!1),e||Ga(t)),null;case 13:return ip(e,t,a);case 4:return We(t,t.stateNode.containerInfo),n=t.pendingProps,e===null?t.child=Rn(t,null,n,a):ct(e,t,n,a),t.child;case 11:return Wh(e,t,t.type,t.pendingProps,a);case 7:return ct(e,t,t.pendingProps,a),t.child;case 8:return ct(e,t,t.pendingProps.children,a),t.child;case 12:return ct(e,t,t.pendingProps.children,a),t.child;case 10:return n=t.pendingProps,Qa(t,t.type,n.value),ct(e,t,n.children,a),t.child;case 9:return r=t.type._context,n=t.pendingProps.children,En(t),r=st(r),n=n(r),t.flags|=1,ct(e,t,n,a),t.child;case 14:return Jh(e,t,t.type,t.pendingProps,a);case 15:return Fh(e,t,t.type,t.pendingProps,a);case 19:return rp(e,t,a);case 31:return ux(e,t,a);case 22:return Ih(e,t,a,t.pendingProps);case 24:return En(t),n=st(Je),e===null?(r=Ws(),r===null&&(r=De,o=Ks(),r.pooledCache=o,o.refCount++,o!==null&&(r.pooledCacheLanes|=a),r=o),t.memoizedState={parent:n,cache:r},Fs(t),Qa(t,Je,r)):((e.lanes&a)!==0&&(Is(e,t),fl(t,null,null,a),dl()),r=e.memoizedState,o=t.memoizedState,r.parent!==n?(r={parent:n,cache:n},t.memoizedState=r,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=r),Qa(t,Je,n)):(n=o.cache,Qa(t,Je,n),n!==r.cache&&Xs(t,[Je],a,!0))),ct(e,t,t.pendingProps.children,a),t.child;case 29:throw t.pendingProps}throw Error(c(156,t.tag))}function wa(e){e.flags|=4}function Mc(e,t,a,n,r){if((t=(e.mode&32)!==0)&&(t=!1),t){if(e.flags|=16777216,(r&335544128)===r)if(e.stateNode.complete)e.flags|=8192;else if(Dp())e.flags|=8192;else throw kn=Tr,Js}else e.flags&=-16777217}function sp(e,t){if(t.type!=="stylesheet"||(t.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!w0(t))if(Dp())e.flags|=8192;else throw kn=Tr,Js}function Vr(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag!==22?qd():536870912,e.lanes|=t,bi|=t)}function yl(e,t){if(!ye)switch(e.tailMode){case"hidden":t=e.tail;for(var a=null;t!==null;)t.alternate!==null&&(a=t),t=t.sibling;a===null?e.tail=null:a.sibling=null;break;case"collapsed":a=e.tail;for(var n=null;a!==null;)a.alternate!==null&&(n=a),a=a.sibling;n===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:n.sibling=null}}function Ue(e){var t=e.alternate!==null&&e.alternate.child===e.child,a=0,n=0;if(t)for(var r=e.child;r!==null;)a|=r.lanes|r.childLanes,n|=r.subtreeFlags&65011712,n|=r.flags&65011712,r.return=e,r=r.sibling;else for(r=e.child;r!==null;)a|=r.lanes|r.childLanes,n|=r.subtreeFlags,n|=r.flags,r.return=e,r=r.sibling;return e.subtreeFlags|=n,e.childLanes=a,t}function fx(e,t,a){var n=t.pendingProps;switch(Ys(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Ue(t),null;case 1:return Ue(t),null;case 3:return a=t.stateNode,n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),ba(Je),Ne(),a.pendingContext&&(a.context=a.pendingContext,a.pendingContext=null),(e===null||e.child===null)&&(ri(t)?wa(t):e===null||e.memoizedState.isDehydrated&&(t.flags&256)===0||(t.flags|=1024,Gs())),Ue(t),null;case 26:var r=t.type,o=t.memoizedState;return e===null?(wa(t),o!==null?(Ue(t),sp(t,o)):(Ue(t),Mc(t,r,null,n,a))):o?o!==e.memoizedState?(wa(t),Ue(t),sp(t,o)):(Ue(t),t.flags&=-16777217):(e=e.memoizedProps,e!==n&&wa(t),Ue(t),Mc(t,r,e,n,a)),null;case 27:if(ra(t),a=ce.current,r=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==n&&wa(t);else{if(!n){if(t.stateNode===null)throw Error(c(166));return Ue(t),null}e=F.current,ri(t)?Yf(t):(e=m0(r,n,a),t.stateNode=e,wa(t))}return Ue(t),null;case 5:if(ra(t),r=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==n&&wa(t);else{if(!n){if(t.stateNode===null)throw Error(c(166));return Ue(t),null}if(o=F.current,ri(t))Yf(t);else{var d=ro(ce.current);switch(o){case 1:o=d.createElementNS("http://www.w3.org/2000/svg",r);break;case 2:o=d.createElementNS("http://www.w3.org/1998/Math/MathML",r);break;default:switch(r){case"svg":o=d.createElementNS("http://www.w3.org/2000/svg",r);break;case"math":o=d.createElementNS("http://www.w3.org/1998/Math/MathML",r);break;case"script":o=d.createElement("div"),o.innerHTML="<script><\/script>",o=o.removeChild(o.firstChild);break;case"select":o=typeof n.is=="string"?d.createElement("select",{is:n.is}):d.createElement("select"),n.multiple?o.multiple=!0:n.size&&(o.size=n.size);break;default:o=typeof n.is=="string"?d.createElement(r,{is:n.is}):d.createElement(r)}}o[rt]=t,o[mt]=n;e:for(d=t.child;d!==null;){if(d.tag===5||d.tag===6)o.appendChild(d.stateNode);else if(d.tag!==4&&d.tag!==27&&d.child!==null){d.child.return=d,d=d.child;continue}if(d===t)break e;for(;d.sibling===null;){if(d.return===null||d.return===t)break e;d=d.return}d.sibling.return=d.return,d=d.sibling}t.stateNode=o;e:switch(ut(o,r,n),r){case"button":case"input":case"select":case"textarea":n=!!n.autoFocus;break e;case"img":n=!0;break e;default:n=!1}n&&wa(t)}}return Ue(t),Mc(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,a),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==n&&wa(t);else{if(typeof n!="string"&&t.stateNode===null)throw Error(c(166));if(e=ce.current,ri(t)){if(e=t.stateNode,a=t.memoizedProps,n=null,r=ot,r!==null)switch(r.tag){case 27:case 5:n=r.memoizedProps}e[rt]=t,e=!!(e.nodeValue===a||n!==null&&n.suppressHydrationWarning===!0||i0(e.nodeValue,a)),e||Ga(t,!0)}else e=ro(e).createTextNode(n),e[rt]=t,t.stateNode=e}return Ue(t),null;case 31:if(a=t.memoizedState,e===null||e.memoizedState!==null){if(n=ri(t),a!==null){if(e===null){if(!n)throw Error(c(318));if(e=t.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(c(557));e[rt]=t}else An(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;Ue(t),e=!1}else a=Gs(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),e=!0;if(!e)return t.flags&256?(kt(t),t):(kt(t),null);if((t.flags&128)!==0)throw Error(c(558))}return Ue(t),null;case 13:if(n=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(r=ri(t),n!==null&&n.dehydrated!==null){if(e===null){if(!r)throw Error(c(318));if(r=t.memoizedState,r=r!==null?r.dehydrated:null,!r)throw Error(c(317));r[rt]=t}else An(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;Ue(t),r=!1}else r=Gs(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=r),r=!0;if(!r)return t.flags&256?(kt(t),t):(kt(t),null)}return kt(t),(t.flags&128)!==0?(t.lanes=a,t):(a=n!==null,e=e!==null&&e.memoizedState!==null,a&&(n=t.child,r=null,n.alternate!==null&&n.alternate.memoizedState!==null&&n.alternate.memoizedState.cachePool!==null&&(r=n.alternate.memoizedState.cachePool.pool),o=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(o=n.memoizedState.cachePool.pool),o!==r&&(n.flags|=2048)),a!==e&&a&&(t.child.flags|=8192),Vr(t,t.updateQueue),Ue(t),null);case 4:return Ne(),e===null&&tu(t.stateNode.containerInfo),Ue(t),null;case 10:return ba(t.type),Ue(t),null;case 19:if(H(Xe),n=t.memoizedState,n===null)return Ue(t),null;if(r=(t.flags&128)!==0,o=n.rendering,o===null)if(r)yl(n,!1);else{if(Ge!==0||e!==null&&(e.flags&128)!==0)for(e=t.child;e!==null;){if(o=_r(e),o!==null){for(t.flags|=128,yl(n,!1),e=o.updateQueue,t.updateQueue=e,Vr(t,e),t.subtreeFlags=0,e=a,a=t.child;a!==null;)Hf(a,e),a=a.sibling;return W(Xe,Xe.current&1|2),ye&&xa(t,n.treeForkCount),t.child}e=e.sibling}n.tail!==null&&Ct()>Jr&&(t.flags|=128,r=!0,yl(n,!1),t.lanes=4194304)}else{if(!r)if(e=_r(o),e!==null){if(t.flags|=128,r=!0,e=e.updateQueue,t.updateQueue=e,Vr(t,e),yl(n,!0),n.tail===null&&n.tailMode==="hidden"&&!o.alternate&&!ye)return Ue(t),null}else 2*Ct()-n.renderingStartTime>Jr&&a!==536870912&&(t.flags|=128,r=!0,yl(n,!1),t.lanes=4194304);n.isBackwards?(o.sibling=t.child,t.child=o):(e=n.last,e!==null?e.sibling=o:t.child=o,n.last=o)}return n.tail!==null?(e=n.tail,n.rendering=e,n.tail=e.sibling,n.renderingStartTime=Ct(),e.sibling=null,a=Xe.current,W(Xe,r?a&1|2:a&1),ye&&xa(t,n.treeForkCount),e):(Ue(t),null);case 22:case 23:return kt(t),ac(),n=t.memoizedState!==null,e!==null?e.memoizedState!==null!==n&&(t.flags|=8192):n&&(t.flags|=8192),n?(a&536870912)!==0&&(t.flags&128)===0&&(Ue(t),t.subtreeFlags&6&&(t.flags|=8192)):Ue(t),a=t.updateQueue,a!==null&&Vr(t,a.retryQueue),a=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(a=e.memoizedState.cachePool.pool),n=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(n=t.memoizedState.cachePool.pool),n!==a&&(t.flags|=2048),e!==null&&H(Tn),null;case 24:return a=null,e!==null&&(a=e.memoizedState.cache),t.memoizedState.cache!==a&&(t.flags|=2048),ba(Je),Ue(t),null;case 25:return null;case 30:return null}throw Error(c(156,t.tag))}function hx(e,t){switch(Ys(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return ba(Je),Ne(),e=t.flags,(e&65536)!==0&&(e&128)===0?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return ra(t),null;case 31:if(t.memoizedState!==null){if(kt(t),t.alternate===null)throw Error(c(340));An()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(kt(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(c(340));An()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return H(Xe),null;case 4:return Ne(),null;case 10:return ba(t.type),null;case 22:case 23:return kt(t),ac(),e!==null&&H(Tn),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return ba(Je),null;case 25:return null;default:return null}}function cp(e,t){switch(Ys(t),t.tag){case 3:ba(Je),Ne();break;case 26:case 27:case 5:ra(t);break;case 4:Ne();break;case 31:t.memoizedState!==null&&kt(t);break;case 13:kt(t);break;case 19:H(Xe);break;case 10:ba(t.type);break;case 22:case 23:kt(t),ac(),e!==null&&H(Tn);break;case 24:ba(Je)}}function bl(e,t){try{var a=t.updateQueue,n=a!==null?a.lastEffect:null;if(n!==null){var r=n.next;a=r;do{if((a.tag&e)===e){n=void 0;var o=a.create,d=a.inst;n=o(),d.destroy=n}a=a.next}while(a!==r)}}catch(m){Te(t,t.return,m)}}function Ja(e,t,a){try{var n=t.updateQueue,r=n!==null?n.lastEffect:null;if(r!==null){var o=r.next;n=o;do{if((n.tag&e)===e){var d=n.inst,m=d.destroy;if(m!==void 0){d.destroy=void 0,r=t;var j=a,T=m;try{T()}catch(O){Te(r,j,O)}}}n=n.next}while(n!==o)}}catch(O){Te(t,t.return,O)}}function up(e){var t=e.updateQueue;if(t!==null){var a=e.stateNode;try{eh(t,a)}catch(n){Te(e,e.return,n)}}}function dp(e,t,a){a.props=Mn(e.type,e.memoizedProps),a.state=e.memoizedState;try{a.componentWillUnmount()}catch(n){Te(e,t,n)}}function vl(e,t){try{var a=e.ref;if(a!==null){switch(e.tag){case 26:case 27:case 5:var n=e.stateNode;break;case 30:n=e.stateNode;break;default:n=e.stateNode}typeof a=="function"?e.refCleanup=a(n):a.current=n}}catch(r){Te(e,t,r)}}function ua(e,t){var a=e.ref,n=e.refCleanup;if(a!==null)if(typeof n=="function")try{n()}catch(r){Te(e,t,r)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof a=="function")try{a(null)}catch(r){Te(e,t,r)}else a.current=null}function fp(e){var t=e.type,a=e.memoizedProps,n=e.stateNode;try{e:switch(t){case"button":case"input":case"select":case"textarea":a.autoFocus&&n.focus();break e;case"img":a.src?n.src=a.src:a.srcSet&&(n.srcset=a.srcSet)}}catch(r){Te(e,e.return,r)}}function Dc(e,t,a){try{var n=e.stateNode;Ox(n,e.type,a,t),n[mt]=t}catch(r){Te(e,e.return,r)}}function hp(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&nn(e.type)||e.tag===4}function Oc(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||hp(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&nn(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Hc(e,t,a){var n=e.tag;if(n===5||n===6)e=e.stateNode,t?(a.nodeType===9?a.body:a.nodeName==="HTML"?a.ownerDocument.body:a).insertBefore(e,t):(t=a.nodeType===9?a.body:a.nodeName==="HTML"?a.ownerDocument.body:a,t.appendChild(e),a=a._reactRootContainer,a!=null||t.onclick!==null||(t.onclick=pa));else if(n!==4&&(n===27&&nn(e.type)&&(a=e.stateNode,t=null),e=e.child,e!==null))for(Hc(e,t,a),e=e.sibling;e!==null;)Hc(e,t,a),e=e.sibling}function Xr(e,t,a){var n=e.tag;if(n===5||n===6)e=e.stateNode,t?a.insertBefore(e,t):a.appendChild(e);else if(n!==4&&(n===27&&nn(e.type)&&(a=e.stateNode),e=e.child,e!==null))for(Xr(e,t,a),e=e.sibling;e!==null;)Xr(e,t,a),e=e.sibling}function pp(e){var t=e.stateNode,a=e.memoizedProps;try{for(var n=e.type,r=t.attributes;r.length;)t.removeAttributeNode(r[0]);ut(t,n,a),t[rt]=e,t[mt]=a}catch(o){Te(e,e.return,o)}}var Ca=!1,Pe=!1,Uc=!1,mp=typeof WeakSet=="function"?WeakSet:Set,it=null;function px(e,t){if(e=e.containerInfo,iu=po,e=Ef(e),ks(e)){if("selectionStart"in e)var a={start:e.selectionStart,end:e.selectionEnd};else e:{a=(a=e.ownerDocument)&&a.defaultView||window;var n=a.getSelection&&a.getSelection();if(n&&n.rangeCount!==0){a=n.anchorNode;var r=n.anchorOffset,o=n.focusNode;n=n.focusOffset;try{a.nodeType,o.nodeType}catch{a=null;break e}var d=0,m=-1,j=-1,T=0,O=0,L=e,N=null;t:for(;;){for(var R;L!==a||r!==0&&L.nodeType!==3||(m=d+r),L!==o||n!==0&&L.nodeType!==3||(j=d+n),L.nodeType===3&&(d+=L.nodeValue.length),(R=L.firstChild)!==null;)N=L,L=R;for(;;){if(L===e)break t;if(N===a&&++T===r&&(m=d),N===o&&++O===n&&(j=d),(R=L.nextSibling)!==null)break;L=N,N=L.parentNode}L=R}a=m===-1||j===-1?null:{start:m,end:j}}else a=null}a=a||{start:0,end:0}}else a=null;for(lu={focusedElem:e,selectionRange:a},po=!1,it=t;it!==null;)if(t=it,e=t.child,(t.subtreeFlags&1028)!==0&&e!==null)e.return=t,it=e;else for(;it!==null;){switch(t=it,o=t.alternate,e=t.flags,t.tag){case 0:if((e&4)!==0&&(e=t.updateQueue,e=e!==null?e.events:null,e!==null))for(a=0;a<e.length;a++)r=e[a],r.ref.impl=r.nextImpl;break;case 11:case 15:break;case 1:if((e&1024)!==0&&o!==null){e=void 0,a=t,r=o.memoizedProps,o=o.memoizedState,n=a.stateNode;try{var P=Mn(a.type,r);e=n.getSnapshotBeforeUpdate(P,o),n.__reactInternalSnapshotBeforeUpdate=e}catch(le){Te(a,a.return,le)}}break;case 3:if((e&1024)!==0){if(e=t.stateNode.containerInfo,a=e.nodeType,a===9)su(e);else if(a===1)switch(e.nodeName){case"HEAD":case"HTML":case"BODY":su(e);break;default:e.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((e&1024)!==0)throw Error(c(163))}if(e=t.sibling,e!==null){e.return=t.return,it=e;break}it=t.return}}function gp(e,t,a){var n=a.flags;switch(a.tag){case 0:case 11:case 15:za(e,a),n&4&&bl(5,a);break;case 1:if(za(e,a),n&4)if(e=a.stateNode,t===null)try{e.componentDidMount()}catch(d){Te(a,a.return,d)}else{var r=Mn(a.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(r,t,e.__reactInternalSnapshotBeforeUpdate)}catch(d){Te(a,a.return,d)}}n&64&&up(a),n&512&&vl(a,a.return);break;case 3:if(za(e,a),n&64&&(e=a.updateQueue,e!==null)){if(t=null,a.child!==null)switch(a.child.tag){case 27:case 5:t=a.child.stateNode;break;case 1:t=a.child.stateNode}try{eh(e,t)}catch(d){Te(a,a.return,d)}}break;case 27:t===null&&n&4&&pp(a);case 26:case 5:za(e,a),t===null&&n&4&&fp(a),n&512&&vl(a,a.return);break;case 12:za(e,a);break;case 31:za(e,a),n&4&&bp(e,a);break;case 13:za(e,a),n&4&&vp(e,a),n&64&&(e=a.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(a=wx.bind(null,a),Gx(e,a))));break;case 22:if(n=a.memoizedState!==null||Ca,!n){t=t!==null&&t.memoizedState!==null||Pe,r=Ca;var o=Pe;Ca=n,(Pe=t)&&!o?Ea(e,a,(a.subtreeFlags&8772)!==0):za(e,a),Ca=r,Pe=o}break;case 30:break;default:za(e,a)}}function xp(e){var t=e.alternate;t!==null&&(e.alternate=null,xp(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&hs(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var Le=null,xt=!1;function Aa(e,t,a){for(a=a.child;a!==null;)yp(e,t,a),a=a.sibling}function yp(e,t,a){if(At&&typeof At.onCommitFiberUnmount=="function")try{At.onCommitFiberUnmount(Qi,a)}catch{}switch(a.tag){case 26:Pe||ua(a,t),Aa(e,t,a),a.memoizedState?a.memoizedState.count--:a.stateNode&&(a=a.stateNode,a.parentNode.removeChild(a));break;case 27:Pe||ua(a,t);var n=Le,r=xt;nn(a.type)&&(Le=a.stateNode,xt=!1),Aa(e,t,a),Nl(a.stateNode),Le=n,xt=r;break;case 5:Pe||ua(a,t);case 6:if(n=Le,r=xt,Le=null,Aa(e,t,a),Le=n,xt=r,Le!==null)if(xt)try{(Le.nodeType===9?Le.body:Le.nodeName==="HTML"?Le.ownerDocument.body:Le).removeChild(a.stateNode)}catch(o){Te(a,t,o)}else try{Le.removeChild(a.stateNode)}catch(o){Te(a,t,o)}break;case 18:Le!==null&&(xt?(e=Le,u0(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,a.stateNode),Ei(e)):u0(Le,a.stateNode));break;case 4:n=Le,r=xt,Le=a.stateNode.containerInfo,xt=!0,Aa(e,t,a),Le=n,xt=r;break;case 0:case 11:case 14:case 15:Ja(2,a,t),Pe||Ja(4,a,t),Aa(e,t,a);break;case 1:Pe||(ua(a,t),n=a.stateNode,typeof n.componentWillUnmount=="function"&&dp(a,t,n)),Aa(e,t,a);break;case 21:Aa(e,t,a);break;case 22:Pe=(n=Pe)||a.memoizedState!==null,Aa(e,t,a),Pe=n;break;default:Aa(e,t,a)}}function bp(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{Ei(e)}catch(a){Te(t,t.return,a)}}}function vp(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{Ei(e)}catch(a){Te(t,t.return,a)}}function mx(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new mp),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new mp),t;default:throw Error(c(435,e.tag))}}function Kr(e,t){var a=mx(e);t.forEach(function(n){if(!a.has(n)){a.add(n);var r=Cx.bind(null,e,n);n.then(r,r)}})}function yt(e,t){var a=t.deletions;if(a!==null)for(var n=0;n<a.length;n++){var r=a[n],o=e,d=t,m=d;e:for(;m!==null;){switch(m.tag){case 27:if(nn(m.type)){Le=m.stateNode,xt=!1;break e}break;case 5:Le=m.stateNode,xt=!1;break e;case 3:case 4:Le=m.stateNode.containerInfo,xt=!0;break e}m=m.return}if(Le===null)throw Error(c(160));yp(o,d,r),Le=null,xt=!1,o=r.alternate,o!==null&&(o.return=null),r.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)jp(t,e),t=t.sibling}var It=null;function jp(e,t){var a=e.alternate,n=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:yt(t,e),bt(e),n&4&&(Ja(3,e,e.return),bl(3,e),Ja(5,e,e.return));break;case 1:yt(t,e),bt(e),n&512&&(Pe||a===null||ua(a,a.return)),n&64&&Ca&&(e=e.updateQueue,e!==null&&(n=e.callbacks,n!==null&&(a=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=a===null?n:a.concat(n))));break;case 26:var r=It;if(yt(t,e),bt(e),n&512&&(Pe||a===null||ua(a,a.return)),n&4){var o=a!==null?a.memoizedState:null;if(n=e.memoizedState,a===null)if(n===null)if(e.stateNode===null){e:{n=e.type,a=e.memoizedProps,r=r.ownerDocument||r;t:switch(n){case"title":o=r.getElementsByTagName("title")[0],(!o||o[Ki]||o[rt]||o.namespaceURI==="http://www.w3.org/2000/svg"||o.hasAttribute("itemprop"))&&(o=r.createElement(n),r.head.insertBefore(o,r.querySelector("head > title"))),ut(o,n,a),o[rt]=e,nt(o),n=o;break e;case"link":var d=j0("link","href",r).get(n+(a.href||""));if(d){for(var m=0;m<d.length;m++)if(o=d[m],o.getAttribute("href")===(a.href==null||a.href===""?null:a.href)&&o.getAttribute("rel")===(a.rel==null?null:a.rel)&&o.getAttribute("title")===(a.title==null?null:a.title)&&o.getAttribute("crossorigin")===(a.crossOrigin==null?null:a.crossOrigin)){d.splice(m,1);break t}}o=r.createElement(n),ut(o,n,a),r.head.appendChild(o);break;case"meta":if(d=j0("meta","content",r).get(n+(a.content||""))){for(m=0;m<d.length;m++)if(o=d[m],o.getAttribute("content")===(a.content==null?null:""+a.content)&&o.getAttribute("name")===(a.name==null?null:a.name)&&o.getAttribute("property")===(a.property==null?null:a.property)&&o.getAttribute("http-equiv")===(a.httpEquiv==null?null:a.httpEquiv)&&o.getAttribute("charset")===(a.charSet==null?null:a.charSet)){d.splice(m,1);break t}}o=r.createElement(n),ut(o,n,a),r.head.appendChild(o);break;default:throw Error(c(468,n))}o[rt]=e,nt(o),n=o}e.stateNode=n}else S0(r,e.type,e.stateNode);else e.stateNode=v0(r,n,e.memoizedProps);else o!==n?(o===null?a.stateNode!==null&&(a=a.stateNode,a.parentNode.removeChild(a)):o.count--,n===null?S0(r,e.type,e.stateNode):v0(r,n,e.memoizedProps)):n===null&&e.stateNode!==null&&Dc(e,e.memoizedProps,a.memoizedProps)}break;case 27:yt(t,e),bt(e),n&512&&(Pe||a===null||ua(a,a.return)),a!==null&&n&4&&Dc(e,e.memoizedProps,a.memoizedProps);break;case 5:if(yt(t,e),bt(e),n&512&&(Pe||a===null||ua(a,a.return)),e.flags&32){r=e.stateNode;try{Jn(r,"")}catch(P){Te(e,e.return,P)}}n&4&&e.stateNode!=null&&(r=e.memoizedProps,Dc(e,r,a!==null?a.memoizedProps:r)),n&1024&&(Uc=!0);break;case 6:if(yt(t,e),bt(e),n&4){if(e.stateNode===null)throw Error(c(162));n=e.memoizedProps,a=e.stateNode;try{a.nodeValue=n}catch(P){Te(e,e.return,P)}}break;case 3:if(co=null,r=It,It=oo(t.containerInfo),yt(t,e),It=r,bt(e),n&4&&a!==null&&a.memoizedState.isDehydrated)try{Ei(t.containerInfo)}catch(P){Te(e,e.return,P)}Uc&&(Uc=!1,Sp(e));break;case 4:n=It,It=oo(e.stateNode.containerInfo),yt(t,e),bt(e),It=n;break;case 12:yt(t,e),bt(e);break;case 31:yt(t,e),bt(e),n&4&&(n=e.updateQueue,n!==null&&(e.updateQueue=null,Kr(e,n)));break;case 13:yt(t,e),bt(e),e.child.flags&8192&&e.memoizedState!==null!=(a!==null&&a.memoizedState!==null)&&(Wr=Ct()),n&4&&(n=e.updateQueue,n!==null&&(e.updateQueue=null,Kr(e,n)));break;case 22:r=e.memoizedState!==null;var j=a!==null&&a.memoizedState!==null,T=Ca,O=Pe;if(Ca=T||r,Pe=O||j,yt(t,e),Pe=O,Ca=T,bt(e),n&8192)e:for(t=e.stateNode,t._visibility=r?t._visibility&-2:t._visibility|1,r&&(a===null||j||Ca||Pe||Dn(e)),a=null,t=e;;){if(t.tag===5||t.tag===26){if(a===null){j=a=t;try{if(o=j.stateNode,r)d=o.style,typeof d.setProperty=="function"?d.setProperty("display","none","important"):d.display="none";else{m=j.stateNode;var L=j.memoizedProps.style,N=L!=null&&L.hasOwnProperty("display")?L.display:null;m.style.display=N==null||typeof N=="boolean"?"":(""+N).trim()}}catch(P){Te(j,j.return,P)}}}else if(t.tag===6){if(a===null){j=t;try{j.stateNode.nodeValue=r?"":j.memoizedProps}catch(P){Te(j,j.return,P)}}}else if(t.tag===18){if(a===null){j=t;try{var R=j.stateNode;r?d0(R,!0):d0(j.stateNode,!1)}catch(P){Te(j,j.return,P)}}}else if((t.tag!==22&&t.tag!==23||t.memoizedState===null||t===e)&&t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break e;for(;t.sibling===null;){if(t.return===null||t.return===e)break e;a===t&&(a=null),t=t.return}a===t&&(a=null),t.sibling.return=t.return,t=t.sibling}n&4&&(n=e.updateQueue,n!==null&&(a=n.retryQueue,a!==null&&(n.retryQueue=null,Kr(e,a))));break;case 19:yt(t,e),bt(e),n&4&&(n=e.updateQueue,n!==null&&(e.updateQueue=null,Kr(e,n)));break;case 30:break;case 21:break;default:yt(t,e),bt(e)}}function bt(e){var t=e.flags;if(t&2){try{for(var a,n=e.return;n!==null;){if(hp(n)){a=n;break}n=n.return}if(a==null)throw Error(c(160));switch(a.tag){case 27:var r=a.stateNode,o=Oc(e);Xr(e,o,r);break;case 5:var d=a.stateNode;a.flags&32&&(Jn(d,""),a.flags&=-33);var m=Oc(e);Xr(e,m,d);break;case 3:case 4:var j=a.stateNode.containerInfo,T=Oc(e);Hc(e,T,j);break;default:throw Error(c(161))}}catch(O){Te(e,e.return,O)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function Sp(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;Sp(t),t.tag===5&&t.flags&1024&&t.stateNode.reset(),e=e.sibling}}function za(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)gp(e,t.alternate,t),t=t.sibling}function Dn(e){for(e=e.child;e!==null;){var t=e;switch(t.tag){case 0:case 11:case 14:case 15:Ja(4,t,t.return),Dn(t);break;case 1:ua(t,t.return);var a=t.stateNode;typeof a.componentWillUnmount=="function"&&dp(t,t.return,a),Dn(t);break;case 27:Nl(t.stateNode);case 26:case 5:ua(t,t.return),Dn(t);break;case 22:t.memoizedState===null&&Dn(t);break;case 30:Dn(t);break;default:Dn(t)}e=e.sibling}}function Ea(e,t,a){for(a=a&&(t.subtreeFlags&8772)!==0,t=t.child;t!==null;){var n=t.alternate,r=e,o=t,d=o.flags;switch(o.tag){case 0:case 11:case 15:Ea(r,o,a),bl(4,o);break;case 1:if(Ea(r,o,a),n=o,r=n.stateNode,typeof r.componentDidMount=="function")try{r.componentDidMount()}catch(T){Te(n,n.return,T)}if(n=o,r=n.updateQueue,r!==null){var m=n.stateNode;try{var j=r.shared.hiddenCallbacks;if(j!==null)for(r.shared.hiddenCallbacks=null,r=0;r<j.length;r++)Pf(j[r],m)}catch(T){Te(n,n.return,T)}}a&&d&64&&up(o),vl(o,o.return);break;case 27:pp(o);case 26:case 5:Ea(r,o,a),a&&n===null&&d&4&&fp(o),vl(o,o.return);break;case 12:Ea(r,o,a);break;case 31:Ea(r,o,a),a&&d&4&&bp(r,o);break;case 13:Ea(r,o,a),a&&d&4&&vp(r,o);break;case 22:o.memoizedState===null&&Ea(r,o,a),vl(o,o.return);break;case 30:break;default:Ea(r,o,a)}t=t.sibling}}function Bc(e,t){var a=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(a=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==a&&(e!=null&&e.refCount++,a!=null&&rl(a))}function Lc(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&rl(e))}function Pt(e,t,a,n){if(t.subtreeFlags&10256)for(t=t.child;t!==null;)wp(e,t,a,n),t=t.sibling}function wp(e,t,a,n){var r=t.flags;switch(t.tag){case 0:case 11:case 15:Pt(e,t,a,n),r&2048&&bl(9,t);break;case 1:Pt(e,t,a,n);break;case 3:Pt(e,t,a,n),r&2048&&(e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&rl(e)));break;case 12:if(r&2048){Pt(e,t,a,n),e=t.stateNode;try{var o=t.memoizedProps,d=o.id,m=o.onPostCommit;typeof m=="function"&&m(d,t.alternate===null?"mount":"update",e.passiveEffectDuration,-0)}catch(j){Te(t,t.return,j)}}else Pt(e,t,a,n);break;case 31:Pt(e,t,a,n);break;case 13:Pt(e,t,a,n);break;case 23:break;case 22:o=t.stateNode,d=t.alternate,t.memoizedState!==null?o._visibility&2?Pt(e,t,a,n):jl(e,t):o._visibility&2?Pt(e,t,a,n):(o._visibility|=2,gi(e,t,a,n,(t.subtreeFlags&10256)!==0||!1)),r&2048&&Bc(d,t);break;case 24:Pt(e,t,a,n),r&2048&&Lc(t.alternate,t);break;default:Pt(e,t,a,n)}}function gi(e,t,a,n,r){for(r=r&&((t.subtreeFlags&10256)!==0||!1),t=t.child;t!==null;){var o=e,d=t,m=a,j=n,T=d.flags;switch(d.tag){case 0:case 11:case 15:gi(o,d,m,j,r),bl(8,d);break;case 23:break;case 22:var O=d.stateNode;d.memoizedState!==null?O._visibility&2?gi(o,d,m,j,r):jl(o,d):(O._visibility|=2,gi(o,d,m,j,r)),r&&T&2048&&Bc(d.alternate,d);break;case 24:gi(o,d,m,j,r),r&&T&2048&&Lc(d.alternate,d);break;default:gi(o,d,m,j,r)}t=t.sibling}}function jl(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var a=e,n=t,r=n.flags;switch(n.tag){case 22:jl(a,n),r&2048&&Bc(n.alternate,n);break;case 24:jl(a,n),r&2048&&Lc(n.alternate,n);break;default:jl(a,n)}t=t.sibling}}var Sl=8192;function xi(e,t,a){if(e.subtreeFlags&Sl)for(e=e.child;e!==null;)Cp(e,t,a),e=e.sibling}function Cp(e,t,a){switch(e.tag){case 26:xi(e,t,a),e.flags&Sl&&e.memoizedState!==null&&ty(a,It,e.memoizedState,e.memoizedProps);break;case 5:xi(e,t,a);break;case 3:case 4:var n=It;It=oo(e.stateNode.containerInfo),xi(e,t,a),It=n;break;case 22:e.memoizedState===null&&(n=e.alternate,n!==null&&n.memoizedState!==null?(n=Sl,Sl=16777216,xi(e,t,a),Sl=n):xi(e,t,a));break;default:xi(e,t,a)}}function Ap(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function wl(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var a=0;a<t.length;a++){var n=t[a];it=n,Ep(n,e)}Ap(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)zp(e),e=e.sibling}function zp(e){switch(e.tag){case 0:case 11:case 15:wl(e),e.flags&2048&&Ja(9,e,e.return);break;case 3:wl(e);break;case 12:wl(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,Zr(e)):wl(e);break;default:wl(e)}}function Zr(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var a=0;a<t.length;a++){var n=t[a];it=n,Ep(n,e)}Ap(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Ja(8,t,t.return),Zr(t);break;case 22:a=t.stateNode,a._visibility&2&&(a._visibility&=-3,Zr(t));break;default:Zr(t)}e=e.sibling}}function Ep(e,t){for(;it!==null;){var a=it;switch(a.tag){case 0:case 11:case 15:Ja(8,a,t);break;case 23:case 22:if(a.memoizedState!==null&&a.memoizedState.cachePool!==null){var n=a.memoizedState.cachePool.pool;n!=null&&n.refCount++}break;case 24:rl(a.memoizedState.cache)}if(n=a.child,n!==null)n.return=a,it=n;else e:for(a=e;it!==null;){n=it;var r=n.sibling,o=n.return;if(xp(n),n===a){it=null;break e}if(r!==null){r.return=o,it=r;break e}it=o}}}var gx={getCacheForType:function(e){var t=st(Je),a=t.data.get(e);return a===void 0&&(a=e(),t.data.set(e,a)),a},cacheSignal:function(){return st(Je).controller.signal}},xx=typeof WeakMap=="function"?WeakMap:Map,Ce=0,De=null,pe=null,ge=0,Ee=0,Rt=null,Fa=!1,yi=!1,qc=!1,Ta=0,Ge=0,Ia=0,On=0,Yc=0,_t=0,bi=0,Cl=null,vt=null,$c=!1,Wr=0,Tp=0,Jr=1/0,Fr=null,Pa=null,tt=0,en=null,vi=null,Na=0,Gc=0,Qc=null,Np=null,Al=0,Vc=null;function Mt(){return(Ce&2)!==0&&ge!==0?ge&-ge:M.T!==null?Fc():Qd()}function kp(){if(_t===0)if((ge&536870912)===0||ye){var e=lr;lr<<=1,(lr&3932160)===0&&(lr=262144),_t=e}else _t=536870912;return e=Nt.current,e!==null&&(e.flags|=32),_t}function jt(e,t,a){(e===De&&(Ee===2||Ee===9)||e.cancelPendingCommit!==null)&&(ji(e,0),tn(e,ge,_t,!1)),Xi(e,a),((Ce&2)===0||e!==De)&&(e===De&&((Ce&2)===0&&(On|=a),Ge===4&&tn(e,ge,_t,!1)),da(e))}function Rp(e,t,a){if((Ce&6)!==0)throw Error(c(327));var n=!a&&(t&127)===0&&(t&e.expiredLanes)===0||Vi(e,t),r=n?vx(e,t):Kc(e,t,!0),o=n;do{if(r===0){yi&&!n&&tn(e,t,0,!1);break}else{if(a=e.current.alternate,o&&!yx(a)){r=Kc(e,t,!1),o=!1;continue}if(r===2){if(o=t,e.errorRecoveryDisabledLanes&o)var d=0;else d=e.pendingLanes&-536870913,d=d!==0?d:d&536870912?536870912:0;if(d!==0){t=d;e:{var m=e;r=Cl;var j=m.current.memoizedState.isDehydrated;if(j&&(ji(m,d).flags|=256),d=Kc(m,d,!1),d!==2){if(qc&&!j){m.errorRecoveryDisabledLanes|=o,On|=o,r=4;break e}o=vt,vt=r,o!==null&&(vt===null?vt=o:vt.push.apply(vt,o))}r=d}if(o=!1,r!==2)continue}}if(r===1){ji(e,0),tn(e,t,0,!0);break}e:{switch(n=e,o=r,o){case 0:case 1:throw Error(c(345));case 4:if((t&4194048)!==t)break;case 6:tn(n,t,_t,!Fa);break e;case 2:vt=null;break;case 3:case 5:break;default:throw Error(c(329))}if((t&62914560)===t&&(r=Wr+300-Ct(),10<r)){if(tn(n,t,_t,!Fa),or(n,0,!0)!==0)break e;Na=t,n.timeoutHandle=s0(_p.bind(null,n,a,vt,Fr,$c,t,_t,On,bi,Fa,o,"Throttled",-0,0),r);break e}_p(n,a,vt,Fr,$c,t,_t,On,bi,Fa,o,null,-0,0)}}break}while(!0);da(e)}function _p(e,t,a,n,r,o,d,m,j,T,O,L,N,R){if(e.timeoutHandle=-1,L=t.subtreeFlags,L&8192||(L&16785408)===16785408){L={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:pa},Cp(t,o,L);var P=(o&62914560)===o?Wr-Ct():(o&4194048)===o?Tp-Ct():0;if(P=ay(L,P),P!==null){Na=o,e.cancelPendingCommit=P(qp.bind(null,e,t,o,a,n,r,d,m,j,O,L,null,N,R)),tn(e,o,d,!T);return}}qp(e,t,o,a,n,r,d,m,j)}function yx(e){for(var t=e;;){var a=t.tag;if((a===0||a===11||a===15)&&t.flags&16384&&(a=t.updateQueue,a!==null&&(a=a.stores,a!==null)))for(var n=0;n<a.length;n++){var r=a[n],o=r.getSnapshot;r=r.value;try{if(!Et(o(),r))return!1}catch{return!1}}if(a=t.child,t.subtreeFlags&16384&&a!==null)a.return=t,t=a;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function tn(e,t,a,n){t&=~Yc,t&=~On,e.suspendedLanes|=t,e.pingedLanes&=~t,n&&(e.warmLanes|=t),n=e.expirationTimes;for(var r=t;0<r;){var o=31-zt(r),d=1<<o;n[o]=-1,r&=~d}a!==0&&Yd(e,a,t)}function Ir(){return(Ce&6)===0?(zl(0),!1):!0}function Xc(){if(pe!==null){if(Ee===0)var e=pe.return;else e=pe,ya=zn=null,sc(e),di=null,sl=0,e=pe;for(;e!==null;)cp(e.alternate,e),e=e.return;pe=null}}function ji(e,t){var a=e.timeoutHandle;a!==-1&&(e.timeoutHandle=-1,Bx(a)),a=e.cancelPendingCommit,a!==null&&(e.cancelPendingCommit=null,a()),Na=0,Xc(),De=e,pe=a=ga(e.current,null),ge=t,Ee=0,Rt=null,Fa=!1,yi=Vi(e,t),qc=!1,bi=_t=Yc=On=Ia=Ge=0,vt=Cl=null,$c=!1,(t&8)!==0&&(t|=t&32);var n=e.entangledLanes;if(n!==0)for(e=e.entanglements,n&=t;0<n;){var r=31-zt(n),o=1<<r;t|=e[r],n&=~o}return Ta=t,br(),a}function Mp(e,t){se=null,M.H=gl,t===ui||t===Er?(t=Wf(),Ee=3):t===Js?(t=Wf(),Ee=4):Ee=t===Cc?8:t!==null&&typeof t=="object"&&typeof t.then=="function"?6:1,Rt=t,pe===null&&(Ge=1,Yr(e,Lt(t,e.current)))}function Dp(){var e=Nt.current;return e===null?!0:(ge&4194048)===ge?Gt===null:(ge&62914560)===ge||(ge&536870912)!==0?e===Gt:!1}function Op(){var e=M.H;return M.H=gl,e===null?gl:e}function Hp(){var e=M.A;return M.A=gx,e}function Pr(){Ge=4,Fa||(ge&4194048)!==ge&&Nt.current!==null||(yi=!0),(Ia&134217727)===0&&(On&134217727)===0||De===null||tn(De,ge,_t,!1)}function Kc(e,t,a){var n=Ce;Ce|=2;var r=Op(),o=Hp();(De!==e||ge!==t)&&(Fr=null,ji(e,t)),t=!1;var d=Ge;e:do try{if(Ee!==0&&pe!==null){var m=pe,j=Rt;switch(Ee){case 8:Xc(),d=6;break e;case 3:case 2:case 9:case 6:Nt.current===null&&(t=!0);var T=Ee;if(Ee=0,Rt=null,Si(e,m,j,T),a&&yi){d=0;break e}break;default:T=Ee,Ee=0,Rt=null,Si(e,m,j,T)}}bx(),d=Ge;break}catch(O){Mp(e,O)}while(!0);return t&&e.shellSuspendCounter++,ya=zn=null,Ce=n,M.H=r,M.A=o,pe===null&&(De=null,ge=0,br()),d}function bx(){for(;pe!==null;)Up(pe)}function vx(e,t){var a=Ce;Ce|=2;var n=Op(),r=Hp();De!==e||ge!==t?(Fr=null,Jr=Ct()+500,ji(e,t)):yi=Vi(e,t);e:do try{if(Ee!==0&&pe!==null){t=pe;var o=Rt;t:switch(Ee){case 1:Ee=0,Rt=null,Si(e,t,o,1);break;case 2:case 9:if(Kf(o)){Ee=0,Rt=null,Bp(t);break}t=function(){Ee!==2&&Ee!==9||De!==e||(Ee=7),da(e)},o.then(t,t);break e;case 3:Ee=7;break e;case 4:Ee=5;break e;case 7:Kf(o)?(Ee=0,Rt=null,Bp(t)):(Ee=0,Rt=null,Si(e,t,o,7));break;case 5:var d=null;switch(pe.tag){case 26:d=pe.memoizedState;case 5:case 27:var m=pe;if(d?w0(d):m.stateNode.complete){Ee=0,Rt=null;var j=m.sibling;if(j!==null)pe=j;else{var T=m.return;T!==null?(pe=T,eo(T)):pe=null}break t}}Ee=0,Rt=null,Si(e,t,o,5);break;case 6:Ee=0,Rt=null,Si(e,t,o,6);break;case 8:Xc(),Ge=6;break e;default:throw Error(c(462))}}jx();break}catch(O){Mp(e,O)}while(!0);return ya=zn=null,M.H=n,M.A=r,Ce=a,pe!==null?0:(De=null,ge=0,br(),Ge)}function jx(){for(;pe!==null&&!Qg();)Up(pe)}function Up(e){var t=op(e.alternate,e,Ta);e.memoizedProps=e.pendingProps,t===null?eo(e):pe=t}function Bp(e){var t=e,a=t.alternate;switch(t.tag){case 15:case 0:t=tp(a,t,t.pendingProps,t.type,void 0,ge);break;case 11:t=tp(a,t,t.pendingProps,t.type.render,t.ref,ge);break;case 5:sc(t);default:cp(a,t),t=pe=Hf(t,Ta),t=op(a,t,Ta)}e.memoizedProps=e.pendingProps,t===null?eo(e):pe=t}function Si(e,t,a,n){ya=zn=null,sc(t),di=null,sl=0;var r=t.return;try{if(cx(e,r,t,a,ge)){Ge=1,Yr(e,Lt(a,e.current)),pe=null;return}}catch(o){if(r!==null)throw pe=r,o;Ge=1,Yr(e,Lt(a,e.current)),pe=null;return}t.flags&32768?(ye||n===1?e=!0:yi||(ge&536870912)!==0?e=!1:(Fa=e=!0,(n===2||n===9||n===3||n===6)&&(n=Nt.current,n!==null&&n.tag===13&&(n.flags|=16384))),Lp(t,e)):eo(t)}function eo(e){var t=e;do{if((t.flags&32768)!==0){Lp(t,Fa);return}e=t.return;var a=fx(t.alternate,t,Ta);if(a!==null){pe=a;return}if(t=t.sibling,t!==null){pe=t;return}pe=t=e}while(t!==null);Ge===0&&(Ge=5)}function Lp(e,t){do{var a=hx(e.alternate,e);if(a!==null){a.flags&=32767,pe=a;return}if(a=e.return,a!==null&&(a.flags|=32768,a.subtreeFlags=0,a.deletions=null),!t&&(e=e.sibling,e!==null)){pe=e;return}pe=e=a}while(e!==null);Ge=6,pe=null}function qp(e,t,a,n,r,o,d,m,j){e.cancelPendingCommit=null;do to();while(tt!==0);if((Ce&6)!==0)throw Error(c(327));if(t!==null){if(t===e.current)throw Error(c(177));if(o=t.lanes|t.childLanes,o|=Os,e1(e,a,o,d,m,j),e===De&&(pe=De=null,ge=0),vi=t,en=e,Na=a,Gc=o,Qc=r,Np=n,(t.subtreeFlags&10256)!==0||(t.flags&10256)!==0?(e.callbackNode=null,e.callbackPriority=0,Ax(nr,function(){return Vp(),null})):(e.callbackNode=null,e.callbackPriority=0),n=(t.flags&13878)!==0,(t.subtreeFlags&13878)!==0||n){n=M.T,M.T=null,r=X.p,X.p=2,d=Ce,Ce|=4;try{px(e,t,a)}finally{Ce=d,X.p=r,M.T=n}}tt=1,Yp(),$p(),Gp()}}function Yp(){if(tt===1){tt=0;var e=en,t=vi,a=(t.flags&13878)!==0;if((t.subtreeFlags&13878)!==0||a){a=M.T,M.T=null;var n=X.p;X.p=2;var r=Ce;Ce|=4;try{jp(t,e);var o=lu,d=Ef(e.containerInfo),m=o.focusedElem,j=o.selectionRange;if(d!==m&&m&&m.ownerDocument&&zf(m.ownerDocument.documentElement,m)){if(j!==null&&ks(m)){var T=j.start,O=j.end;if(O===void 0&&(O=T),"selectionStart"in m)m.selectionStart=T,m.selectionEnd=Math.min(O,m.value.length);else{var L=m.ownerDocument||document,N=L&&L.defaultView||window;if(N.getSelection){var R=N.getSelection(),P=m.textContent.length,le=Math.min(j.start,P),_e=j.end===void 0?le:Math.min(j.end,P);!R.extend&&le>_e&&(d=_e,_e=le,le=d);var z=Af(m,le),S=Af(m,_e);if(z&&S&&(R.rangeCount!==1||R.anchorNode!==z.node||R.anchorOffset!==z.offset||R.focusNode!==S.node||R.focusOffset!==S.offset)){var E=L.createRange();E.setStart(z.node,z.offset),R.removeAllRanges(),le>_e?(R.addRange(E),R.extend(S.node,S.offset)):(E.setEnd(S.node,S.offset),R.addRange(E))}}}}for(L=[],R=m;R=R.parentNode;)R.nodeType===1&&L.push({element:R,left:R.scrollLeft,top:R.scrollTop});for(typeof m.focus=="function"&&m.focus(),m=0;m<L.length;m++){var B=L[m];B.element.scrollLeft=B.left,B.element.scrollTop=B.top}}po=!!iu,lu=iu=null}finally{Ce=r,X.p=n,M.T=a}}e.current=t,tt=2}}function $p(){if(tt===2){tt=0;var e=en,t=vi,a=(t.flags&8772)!==0;if((t.subtreeFlags&8772)!==0||a){a=M.T,M.T=null;var n=X.p;X.p=2;var r=Ce;Ce|=4;try{gp(e,t.alternate,t)}finally{Ce=r,X.p=n,M.T=a}}tt=3}}function Gp(){if(tt===4||tt===3){tt=0,Vg();var e=en,t=vi,a=Na,n=Np;(t.subtreeFlags&10256)!==0||(t.flags&10256)!==0?tt=5:(tt=0,vi=en=null,Qp(e,e.pendingLanes));var r=e.pendingLanes;if(r===0&&(Pa=null),ds(a),t=t.stateNode,At&&typeof At.onCommitFiberRoot=="function")try{At.onCommitFiberRoot(Qi,t,void 0,(t.current.flags&128)===128)}catch{}if(n!==null){t=M.T,r=X.p,X.p=2,M.T=null;try{for(var o=e.onRecoverableError,d=0;d<n.length;d++){var m=n[d];o(m.value,{componentStack:m.stack})}}finally{M.T=t,X.p=r}}(Na&3)!==0&&to(),da(e),r=e.pendingLanes,(a&261930)!==0&&(r&42)!==0?e===Vc?Al++:(Al=0,Vc=e):Al=0,zl(0)}}function Qp(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,rl(t)))}function to(){return Yp(),$p(),Gp(),Vp()}function Vp(){if(tt!==5)return!1;var e=en,t=Gc;Gc=0;var a=ds(Na),n=M.T,r=X.p;try{X.p=32>a?32:a,M.T=null,a=Qc,Qc=null;var o=en,d=Na;if(tt=0,vi=en=null,Na=0,(Ce&6)!==0)throw Error(c(331));var m=Ce;if(Ce|=4,zp(o.current),wp(o,o.current,d,a),Ce=m,zl(0,!1),At&&typeof At.onPostCommitFiberRoot=="function")try{At.onPostCommitFiberRoot(Qi,o)}catch{}return!0}finally{X.p=r,M.T=n,Qp(e,t)}}function Xp(e,t,a){t=Lt(a,t),t=wc(e.stateNode,t,2),e=Ka(e,t,2),e!==null&&(Xi(e,2),da(e))}function Te(e,t,a){if(e.tag===3)Xp(e,e,a);else for(;t!==null;){if(t.tag===3){Xp(t,e,a);break}else if(t.tag===1){var n=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof n.componentDidCatch=="function"&&(Pa===null||!Pa.has(n))){e=Lt(a,e),a=Kh(2),n=Ka(t,a,2),n!==null&&(Zh(a,n,t,e),Xi(n,2),da(n));break}}t=t.return}}function Zc(e,t,a){var n=e.pingCache;if(n===null){n=e.pingCache=new xx;var r=new Set;n.set(t,r)}else r=n.get(t),r===void 0&&(r=new Set,n.set(t,r));r.has(a)||(qc=!0,r.add(a),e=Sx.bind(null,e,t,a),t.then(e,e))}function Sx(e,t,a){var n=e.pingCache;n!==null&&n.delete(t),e.pingedLanes|=e.suspendedLanes&a,e.warmLanes&=~a,De===e&&(ge&a)===a&&(Ge===4||Ge===3&&(ge&62914560)===ge&&300>Ct()-Wr?(Ce&2)===0&&ji(e,0):Yc|=a,bi===ge&&(bi=0)),da(e)}function Kp(e,t){t===0&&(t=qd()),e=wn(e,t),e!==null&&(Xi(e,t),da(e))}function wx(e){var t=e.memoizedState,a=0;t!==null&&(a=t.retryLane),Kp(e,a)}function Cx(e,t){var a=0;switch(e.tag){case 31:case 13:var n=e.stateNode,r=e.memoizedState;r!==null&&(a=r.retryLane);break;case 19:n=e.stateNode;break;case 22:n=e.stateNode._retryCache;break;default:throw Error(c(314))}n!==null&&n.delete(t),Kp(e,a)}function Ax(e,t){return os(e,t)}var ao=null,wi=null,Wc=!1,no=!1,Jc=!1,an=0;function da(e){e!==wi&&e.next===null&&(wi===null?ao=wi=e:wi=wi.next=e),no=!0,Wc||(Wc=!0,Ex())}function zl(e,t){if(!Jc&&no){Jc=!0;do for(var a=!1,n=ao;n!==null;){if(e!==0){var r=n.pendingLanes;if(r===0)var o=0;else{var d=n.suspendedLanes,m=n.pingedLanes;o=(1<<31-zt(42|e)+1)-1,o&=r&~(d&~m),o=o&201326741?o&201326741|1:o?o|2:0}o!==0&&(a=!0,Fp(n,o))}else o=ge,o=or(n,n===De?o:0,n.cancelPendingCommit!==null||n.timeoutHandle!==-1),(o&3)===0||Vi(n,o)||(a=!0,Fp(n,o));n=n.next}while(a);Jc=!1}}function zx(){Zp()}function Zp(){no=Wc=!1;var e=0;an!==0&&Ux()&&(e=an);for(var t=Ct(),a=null,n=ao;n!==null;){var r=n.next,o=Wp(n,t);o===0?(n.next=null,a===null?ao=r:a.next=r,r===null&&(wi=a)):(a=n,(e!==0||(o&3)!==0)&&(no=!0)),n=r}tt!==0&&tt!==5||zl(e),an!==0&&(an=0)}function Wp(e,t){for(var a=e.suspendedLanes,n=e.pingedLanes,r=e.expirationTimes,o=e.pendingLanes&-62914561;0<o;){var d=31-zt(o),m=1<<d,j=r[d];j===-1?((m&a)===0||(m&n)!==0)&&(r[d]=Pg(m,t)):j<=t&&(e.expiredLanes|=m),o&=~m}if(t=De,a=ge,a=or(e,e===t?a:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),n=e.callbackNode,a===0||e===t&&(Ee===2||Ee===9)||e.cancelPendingCommit!==null)return n!==null&&n!==null&&ss(n),e.callbackNode=null,e.callbackPriority=0;if((a&3)===0||Vi(e,a)){if(t=a&-a,t===e.callbackPriority)return t;switch(n!==null&&ss(n),ds(a)){case 2:case 8:a=Bd;break;case 32:a=nr;break;case 268435456:a=Ld;break;default:a=nr}return n=Jp.bind(null,e),a=os(a,n),e.callbackPriority=t,e.callbackNode=a,t}return n!==null&&n!==null&&ss(n),e.callbackPriority=2,e.callbackNode=null,2}function Jp(e,t){if(tt!==0&&tt!==5)return e.callbackNode=null,e.callbackPriority=0,null;var a=e.callbackNode;if(to()&&e.callbackNode!==a)return null;var n=ge;return n=or(e,e===De?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),n===0?null:(Rp(e,n,t),Wp(e,Ct()),e.callbackNode!=null&&e.callbackNode===a?Jp.bind(null,e):null)}function Fp(e,t){if(to())return null;Rp(e,t,!0)}function Ex(){Lx(function(){(Ce&6)!==0?os(Ud,zx):Zp()})}function Fc(){if(an===0){var e=si;e===0&&(e=ir,ir<<=1,(ir&261888)===0&&(ir=256)),an=e}return an}function Ip(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:dr(""+e)}function Pp(e,t){var a=t.ownerDocument.createElement("input");return a.name=t.name,a.value=t.value,e.id&&a.setAttribute("form",e.id),t.parentNode.insertBefore(a,t),e=new FormData(e),a.parentNode.removeChild(a),e}function Tx(e,t,a,n,r){if(t==="submit"&&a&&a.stateNode===r){var o=Ip((r[mt]||null).action),d=n.submitter;d&&(t=(t=d[mt]||null)?Ip(t.formAction):d.getAttribute("formAction"),t!==null&&(o=t,d=null));var m=new mr("action","action",null,n,r);e.push({event:m,listeners:[{instance:null,listener:function(){if(n.defaultPrevented){if(an!==0){var j=d?Pp(r,d):new FormData(r);xc(a,{pending:!0,data:j,method:r.method,action:o},null,j)}}else typeof o=="function"&&(m.preventDefault(),j=d?Pp(r,d):new FormData(r),xc(a,{pending:!0,data:j,method:r.method,action:o},o,j))},currentTarget:r}]})}}for(var Ic=0;Ic<Ds.length;Ic++){var Pc=Ds[Ic],Nx=Pc.toLowerCase(),kx=Pc[0].toUpperCase()+Pc.slice(1);Ft(Nx,"on"+kx)}Ft(kf,"onAnimationEnd"),Ft(Rf,"onAnimationIteration"),Ft(_f,"onAnimationStart"),Ft("dblclick","onDoubleClick"),Ft("focusin","onFocus"),Ft("focusout","onBlur"),Ft(X1,"onTransitionRun"),Ft(K1,"onTransitionStart"),Ft(Z1,"onTransitionCancel"),Ft(Mf,"onTransitionEnd"),Zn("onMouseEnter",["mouseout","mouseover"]),Zn("onMouseLeave",["mouseout","mouseover"]),Zn("onPointerEnter",["pointerout","pointerover"]),Zn("onPointerLeave",["pointerout","pointerover"]),bn("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),bn("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),bn("onBeforeInput",["compositionend","keypress","textInput","paste"]),bn("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),bn("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),bn("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var El="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Rx=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(El));function e0(e,t){t=(t&4)!==0;for(var a=0;a<e.length;a++){var n=e[a],r=n.event;n=n.listeners;e:{var o=void 0;if(t)for(var d=n.length-1;0<=d;d--){var m=n[d],j=m.instance,T=m.currentTarget;if(m=m.listener,j!==o&&r.isPropagationStopped())break e;o=m,r.currentTarget=T;try{o(r)}catch(O){yr(O)}r.currentTarget=null,o=j}else for(d=0;d<n.length;d++){if(m=n[d],j=m.instance,T=m.currentTarget,m=m.listener,j!==o&&r.isPropagationStopped())break e;o=m,r.currentTarget=T;try{o(r)}catch(O){yr(O)}r.currentTarget=null,o=j}}}}function me(e,t){var a=t[fs];a===void 0&&(a=t[fs]=new Set);var n=e+"__bubble";a.has(n)||(t0(t,e,2,!1),a.add(n))}function eu(e,t,a){var n=0;t&&(n|=4),t0(a,e,n,t)}var io="_reactListening"+Math.random().toString(36).slice(2);function tu(e){if(!e[io]){e[io]=!0,Kd.forEach(function(a){a!=="selectionchange"&&(Rx.has(a)||eu(a,!1,e),eu(a,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[io]||(t[io]=!0,eu("selectionchange",!1,t))}}function t0(e,t,a,n){switch(k0(t)){case 2:var r=ly;break;case 8:r=ry;break;default:r=gu}a=r.bind(null,t,a,e),r=void 0,!js||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(r=!0),n?r!==void 0?e.addEventListener(t,a,{capture:!0,passive:r}):e.addEventListener(t,a,!0):r!==void 0?e.addEventListener(t,a,{passive:r}):e.addEventListener(t,a,!1)}function au(e,t,a,n,r){var o=n;if((t&1)===0&&(t&2)===0&&n!==null)e:for(;;){if(n===null)return;var d=n.tag;if(d===3||d===4){var m=n.stateNode.containerInfo;if(m===r)break;if(d===4)for(d=n.return;d!==null;){var j=d.tag;if((j===3||j===4)&&d.stateNode.containerInfo===r)return;d=d.return}for(;m!==null;){if(d=Vn(m),d===null)return;if(j=d.tag,j===5||j===6||j===26||j===27){n=o=d;continue e}m=m.parentNode}}n=n.return}rf(function(){var T=o,O=bs(a),L=[];e:{var N=Df.get(e);if(N!==void 0){var R=mr,P=e;switch(e){case"keypress":if(hr(a)===0)break e;case"keydown":case"keyup":R=C1;break;case"focusin":P="focus",R=As;break;case"focusout":P="blur",R=As;break;case"beforeblur":case"afterblur":R=As;break;case"click":if(a.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":R=cf;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":R=f1;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":R=E1;break;case kf:case Rf:case _f:R=m1;break;case Mf:R=N1;break;case"scroll":case"scrollend":R=u1;break;case"wheel":R=R1;break;case"copy":case"cut":case"paste":R=x1;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":R=df;break;case"toggle":case"beforetoggle":R=M1}var le=(t&4)!==0,_e=!le&&(e==="scroll"||e==="scrollend"),z=le?N!==null?N+"Capture":null:N;le=[];for(var S=T,E;S!==null;){var B=S;if(E=B.stateNode,B=B.tag,B!==5&&B!==26&&B!==27||E===null||z===null||(B=Wi(S,z),B!=null&&le.push(Tl(S,B,E))),_e)break;S=S.return}0<le.length&&(N=new R(N,P,null,a,O),L.push({event:N,listeners:le}))}}if((t&7)===0){e:{if(N=e==="mouseover"||e==="pointerover",R=e==="mouseout"||e==="pointerout",N&&a!==ys&&(P=a.relatedTarget||a.fromElement)&&(Vn(P)||P[Qn]))break e;if((R||N)&&(N=O.window===O?O:(N=O.ownerDocument)?N.defaultView||N.parentWindow:window,R?(P=a.relatedTarget||a.toElement,R=T,P=P?Vn(P):null,P!==null&&(_e=p(P),le=P.tag,P!==_e||le!==5&&le!==27&&le!==6)&&(P=null)):(R=null,P=T),R!==P)){if(le=cf,B="onMouseLeave",z="onMouseEnter",S="mouse",(e==="pointerout"||e==="pointerover")&&(le=df,B="onPointerLeave",z="onPointerEnter",S="pointer"),_e=R==null?N:Zi(R),E=P==null?N:Zi(P),N=new le(B,S+"leave",R,a,O),N.target=_e,N.relatedTarget=E,B=null,Vn(O)===T&&(le=new le(z,S+"enter",P,a,O),le.target=E,le.relatedTarget=_e,B=le),_e=B,R&&P)t:{for(le=_x,z=R,S=P,E=0,B=z;B;B=le(B))E++;B=0;for(var ne=S;ne;ne=le(ne))B++;for(;0<E-B;)z=le(z),E--;for(;0<B-E;)S=le(S),B--;for(;E--;){if(z===S||S!==null&&z===S.alternate){le=z;break t}z=le(z),S=le(S)}le=null}else le=null;R!==null&&a0(L,N,R,le,!1),P!==null&&_e!==null&&a0(L,_e,P,le,!0)}}e:{if(N=T?Zi(T):window,R=N.nodeName&&N.nodeName.toLowerCase(),R==="select"||R==="input"&&N.type==="file")var Se=bf;else if(xf(N))if(vf)Se=G1;else{Se=Y1;var ae=q1}else R=N.nodeName,!R||R.toLowerCase()!=="input"||N.type!=="checkbox"&&N.type!=="radio"?T&&xs(T.elementType)&&(Se=bf):Se=$1;if(Se&&(Se=Se(e,T))){yf(L,Se,a,O);break e}ae&&ae(e,N,T),e==="focusout"&&T&&N.type==="number"&&T.memoizedProps.value!=null&&gs(N,"number",N.value)}switch(ae=T?Zi(T):window,e){case"focusin":(xf(ae)||ae.contentEditable==="true")&&(ei=ae,Rs=T,nl=null);break;case"focusout":nl=Rs=ei=null;break;case"mousedown":_s=!0;break;case"contextmenu":case"mouseup":case"dragend":_s=!1,Tf(L,a,O);break;case"selectionchange":if(V1)break;case"keydown":case"keyup":Tf(L,a,O)}var ue;if(Es)e:{switch(e){case"compositionstart":var xe="onCompositionStart";break e;case"compositionend":xe="onCompositionEnd";break e;case"compositionupdate":xe="onCompositionUpdate";break e}xe=void 0}else Pn?mf(e,a)&&(xe="onCompositionEnd"):e==="keydown"&&a.keyCode===229&&(xe="onCompositionStart");xe&&(ff&&a.locale!=="ko"&&(Pn||xe!=="onCompositionStart"?xe==="onCompositionEnd"&&Pn&&(ue=of()):(qa=O,Ss="value"in qa?qa.value:qa.textContent,Pn=!0)),ae=lo(T,xe),0<ae.length&&(xe=new uf(xe,e,null,a,O),L.push({event:xe,listeners:ae}),ue?xe.data=ue:(ue=gf(a),ue!==null&&(xe.data=ue)))),(ue=O1?H1(e,a):U1(e,a))&&(xe=lo(T,"onBeforeInput"),0<xe.length&&(ae=new uf("onBeforeInput","beforeinput",null,a,O),L.push({event:ae,listeners:xe}),ae.data=ue)),Tx(L,e,T,a,O)}e0(L,t)})}function Tl(e,t,a){return{instance:e,listener:t,currentTarget:a}}function lo(e,t){for(var a=t+"Capture",n=[];e!==null;){var r=e,o=r.stateNode;if(r=r.tag,r!==5&&r!==26&&r!==27||o===null||(r=Wi(e,a),r!=null&&n.unshift(Tl(e,r,o)),r=Wi(e,t),r!=null&&n.push(Tl(e,r,o))),e.tag===3)return n;e=e.return}return[]}function _x(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function a0(e,t,a,n,r){for(var o=t._reactName,d=[];a!==null&&a!==n;){var m=a,j=m.alternate,T=m.stateNode;if(m=m.tag,j!==null&&j===n)break;m!==5&&m!==26&&m!==27||T===null||(j=T,r?(T=Wi(a,o),T!=null&&d.unshift(Tl(a,T,j))):r||(T=Wi(a,o),T!=null&&d.push(Tl(a,T,j)))),a=a.return}d.length!==0&&e.push({event:t,listeners:d})}var Mx=/\r\n?/g,Dx=/\u0000|\uFFFD/g;function n0(e){return(typeof e=="string"?e:""+e).replace(Mx,`
`).replace(Dx,"")}function i0(e,t){return t=n0(t),n0(e)===t}function Re(e,t,a,n,r,o){switch(a){case"children":typeof n=="string"?t==="body"||t==="textarea"&&n===""||Jn(e,n):(typeof n=="number"||typeof n=="bigint")&&t!=="body"&&Jn(e,""+n);break;case"className":cr(e,"class",n);break;case"tabIndex":cr(e,"tabindex",n);break;case"dir":case"role":case"viewBox":case"width":case"height":cr(e,a,n);break;case"style":nf(e,n,o);break;case"data":if(t!=="object"){cr(e,"data",n);break}case"src":case"href":if(n===""&&(t!=="a"||a!=="href")){e.removeAttribute(a);break}if(n==null||typeof n=="function"||typeof n=="symbol"||typeof n=="boolean"){e.removeAttribute(a);break}n=dr(""+n),e.setAttribute(a,n);break;case"action":case"formAction":if(typeof n=="function"){e.setAttribute(a,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof o=="function"&&(a==="formAction"?(t!=="input"&&Re(e,t,"name",r.name,r,null),Re(e,t,"formEncType",r.formEncType,r,null),Re(e,t,"formMethod",r.formMethod,r,null),Re(e,t,"formTarget",r.formTarget,r,null)):(Re(e,t,"encType",r.encType,r,null),Re(e,t,"method",r.method,r,null),Re(e,t,"target",r.target,r,null)));if(n==null||typeof n=="symbol"||typeof n=="boolean"){e.removeAttribute(a);break}n=dr(""+n),e.setAttribute(a,n);break;case"onClick":n!=null&&(e.onclick=pa);break;case"onScroll":n!=null&&me("scroll",e);break;case"onScrollEnd":n!=null&&me("scrollend",e);break;case"dangerouslySetInnerHTML":if(n!=null){if(typeof n!="object"||!("__html"in n))throw Error(c(61));if(a=n.__html,a!=null){if(r.children!=null)throw Error(c(60));e.innerHTML=a}}break;case"multiple":e.multiple=n&&typeof n!="function"&&typeof n!="symbol";break;case"muted":e.muted=n&&typeof n!="function"&&typeof n!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(n==null||typeof n=="function"||typeof n=="boolean"||typeof n=="symbol"){e.removeAttribute("xlink:href");break}a=dr(""+n),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",a);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":n!=null&&typeof n!="function"&&typeof n!="symbol"?e.setAttribute(a,""+n):e.removeAttribute(a);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":n&&typeof n!="function"&&typeof n!="symbol"?e.setAttribute(a,""):e.removeAttribute(a);break;case"capture":case"download":n===!0?e.setAttribute(a,""):n!==!1&&n!=null&&typeof n!="function"&&typeof n!="symbol"?e.setAttribute(a,n):e.removeAttribute(a);break;case"cols":case"rows":case"size":case"span":n!=null&&typeof n!="function"&&typeof n!="symbol"&&!isNaN(n)&&1<=n?e.setAttribute(a,n):e.removeAttribute(a);break;case"rowSpan":case"start":n==null||typeof n=="function"||typeof n=="symbol"||isNaN(n)?e.removeAttribute(a):e.setAttribute(a,n);break;case"popover":me("beforetoggle",e),me("toggle",e),sr(e,"popover",n);break;case"xlinkActuate":ha(e,"http://www.w3.org/1999/xlink","xlink:actuate",n);break;case"xlinkArcrole":ha(e,"http://www.w3.org/1999/xlink","xlink:arcrole",n);break;case"xlinkRole":ha(e,"http://www.w3.org/1999/xlink","xlink:role",n);break;case"xlinkShow":ha(e,"http://www.w3.org/1999/xlink","xlink:show",n);break;case"xlinkTitle":ha(e,"http://www.w3.org/1999/xlink","xlink:title",n);break;case"xlinkType":ha(e,"http://www.w3.org/1999/xlink","xlink:type",n);break;case"xmlBase":ha(e,"http://www.w3.org/XML/1998/namespace","xml:base",n);break;case"xmlLang":ha(e,"http://www.w3.org/XML/1998/namespace","xml:lang",n);break;case"xmlSpace":ha(e,"http://www.w3.org/XML/1998/namespace","xml:space",n);break;case"is":sr(e,"is",n);break;case"innerText":case"textContent":break;default:(!(2<a.length)||a[0]!=="o"&&a[0]!=="O"||a[1]!=="n"&&a[1]!=="N")&&(a=s1.get(a)||a,sr(e,a,n))}}function nu(e,t,a,n,r,o){switch(a){case"style":nf(e,n,o);break;case"dangerouslySetInnerHTML":if(n!=null){if(typeof n!="object"||!("__html"in n))throw Error(c(61));if(a=n.__html,a!=null){if(r.children!=null)throw Error(c(60));e.innerHTML=a}}break;case"children":typeof n=="string"?Jn(e,n):(typeof n=="number"||typeof n=="bigint")&&Jn(e,""+n);break;case"onScroll":n!=null&&me("scroll",e);break;case"onScrollEnd":n!=null&&me("scrollend",e);break;case"onClick":n!=null&&(e.onclick=pa);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!Zd.hasOwnProperty(a))e:{if(a[0]==="o"&&a[1]==="n"&&(r=a.endsWith("Capture"),t=a.slice(2,r?a.length-7:void 0),o=e[mt]||null,o=o!=null?o[a]:null,typeof o=="function"&&e.removeEventListener(t,o,r),typeof n=="function")){typeof o!="function"&&o!==null&&(a in e?e[a]=null:e.hasAttribute(a)&&e.removeAttribute(a)),e.addEventListener(t,n,r);break e}a in e?e[a]=n:n===!0?e.setAttribute(a,""):sr(e,a,n)}}}function ut(e,t,a){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":me("error",e),me("load",e);var n=!1,r=!1,o;for(o in a)if(a.hasOwnProperty(o)){var d=a[o];if(d!=null)switch(o){case"src":n=!0;break;case"srcSet":r=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(c(137,t));default:Re(e,t,o,d,a,null)}}r&&Re(e,t,"srcSet",a.srcSet,a,null),n&&Re(e,t,"src",a.src,a,null);return;case"input":me("invalid",e);var m=o=d=r=null,j=null,T=null;for(n in a)if(a.hasOwnProperty(n)){var O=a[n];if(O!=null)switch(n){case"name":r=O;break;case"type":d=O;break;case"checked":j=O;break;case"defaultChecked":T=O;break;case"value":o=O;break;case"defaultValue":m=O;break;case"children":case"dangerouslySetInnerHTML":if(O!=null)throw Error(c(137,t));break;default:Re(e,t,n,O,a,null)}}Pd(e,o,m,j,T,d,r,!1);return;case"select":me("invalid",e),n=d=o=null;for(r in a)if(a.hasOwnProperty(r)&&(m=a[r],m!=null))switch(r){case"value":o=m;break;case"defaultValue":d=m;break;case"multiple":n=m;default:Re(e,t,r,m,a,null)}t=o,a=d,e.multiple=!!n,t!=null?Wn(e,!!n,t,!1):a!=null&&Wn(e,!!n,a,!0);return;case"textarea":me("invalid",e),o=r=n=null;for(d in a)if(a.hasOwnProperty(d)&&(m=a[d],m!=null))switch(d){case"value":n=m;break;case"defaultValue":r=m;break;case"children":o=m;break;case"dangerouslySetInnerHTML":if(m!=null)throw Error(c(91));break;default:Re(e,t,d,m,a,null)}tf(e,n,r,o);return;case"option":for(j in a)a.hasOwnProperty(j)&&(n=a[j],n!=null)&&(j==="selected"?e.selected=n&&typeof n!="function"&&typeof n!="symbol":Re(e,t,j,n,a,null));return;case"dialog":me("beforetoggle",e),me("toggle",e),me("cancel",e),me("close",e);break;case"iframe":case"object":me("load",e);break;case"video":case"audio":for(n=0;n<El.length;n++)me(El[n],e);break;case"image":me("error",e),me("load",e);break;case"details":me("toggle",e);break;case"embed":case"source":case"link":me("error",e),me("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(T in a)if(a.hasOwnProperty(T)&&(n=a[T],n!=null))switch(T){case"children":case"dangerouslySetInnerHTML":throw Error(c(137,t));default:Re(e,t,T,n,a,null)}return;default:if(xs(t)){for(O in a)a.hasOwnProperty(O)&&(n=a[O],n!==void 0&&nu(e,t,O,n,a,void 0));return}}for(m in a)a.hasOwnProperty(m)&&(n=a[m],n!=null&&Re(e,t,m,n,a,null))}function Ox(e,t,a,n){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var r=null,o=null,d=null,m=null,j=null,T=null,O=null;for(R in a){var L=a[R];if(a.hasOwnProperty(R)&&L!=null)switch(R){case"checked":break;case"value":break;case"defaultValue":j=L;default:n.hasOwnProperty(R)||Re(e,t,R,null,n,L)}}for(var N in n){var R=n[N];if(L=a[N],n.hasOwnProperty(N)&&(R!=null||L!=null))switch(N){case"type":o=R;break;case"name":r=R;break;case"checked":T=R;break;case"defaultChecked":O=R;break;case"value":d=R;break;case"defaultValue":m=R;break;case"children":case"dangerouslySetInnerHTML":if(R!=null)throw Error(c(137,t));break;default:R!==L&&Re(e,t,N,R,n,L)}}ms(e,d,m,j,T,O,o,r);return;case"select":R=d=m=N=null;for(o in a)if(j=a[o],a.hasOwnProperty(o)&&j!=null)switch(o){case"value":break;case"multiple":R=j;default:n.hasOwnProperty(o)||Re(e,t,o,null,n,j)}for(r in n)if(o=n[r],j=a[r],n.hasOwnProperty(r)&&(o!=null||j!=null))switch(r){case"value":N=o;break;case"defaultValue":m=o;break;case"multiple":d=o;default:o!==j&&Re(e,t,r,o,n,j)}t=m,a=d,n=R,N!=null?Wn(e,!!a,N,!1):!!n!=!!a&&(t!=null?Wn(e,!!a,t,!0):Wn(e,!!a,a?[]:"",!1));return;case"textarea":R=N=null;for(m in a)if(r=a[m],a.hasOwnProperty(m)&&r!=null&&!n.hasOwnProperty(m))switch(m){case"value":break;case"children":break;default:Re(e,t,m,null,n,r)}for(d in n)if(r=n[d],o=a[d],n.hasOwnProperty(d)&&(r!=null||o!=null))switch(d){case"value":N=r;break;case"defaultValue":R=r;break;case"children":break;case"dangerouslySetInnerHTML":if(r!=null)throw Error(c(91));break;default:r!==o&&Re(e,t,d,r,n,o)}ef(e,N,R);return;case"option":for(var P in a)N=a[P],a.hasOwnProperty(P)&&N!=null&&!n.hasOwnProperty(P)&&(P==="selected"?e.selected=!1:Re(e,t,P,null,n,N));for(j in n)N=n[j],R=a[j],n.hasOwnProperty(j)&&N!==R&&(N!=null||R!=null)&&(j==="selected"?e.selected=N&&typeof N!="function"&&typeof N!="symbol":Re(e,t,j,N,n,R));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var le in a)N=a[le],a.hasOwnProperty(le)&&N!=null&&!n.hasOwnProperty(le)&&Re(e,t,le,null,n,N);for(T in n)if(N=n[T],R=a[T],n.hasOwnProperty(T)&&N!==R&&(N!=null||R!=null))switch(T){case"children":case"dangerouslySetInnerHTML":if(N!=null)throw Error(c(137,t));break;default:Re(e,t,T,N,n,R)}return;default:if(xs(t)){for(var _e in a)N=a[_e],a.hasOwnProperty(_e)&&N!==void 0&&!n.hasOwnProperty(_e)&&nu(e,t,_e,void 0,n,N);for(O in n)N=n[O],R=a[O],!n.hasOwnProperty(O)||N===R||N===void 0&&R===void 0||nu(e,t,O,N,n,R);return}}for(var z in a)N=a[z],a.hasOwnProperty(z)&&N!=null&&!n.hasOwnProperty(z)&&Re(e,t,z,null,n,N);for(L in n)N=n[L],R=a[L],!n.hasOwnProperty(L)||N===R||N==null&&R==null||Re(e,t,L,N,n,R)}function l0(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function Hx(){if(typeof performance.getEntriesByType=="function"){for(var e=0,t=0,a=performance.getEntriesByType("resource"),n=0;n<a.length;n++){var r=a[n],o=r.transferSize,d=r.initiatorType,m=r.duration;if(o&&m&&l0(d)){for(d=0,m=r.responseEnd,n+=1;n<a.length;n++){var j=a[n],T=j.startTime;if(T>m)break;var O=j.transferSize,L=j.initiatorType;O&&l0(L)&&(j=j.responseEnd,d+=O*(j<m?1:(m-T)/(j-T)))}if(--n,t+=8*(o+d)/(r.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var iu=null,lu=null;function ro(e){return e.nodeType===9?e:e.ownerDocument}function r0(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function o0(e,t){if(e===0)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&t==="foreignObject"?0:e}function ru(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.children=="bigint"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var ou=null;function Ux(){var e=window.event;return e&&e.type==="popstate"?e===ou?!1:(ou=e,!0):(ou=null,!1)}var s0=typeof setTimeout=="function"?setTimeout:void 0,Bx=typeof clearTimeout=="function"?clearTimeout:void 0,c0=typeof Promise=="function"?Promise:void 0,Lx=typeof queueMicrotask=="function"?queueMicrotask:typeof c0<"u"?function(e){return c0.resolve(null).then(e).catch(qx)}:s0;function qx(e){setTimeout(function(){throw e})}function nn(e){return e==="head"}function u0(e,t){var a=t,n=0;do{var r=a.nextSibling;if(e.removeChild(a),r&&r.nodeType===8)if(a=r.data,a==="/$"||a==="/&"){if(n===0){e.removeChild(r),Ei(t);return}n--}else if(a==="$"||a==="$?"||a==="$~"||a==="$!"||a==="&")n++;else if(a==="html")Nl(e.ownerDocument.documentElement);else if(a==="head"){a=e.ownerDocument.head,Nl(a);for(var o=a.firstChild;o;){var d=o.nextSibling,m=o.nodeName;o[Ki]||m==="SCRIPT"||m==="STYLE"||m==="LINK"&&o.rel.toLowerCase()==="stylesheet"||a.removeChild(o),o=d}}else a==="body"&&Nl(e.ownerDocument.body);a=r}while(a);Ei(t)}function d0(e,t){var a=e;e=0;do{var n=a.nextSibling;if(a.nodeType===1?t?(a._stashedDisplay=a.style.display,a.style.display="none"):(a.style.display=a._stashedDisplay||"",a.getAttribute("style")===""&&a.removeAttribute("style")):a.nodeType===3&&(t?(a._stashedText=a.nodeValue,a.nodeValue=""):a.nodeValue=a._stashedText||""),n&&n.nodeType===8)if(a=n.data,a==="/$"){if(e===0)break;e--}else a!=="$"&&a!=="$?"&&a!=="$~"&&a!=="$!"||e++;a=n}while(a)}function su(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var a=t;switch(t=t.nextSibling,a.nodeName){case"HTML":case"HEAD":case"BODY":su(a),hs(a);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(a.rel.toLowerCase()==="stylesheet")continue}e.removeChild(a)}}function Yx(e,t,a,n){for(;e.nodeType===1;){var r=a;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!n&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(n){if(!e[Ki])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(o=e.getAttribute("rel"),o==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(o!==r.rel||e.getAttribute("href")!==(r.href==null||r.href===""?null:r.href)||e.getAttribute("crossorigin")!==(r.crossOrigin==null?null:r.crossOrigin)||e.getAttribute("title")!==(r.title==null?null:r.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(o=e.getAttribute("src"),(o!==(r.src==null?null:r.src)||e.getAttribute("type")!==(r.type==null?null:r.type)||e.getAttribute("crossorigin")!==(r.crossOrigin==null?null:r.crossOrigin))&&o&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(t==="input"&&e.type==="hidden"){var o=r.name==null?null:""+r.name;if(r.type==="hidden"&&e.getAttribute("name")===o)return e}else return e;if(e=Qt(e.nextSibling),e===null)break}return null}function $x(e,t,a){if(t==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!a||(e=Qt(e.nextSibling),e===null))return null;return e}function f0(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!t||(e=Qt(e.nextSibling),e===null))return null;return e}function cu(e){return e.data==="$?"||e.data==="$~"}function uu(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function Gx(e,t){var a=e.ownerDocument;if(e.data==="$~")e._reactRetry=t;else if(e.data!=="$?"||a.readyState!=="loading")t();else{var n=function(){t(),a.removeEventListener("DOMContentLoaded",n)};a.addEventListener("DOMContentLoaded",n),e._reactRetry=n}}function Qt(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"||t==="F!"||t==="F")break;if(t==="/$"||t==="/&")return null}}return e}var du=null;function h0(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var a=e.data;if(a==="/$"||a==="/&"){if(t===0)return Qt(e.nextSibling);t--}else a!=="$"&&a!=="$!"&&a!=="$?"&&a!=="$~"&&a!=="&"||t++}e=e.nextSibling}return null}function p0(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var a=e.data;if(a==="$"||a==="$!"||a==="$?"||a==="$~"||a==="&"){if(t===0)return e;t--}else a!=="/$"&&a!=="/&"||t++}e=e.previousSibling}return null}function m0(e,t,a){switch(t=ro(a),e){case"html":if(e=t.documentElement,!e)throw Error(c(452));return e;case"head":if(e=t.head,!e)throw Error(c(453));return e;case"body":if(e=t.body,!e)throw Error(c(454));return e;default:throw Error(c(451))}}function Nl(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);hs(e)}var Vt=new Map,g0=new Set;function oo(e){return typeof e.getRootNode=="function"?e.getRootNode():e.nodeType===9?e:e.ownerDocument}var ka=X.d;X.d={f:Qx,r:Vx,D:Xx,C:Kx,L:Zx,m:Wx,X:Fx,S:Jx,M:Ix};function Qx(){var e=ka.f(),t=Ir();return e||t}function Vx(e){var t=Xn(e);t!==null&&t.tag===5&&t.type==="form"?Mh(t):ka.r(e)}var Ci=typeof document>"u"?null:document;function x0(e,t,a){var n=Ci;if(n&&typeof t=="string"&&t){var r=Ut(t);r='link[rel="'+e+'"][href="'+r+'"]',typeof a=="string"&&(r+='[crossorigin="'+a+'"]'),g0.has(r)||(g0.add(r),e={rel:e,crossOrigin:a,href:t},n.querySelector(r)===null&&(t=n.createElement("link"),ut(t,"link",e),nt(t),n.head.appendChild(t)))}}function Xx(e){ka.D(e),x0("dns-prefetch",e,null)}function Kx(e,t){ka.C(e,t),x0("preconnect",e,t)}function Zx(e,t,a){ka.L(e,t,a);var n=Ci;if(n&&e&&t){var r='link[rel="preload"][as="'+Ut(t)+'"]';t==="image"&&a&&a.imageSrcSet?(r+='[imagesrcset="'+Ut(a.imageSrcSet)+'"]',typeof a.imageSizes=="string"&&(r+='[imagesizes="'+Ut(a.imageSizes)+'"]')):r+='[href="'+Ut(e)+'"]';var o=r;switch(t){case"style":o=Ai(e);break;case"script":o=zi(e)}Vt.has(o)||(e=y({rel:"preload",href:t==="image"&&a&&a.imageSrcSet?void 0:e,as:t},a),Vt.set(o,e),n.querySelector(r)!==null||t==="style"&&n.querySelector(kl(o))||t==="script"&&n.querySelector(Rl(o))||(t=n.createElement("link"),ut(t,"link",e),nt(t),n.head.appendChild(t)))}}function Wx(e,t){ka.m(e,t);var a=Ci;if(a&&e){var n=t&&typeof t.as=="string"?t.as:"script",r='link[rel="modulepreload"][as="'+Ut(n)+'"][href="'+Ut(e)+'"]',o=r;switch(n){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":o=zi(e)}if(!Vt.has(o)&&(e=y({rel:"modulepreload",href:e},t),Vt.set(o,e),a.querySelector(r)===null)){switch(n){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(a.querySelector(Rl(o)))return}n=a.createElement("link"),ut(n,"link",e),nt(n),a.head.appendChild(n)}}}function Jx(e,t,a){ka.S(e,t,a);var n=Ci;if(n&&e){var r=Kn(n).hoistableStyles,o=Ai(e);t=t||"default";var d=r.get(o);if(!d){var m={loading:0,preload:null};if(d=n.querySelector(kl(o)))m.loading=5;else{e=y({rel:"stylesheet",href:e,"data-precedence":t},a),(a=Vt.get(o))&&fu(e,a);var j=d=n.createElement("link");nt(j),ut(j,"link",e),j._p=new Promise(function(T,O){j.onload=T,j.onerror=O}),j.addEventListener("load",function(){m.loading|=1}),j.addEventListener("error",function(){m.loading|=2}),m.loading|=4,so(d,t,n)}d={type:"stylesheet",instance:d,count:1,state:m},r.set(o,d)}}}function Fx(e,t){ka.X(e,t);var a=Ci;if(a&&e){var n=Kn(a).hoistableScripts,r=zi(e),o=n.get(r);o||(o=a.querySelector(Rl(r)),o||(e=y({src:e,async:!0},t),(t=Vt.get(r))&&hu(e,t),o=a.createElement("script"),nt(o),ut(o,"link",e),a.head.appendChild(o)),o={type:"script",instance:o,count:1,state:null},n.set(r,o))}}function Ix(e,t){ka.M(e,t);var a=Ci;if(a&&e){var n=Kn(a).hoistableScripts,r=zi(e),o=n.get(r);o||(o=a.querySelector(Rl(r)),o||(e=y({src:e,async:!0,type:"module"},t),(t=Vt.get(r))&&hu(e,t),o=a.createElement("script"),nt(o),ut(o,"link",e),a.head.appendChild(o)),o={type:"script",instance:o,count:1,state:null},n.set(r,o))}}function y0(e,t,a,n){var r=(r=ce.current)?oo(r):null;if(!r)throw Error(c(446));switch(e){case"meta":case"title":return null;case"style":return typeof a.precedence=="string"&&typeof a.href=="string"?(t=Ai(a.href),a=Kn(r).hoistableStyles,n=a.get(t),n||(n={type:"style",instance:null,count:0,state:null},a.set(t,n)),n):{type:"void",instance:null,count:0,state:null};case"link":if(a.rel==="stylesheet"&&typeof a.href=="string"&&typeof a.precedence=="string"){e=Ai(a.href);var o=Kn(r).hoistableStyles,d=o.get(e);if(d||(r=r.ownerDocument||r,d={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},o.set(e,d),(o=r.querySelector(kl(e)))&&!o._p&&(d.instance=o,d.state.loading=5),Vt.has(e)||(a={rel:"preload",as:"style",href:a.href,crossOrigin:a.crossOrigin,integrity:a.integrity,media:a.media,hrefLang:a.hrefLang,referrerPolicy:a.referrerPolicy},Vt.set(e,a),o||Px(r,e,a,d.state))),t&&n===null)throw Error(c(528,""));return d}if(t&&n!==null)throw Error(c(529,""));return null;case"script":return t=a.async,a=a.src,typeof a=="string"&&t&&typeof t!="function"&&typeof t!="symbol"?(t=zi(a),a=Kn(r).hoistableScripts,n=a.get(t),n||(n={type:"script",instance:null,count:0,state:null},a.set(t,n)),n):{type:"void",instance:null,count:0,state:null};default:throw Error(c(444,e))}}function Ai(e){return'href="'+Ut(e)+'"'}function kl(e){return'link[rel="stylesheet"]['+e+"]"}function b0(e){return y({},e,{"data-precedence":e.precedence,precedence:null})}function Px(e,t,a,n){e.querySelector('link[rel="preload"][as="style"]['+t+"]")?n.loading=1:(t=e.createElement("link"),n.preload=t,t.addEventListener("load",function(){return n.loading|=1}),t.addEventListener("error",function(){return n.loading|=2}),ut(t,"link",a),nt(t),e.head.appendChild(t))}function zi(e){return'[src="'+Ut(e)+'"]'}function Rl(e){return"script[async]"+e}function v0(e,t,a){if(t.count++,t.instance===null)switch(t.type){case"style":var n=e.querySelector('style[data-href~="'+Ut(a.href)+'"]');if(n)return t.instance=n,nt(n),n;var r=y({},a,{"data-href":a.href,"data-precedence":a.precedence,href:null,precedence:null});return n=(e.ownerDocument||e).createElement("style"),nt(n),ut(n,"style",r),so(n,a.precedence,e),t.instance=n;case"stylesheet":r=Ai(a.href);var o=e.querySelector(kl(r));if(o)return t.state.loading|=4,t.instance=o,nt(o),o;n=b0(a),(r=Vt.get(r))&&fu(n,r),o=(e.ownerDocument||e).createElement("link"),nt(o);var d=o;return d._p=new Promise(function(m,j){d.onload=m,d.onerror=j}),ut(o,"link",n),t.state.loading|=4,so(o,a.precedence,e),t.instance=o;case"script":return o=zi(a.src),(r=e.querySelector(Rl(o)))?(t.instance=r,nt(r),r):(n=a,(r=Vt.get(o))&&(n=y({},a),hu(n,r)),e=e.ownerDocument||e,r=e.createElement("script"),nt(r),ut(r,"link",n),e.head.appendChild(r),t.instance=r);case"void":return null;default:throw Error(c(443,t.type))}else t.type==="stylesheet"&&(t.state.loading&4)===0&&(n=t.instance,t.state.loading|=4,so(n,a.precedence,e));return t.instance}function so(e,t,a){for(var n=a.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),r=n.length?n[n.length-1]:null,o=r,d=0;d<n.length;d++){var m=n[d];if(m.dataset.precedence===t)o=m;else if(o!==r)break}o?o.parentNode.insertBefore(e,o.nextSibling):(t=a.nodeType===9?a.head:a,t.insertBefore(e,t.firstChild))}function fu(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.title==null&&(e.title=t.title)}function hu(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.integrity==null&&(e.integrity=t.integrity)}var co=null;function j0(e,t,a){if(co===null){var n=new Map,r=co=new Map;r.set(a,n)}else r=co,n=r.get(a),n||(n=new Map,r.set(a,n));if(n.has(e))return n;for(n.set(e,null),a=a.getElementsByTagName(e),r=0;r<a.length;r++){var o=a[r];if(!(o[Ki]||o[rt]||e==="link"&&o.getAttribute("rel")==="stylesheet")&&o.namespaceURI!=="http://www.w3.org/2000/svg"){var d=o.getAttribute(t)||"";d=e+d;var m=n.get(d);m?m.push(o):n.set(d,[o])}}return n}function S0(e,t,a){e=e.ownerDocument||e,e.head.insertBefore(a,t==="title"?e.querySelector("head > title"):null)}function ey(e,t,a){if(a===1||t.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof t.precedence!="string"||typeof t.href!="string"||t.href==="")break;return!0;case"link":if(typeof t.rel!="string"||typeof t.href!="string"||t.href===""||t.onLoad||t.onError)break;return t.rel==="stylesheet"?(e=t.disabled,typeof t.precedence=="string"&&e==null):!0;case"script":if(t.async&&typeof t.async!="function"&&typeof t.async!="symbol"&&!t.onLoad&&!t.onError&&t.src&&typeof t.src=="string")return!0}return!1}function w0(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function ty(e,t,a,n){if(a.type==="stylesheet"&&(typeof n.media!="string"||matchMedia(n.media).matches!==!1)&&(a.state.loading&4)===0){if(a.instance===null){var r=Ai(n.href),o=t.querySelector(kl(r));if(o){t=o._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(e.count++,e=uo.bind(e),t.then(e,e)),a.state.loading|=4,a.instance=o,nt(o);return}o=t.ownerDocument||t,n=b0(n),(r=Vt.get(r))&&fu(n,r),o=o.createElement("link"),nt(o);var d=o;d._p=new Promise(function(m,j){d.onload=m,d.onerror=j}),ut(o,"link",n),a.instance=o}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(a,t),(t=a.state.preload)&&(a.state.loading&3)===0&&(e.count++,a=uo.bind(e),t.addEventListener("load",a),t.addEventListener("error",a))}}var pu=0;function ay(e,t){return e.stylesheets&&e.count===0&&ho(e,e.stylesheets),0<e.count||0<e.imgCount?function(a){var n=setTimeout(function(){if(e.stylesheets&&ho(e,e.stylesheets),e.unsuspend){var o=e.unsuspend;e.unsuspend=null,o()}},6e4+t);0<e.imgBytes&&pu===0&&(pu=62500*Hx());var r=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&ho(e,e.stylesheets),e.unsuspend)){var o=e.unsuspend;e.unsuspend=null,o()}},(e.imgBytes>pu?50:800)+t);return e.unsuspend=a,function(){e.unsuspend=null,clearTimeout(n),clearTimeout(r)}}:null}function uo(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)ho(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}var fo=null;function ho(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,fo=new Map,t.forEach(ny,e),fo=null,uo.call(e))}function ny(e,t){if(!(t.state.loading&4)){var a=fo.get(e);if(a)var n=a.get(null);else{a=new Map,fo.set(e,a);for(var r=e.querySelectorAll("link[data-precedence],style[data-precedence]"),o=0;o<r.length;o++){var d=r[o];(d.nodeName==="LINK"||d.getAttribute("media")!=="not all")&&(a.set(d.dataset.precedence,d),n=d)}n&&a.set(null,n)}r=t.instance,d=r.getAttribute("data-precedence"),o=a.get(d)||n,o===n&&a.set(null,r),a.set(d,r),this.count++,n=uo.bind(this),r.addEventListener("load",n),r.addEventListener("error",n),o?o.parentNode.insertBefore(r,o.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(r,e.firstChild)),t.state.loading|=4}}var _l={$$typeof:Z,Provider:null,Consumer:null,_currentValue:ie,_currentValue2:ie,_threadCount:0};function iy(e,t,a,n,r,o,d,m,j){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=cs(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=cs(0),this.hiddenUpdates=cs(null),this.identifierPrefix=n,this.onUncaughtError=r,this.onCaughtError=o,this.onRecoverableError=d,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=j,this.incompleteTransitions=new Map}function C0(e,t,a,n,r,o,d,m,j,T,O,L){return e=new iy(e,t,a,d,j,T,O,L,m),t=1,o===!0&&(t|=24),o=Tt(3,null,null,t),e.current=o,o.stateNode=e,t=Ks(),t.refCount++,e.pooledCache=t,t.refCount++,o.memoizedState={element:n,isDehydrated:a,cache:t},Fs(o),e}function A0(e){return e?(e=ni,e):ni}function z0(e,t,a,n,r,o){r=A0(r),n.context===null?n.context=r:n.pendingContext=r,n=Xa(t),n.payload={element:a},o=o===void 0?null:o,o!==null&&(n.callback=o),a=Ka(e,n,t),a!==null&&(jt(a,e,t),ul(a,e,t))}function E0(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var a=e.retryLane;e.retryLane=a!==0&&a<t?a:t}}function mu(e,t){E0(e,t),(e=e.alternate)&&E0(e,t)}function T0(e){if(e.tag===13||e.tag===31){var t=wn(e,67108864);t!==null&&jt(t,e,67108864),mu(e,67108864)}}function N0(e){if(e.tag===13||e.tag===31){var t=Mt();t=us(t);var a=wn(e,t);a!==null&&jt(a,e,t),mu(e,t)}}var po=!0;function ly(e,t,a,n){var r=M.T;M.T=null;var o=X.p;try{X.p=2,gu(e,t,a,n)}finally{X.p=o,M.T=r}}function ry(e,t,a,n){var r=M.T;M.T=null;var o=X.p;try{X.p=8,gu(e,t,a,n)}finally{X.p=o,M.T=r}}function gu(e,t,a,n){if(po){var r=xu(n);if(r===null)au(e,t,n,mo,a),R0(e,n);else if(sy(r,e,t,a,n))n.stopPropagation();else if(R0(e,n),t&4&&-1<oy.indexOf(e)){for(;r!==null;){var o=Xn(r);if(o!==null)switch(o.tag){case 3:if(o=o.stateNode,o.current.memoizedState.isDehydrated){var d=yn(o.pendingLanes);if(d!==0){var m=o;for(m.pendingLanes|=2,m.entangledLanes|=2;d;){var j=1<<31-zt(d);m.entanglements[1]|=j,d&=~j}da(o),(Ce&6)===0&&(Jr=Ct()+500,zl(0))}}break;case 31:case 13:m=wn(o,2),m!==null&&jt(m,o,2),Ir(),mu(o,2)}if(o=xu(n),o===null&&au(e,t,n,mo,a),o===r)break;r=o}r!==null&&n.stopPropagation()}else au(e,t,n,null,a)}}function xu(e){return e=bs(e),yu(e)}var mo=null;function yu(e){if(mo=null,e=Vn(e),e!==null){var t=p(e);if(t===null)e=null;else{var a=t.tag;if(a===13){if(e=h(t),e!==null)return e;e=null}else if(a===31){if(e=v(t),e!==null)return e;e=null}else if(a===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return mo=e,null}function k0(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(Xg()){case Ud:return 2;case Bd:return 8;case nr:case Kg:return 32;case Ld:return 268435456;default:return 32}default:return 32}}var bu=!1,ln=null,rn=null,on=null,Ml=new Map,Dl=new Map,sn=[],oy="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function R0(e,t){switch(e){case"focusin":case"focusout":ln=null;break;case"dragenter":case"dragleave":rn=null;break;case"mouseover":case"mouseout":on=null;break;case"pointerover":case"pointerout":Ml.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":Dl.delete(t.pointerId)}}function Ol(e,t,a,n,r,o){return e===null||e.nativeEvent!==o?(e={blockedOn:t,domEventName:a,eventSystemFlags:n,nativeEvent:o,targetContainers:[r]},t!==null&&(t=Xn(t),t!==null&&T0(t)),e):(e.eventSystemFlags|=n,t=e.targetContainers,r!==null&&t.indexOf(r)===-1&&t.push(r),e)}function sy(e,t,a,n,r){switch(t){case"focusin":return ln=Ol(ln,e,t,a,n,r),!0;case"dragenter":return rn=Ol(rn,e,t,a,n,r),!0;case"mouseover":return on=Ol(on,e,t,a,n,r),!0;case"pointerover":var o=r.pointerId;return Ml.set(o,Ol(Ml.get(o)||null,e,t,a,n,r)),!0;case"gotpointercapture":return o=r.pointerId,Dl.set(o,Ol(Dl.get(o)||null,e,t,a,n,r)),!0}return!1}function _0(e){var t=Vn(e.target);if(t!==null){var a=p(t);if(a!==null){if(t=a.tag,t===13){if(t=h(a),t!==null){e.blockedOn=t,Vd(e.priority,function(){N0(a)});return}}else if(t===31){if(t=v(a),t!==null){e.blockedOn=t,Vd(e.priority,function(){N0(a)});return}}else if(t===3&&a.stateNode.current.memoizedState.isDehydrated){e.blockedOn=a.tag===3?a.stateNode.containerInfo:null;return}}}e.blockedOn=null}function go(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var a=xu(e.nativeEvent);if(a===null){a=e.nativeEvent;var n=new a.constructor(a.type,a);ys=n,a.target.dispatchEvent(n),ys=null}else return t=Xn(a),t!==null&&T0(t),e.blockedOn=a,!1;t.shift()}return!0}function M0(e,t,a){go(e)&&a.delete(t)}function cy(){bu=!1,ln!==null&&go(ln)&&(ln=null),rn!==null&&go(rn)&&(rn=null),on!==null&&go(on)&&(on=null),Ml.forEach(M0),Dl.forEach(M0)}function xo(e,t){e.blockedOn===t&&(e.blockedOn=null,bu||(bu=!0,i.unstable_scheduleCallback(i.unstable_NormalPriority,cy)))}var yo=null;function D0(e){yo!==e&&(yo=e,i.unstable_scheduleCallback(i.unstable_NormalPriority,function(){yo===e&&(yo=null);for(var t=0;t<e.length;t+=3){var a=e[t],n=e[t+1],r=e[t+2];if(typeof n!="function"){if(yu(n||a)===null)continue;break}var o=Xn(a);o!==null&&(e.splice(t,3),t-=3,xc(o,{pending:!0,data:r,method:a.method,action:n},n,r))}}))}function Ei(e){function t(j){return xo(j,e)}ln!==null&&xo(ln,e),rn!==null&&xo(rn,e),on!==null&&xo(on,e),Ml.forEach(t),Dl.forEach(t);for(var a=0;a<sn.length;a++){var n=sn[a];n.blockedOn===e&&(n.blockedOn=null)}for(;0<sn.length&&(a=sn[0],a.blockedOn===null);)_0(a),a.blockedOn===null&&sn.shift();if(a=(e.ownerDocument||e).$$reactFormReplay,a!=null)for(n=0;n<a.length;n+=3){var r=a[n],o=a[n+1],d=r[mt]||null;if(typeof o=="function")d||D0(a);else if(d){var m=null;if(o&&o.hasAttribute("formAction")){if(r=o,d=o[mt]||null)m=d.formAction;else if(yu(r)!==null)continue}else m=d.action;typeof m=="function"?a[n+1]=m:(a.splice(n,3),n-=3),D0(a)}}}function O0(){function e(o){o.canIntercept&&o.info==="react-transition"&&o.intercept({handler:function(){return new Promise(function(d){return r=d})},focusReset:"manual",scroll:"manual"})}function t(){r!==null&&(r(),r=null),n||setTimeout(a,20)}function a(){if(!n&&!navigation.transition){var o=navigation.currentEntry;o&&o.url!=null&&navigation.navigate(o.url,{state:o.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var n=!1,r=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(a,100),function(){n=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),r!==null&&(r(),r=null)}}}function vu(e){this._internalRoot=e}bo.prototype.render=vu.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(c(409));var a=t.current,n=Mt();z0(a,n,e,t,null,null)},bo.prototype.unmount=vu.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;z0(e.current,2,null,e,null,null),Ir(),t[Qn]=null}};function bo(e){this._internalRoot=e}bo.prototype.unstable_scheduleHydration=function(e){if(e){var t=Qd();e={blockedOn:null,target:e,priority:t};for(var a=0;a<sn.length&&t!==0&&t<sn[a].priority;a++);sn.splice(a,0,e),a===0&&_0(e)}};var H0=s.version;if(H0!=="19.2.4")throw Error(c(527,H0,"19.2.4"));X.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(c(188)):(e=Object.keys(e).join(","),Error(c(268,e)));return e=g(t),e=e!==null?b(e):null,e=e===null?null:e.stateNode,e};var uy={bundleType:0,version:"19.2.4",rendererPackageName:"react-dom",currentDispatcherRef:M,reconcilerVersion:"19.2.4"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var vo=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!vo.isDisabled&&vo.supportsFiber)try{Qi=vo.inject(uy),At=vo}catch{}}return Ul.createRoot=function(e,t){if(!f(e))throw Error(c(299));var a=!1,n="",r=Gh,o=Qh,d=Vh;return t!=null&&(t.unstable_strictMode===!0&&(a=!0),t.identifierPrefix!==void 0&&(n=t.identifierPrefix),t.onUncaughtError!==void 0&&(r=t.onUncaughtError),t.onCaughtError!==void 0&&(o=t.onCaughtError),t.onRecoverableError!==void 0&&(d=t.onRecoverableError)),t=C0(e,1,!1,null,null,a,n,null,r,o,d,O0),e[Qn]=t.current,tu(e),new vu(t)},Ul.hydrateRoot=function(e,t,a){if(!f(e))throw Error(c(299));var n=!1,r="",o=Gh,d=Qh,m=Vh,j=null;return a!=null&&(a.unstable_strictMode===!0&&(n=!0),a.identifierPrefix!==void 0&&(r=a.identifierPrefix),a.onUncaughtError!==void 0&&(o=a.onUncaughtError),a.onCaughtError!==void 0&&(d=a.onCaughtError),a.onRecoverableError!==void 0&&(m=a.onRecoverableError),a.formState!==void 0&&(j=a.formState)),t=C0(e,1,!0,t,a??null,n,r,j,o,d,m,O0),t.context=A0(null),a=t.current,n=Mt(),n=us(n),r=Xa(n),r.callback=null,Ka(a,r,n),a=n,t.current.lanes=a,Xi(t,a),da(t),e[Qn]=t.current,tu(e),new bo(t)},Ul.version="19.2.4",Ul}var X0;function jy(){if(X0)return wu.exports;X0=1;function i(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(i)}catch(s){console.error(s)}}return i(),wu.exports=vy(),wu.exports}var Sy=jy();var K0="popstate";function wy(i={}){function s(c,f){let{pathname:p,search:h,hash:v}=c.location;return Ju("",{pathname:p,search:h,hash:v},f.state&&f.state.usr||null,f.state&&f.state.key||"default")}function u(c,f){return typeof f=="string"?f:Kl(f)}return Ay(s,u,null,i)}function Ye(i,s){if(i===!1||i===null||typeof i>"u")throw new Error(s)}function fa(i,s){if(!i){typeof console<"u"&&console.warn(s);try{throw new Error(s)}catch{}}}function Cy(){return Math.random().toString(36).substring(2,10)}function Z0(i,s){return{usr:i.state,key:i.key,idx:s}}function Ju(i,s,u=null,c){return{pathname:typeof i=="string"?i:i.pathname,search:"",hash:"",...typeof s=="string"?Yi(s):s,state:u,key:s&&s.key||c||Cy()}}function Kl({pathname:i="/",search:s="",hash:u=""}){return s&&s!=="?"&&(i+=s.charAt(0)==="?"?s:"?"+s),u&&u!=="#"&&(i+=u.charAt(0)==="#"?u:"#"+u),i}function Yi(i){let s={};if(i){let u=i.indexOf("#");u>=0&&(s.hash=i.substring(u),i=i.substring(0,u));let c=i.indexOf("?");c>=0&&(s.search=i.substring(c),i=i.substring(0,c)),i&&(s.pathname=i)}return s}function Ay(i,s,u,c={}){let{window:f=document.defaultView,v5Compat:p=!1}=c,h=f.history,v="POP",x=null,g=b();g==null&&(g=0,h.replaceState({...h.state,idx:g},""));function b(){return(h.state||{idx:null}).idx}function y(){v="POP";let Y=b(),U=Y==null?null:Y-g;g=Y,x&&x({action:v,location:q.location,delta:U})}function k(Y,U){v="PUSH";let Q=Ju(q.location,Y,U);g=b()+1;let Z=Z0(Q,g),V=q.createHref(Q);try{h.pushState(Z,"",V)}catch(te){if(te instanceof DOMException&&te.name==="DataCloneError")throw te;f.location.assign(V)}p&&x&&x({action:v,location:q.location,delta:1})}function D(Y,U){v="REPLACE";let Q=Ju(q.location,Y,U);g=b();let Z=Z0(Q,g),V=q.createHref(Q);h.replaceState(Z,"",V),p&&x&&x({action:v,location:q.location,delta:0})}function _(Y){return zy(Y)}let q={get action(){return v},get location(){return i(f,h)},listen(Y){if(x)throw new Error("A history only accepts one active listener");return f.addEventListener(K0,y),x=Y,()=>{f.removeEventListener(K0,y),x=null}},createHref(Y){return s(f,Y)},createURL:_,encodeLocation(Y){let U=_(Y);return{pathname:U.pathname,search:U.search,hash:U.hash}},push:k,replace:D,go(Y){return h.go(Y)}};return q}function zy(i,s=!1){let u="http://localhost";typeof window<"u"&&(u=window.location.origin!=="null"?window.location.origin:window.location.href),Ye(u,"No window.location.(origin|href) available to create URL");let c=typeof i=="string"?i:Kl(i);return c=c.replace(/ $/,"%20"),!s&&c.startsWith("//")&&(c=u+c),new URL(c,u)}function Nm(i,s,u="/"){return Ey(i,s,u,!1)}function Ey(i,s,u,c){let f=typeof s=="string"?Yi(s):s,p=Oa(f.pathname||"/",u);if(p==null)return null;let h=km(i);Ty(h);let v=null;for(let x=0;v==null&&x<h.length;++x){let g=Ly(p);v=Uy(h[x],g,c)}return v}function km(i,s=[],u=[],c="",f=!1){let p=(h,v,x=f,g)=>{let b={relativePath:g===void 0?h.path||"":g,caseSensitive:h.caseSensitive===!0,childrenIndex:v,route:h};if(b.relativePath.startsWith("/")){if(!b.relativePath.startsWith(c)&&x)return;Ye(b.relativePath.startsWith(c),`Absolute route path "${b.relativePath}" nested under path "${c}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`),b.relativePath=b.relativePath.slice(c.length)}let y=Da([c,b.relativePath]),k=u.concat(b);h.children&&h.children.length>0&&(Ye(h.index!==!0,`Index routes must not have child routes. Please remove all child routes from route path "${y}".`),km(h.children,s,k,y,x)),!(h.path==null&&!h.index)&&s.push({path:y,score:Oy(y,h.index),routesMeta:k})};return i.forEach((h,v)=>{if(h.path===""||!h.path?.includes("?"))p(h,v);else for(let x of Rm(h.path))p(h,v,!0,x)}),s}function Rm(i){let s=i.split("/");if(s.length===0)return[];let[u,...c]=s,f=u.endsWith("?"),p=u.replace(/\?$/,"");if(c.length===0)return f?[p,""]:[p];let h=Rm(c.join("/")),v=[];return v.push(...h.map(x=>x===""?p:[p,x].join("/"))),f&&v.push(...h),v.map(x=>i.startsWith("/")&&x===""?"/":x)}function Ty(i){i.sort((s,u)=>s.score!==u.score?u.score-s.score:Hy(s.routesMeta.map(c=>c.childrenIndex),u.routesMeta.map(c=>c.childrenIndex)))}var Ny=/^:[\w-]+$/,ky=3,Ry=2,_y=1,My=10,Dy=-2,W0=i=>i==="*";function Oy(i,s){let u=i.split("/"),c=u.length;return u.some(W0)&&(c+=Dy),s&&(c+=Ry),u.filter(f=>!W0(f)).reduce((f,p)=>f+(Ny.test(p)?ky:p===""?_y:My),c)}function Hy(i,s){return i.length===s.length&&i.slice(0,-1).every((c,f)=>c===s[f])?i[i.length-1]-s[s.length-1]:0}function Uy(i,s,u=!1){let{routesMeta:c}=i,f={},p="/",h=[];for(let v=0;v<c.length;++v){let x=c[v],g=v===c.length-1,b=p==="/"?s:s.slice(p.length)||"/",y=$o({path:x.relativePath,caseSensitive:x.caseSensitive,end:g},b),k=x.route;if(!y&&g&&u&&!c[c.length-1].route.index&&(y=$o({path:x.relativePath,caseSensitive:x.caseSensitive,end:!1},b)),!y)return null;Object.assign(f,y.params),h.push({params:f,pathname:Da([p,y.pathname]),pathnameBase:Gy(Da([p,y.pathnameBase])),route:k}),y.pathnameBase!=="/"&&(p=Da([p,y.pathnameBase]))}return h}function $o(i,s){typeof i=="string"&&(i={path:i,caseSensitive:!1,end:!0});let[u,c]=By(i.path,i.caseSensitive,i.end),f=s.match(u);if(!f)return null;let p=f[0],h=p.replace(/(.)\/+$/,"$1"),v=f.slice(1);return{params:c.reduce((g,{paramName:b,isOptional:y},k)=>{if(b==="*"){let _=v[k]||"";h=p.slice(0,p.length-_.length).replace(/(.)\/+$/,"$1")}const D=v[k];return y&&!D?g[b]=void 0:g[b]=(D||"").replace(/%2F/g,"/"),g},{}),pathname:p,pathnameBase:h,pattern:i}}function By(i,s=!1,u=!0){fa(i==="*"||!i.endsWith("*")||i.endsWith("/*"),`Route path "${i}" will be treated as if it were "${i.replace(/\*$/,"/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${i.replace(/\*$/,"/*")}".`);let c=[],f="^"+i.replace(/\/*\*?$/,"").replace(/^\/*/,"/").replace(/[\\.*+^${}|()[\]]/g,"\\$&").replace(/\/:([\w-]+)(\?)?/g,(h,v,x)=>(c.push({paramName:v,isOptional:x!=null}),x?"/?([^\\/]+)?":"/([^\\/]+)")).replace(/\/([\w-]+)\?(\/|$)/g,"(/$1)?$2");return i.endsWith("*")?(c.push({paramName:"*"}),f+=i==="*"||i==="/*"?"(.*)$":"(?:\\/(.+)|\\/*)$"):u?f+="\\/*$":i!==""&&i!=="/"&&(f+="(?:(?=\\/|$))"),[new RegExp(f,s?void 0:"i"),c]}function Ly(i){try{return i.split("/").map(s=>decodeURIComponent(s).replace(/\//g,"%2F")).join("/")}catch(s){return fa(!1,`The URL path "${i}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${s}).`),i}}function Oa(i,s){if(s==="/")return i;if(!i.toLowerCase().startsWith(s.toLowerCase()))return null;let u=s.endsWith("/")?s.length-1:s.length,c=i.charAt(u);return c&&c!=="/"?null:i.slice(u)||"/"}var qy=/^(?:[a-z][a-z0-9+.-]*:|\/\/)/i;function Yy(i,s="/"){let{pathname:u,search:c="",hash:f=""}=typeof i=="string"?Yi(i):i,p;return u?(u=u.replace(/\/\/+/g,"/"),u.startsWith("/")?p=J0(u.substring(1),"/"):p=J0(u,s)):p=s,{pathname:p,search:Qy(c),hash:Vy(f)}}function J0(i,s){let u=s.replace(/\/+$/,"").split("/");return i.split("/").forEach(f=>{f===".."?u.length>1&&u.pop():f!=="."&&u.push(f)}),u.length>1?u.join("/"):"/"}function Eu(i,s,u,c){return`Cannot include a '${i}' character in a manually specified \`to.${s}\` field [${JSON.stringify(c)}].  Please separate it out to the \`to.${u}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`}function $y(i){return i.filter((s,u)=>u===0||s.route.path&&s.route.path.length>0)}function _m(i){let s=$y(i);return s.map((u,c)=>c===s.length-1?u.pathname:u.pathnameBase)}function Mm(i,s,u,c=!1){let f;typeof i=="string"?f=Yi(i):(f={...i},Ye(!f.pathname||!f.pathname.includes("?"),Eu("?","pathname","search",f)),Ye(!f.pathname||!f.pathname.includes("#"),Eu("#","pathname","hash",f)),Ye(!f.search||!f.search.includes("#"),Eu("#","search","hash",f)));let p=i===""||f.pathname==="",h=p?"/":f.pathname,v;if(h==null)v=u;else{let y=s.length-1;if(!c&&h.startsWith("..")){let k=h.split("/");for(;k[0]==="..";)k.shift(),y-=1;f.pathname=k.join("/")}v=y>=0?s[y]:"/"}let x=Yy(f,v),g=h&&h!=="/"&&h.endsWith("/"),b=(p||h===".")&&u.endsWith("/");return!x.pathname.endsWith("/")&&(g||b)&&(x.pathname+="/"),x}var Da=i=>i.join("/").replace(/\/\/+/g,"/"),Gy=i=>i.replace(/\/+$/,"").replace(/^\/*/,"/"),Qy=i=>!i||i==="?"?"":i.startsWith("?")?i:"?"+i,Vy=i=>!i||i==="#"?"":i.startsWith("#")?i:"#"+i,Xy=class{constructor(i,s,u,c=!1){this.status=i,this.statusText=s||"",this.internal=c,u instanceof Error?(this.data=u.toString(),this.error=u):this.data=u}};function Ky(i){return i!=null&&typeof i.status=="number"&&typeof i.statusText=="string"&&typeof i.internal=="boolean"&&"data"in i}function Zy(i){return i.map(s=>s.route.path).filter(Boolean).join("/").replace(/\/\/*/g,"/")||"/"}var Dm=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";function Om(i,s){let u=i;if(typeof u!="string"||!qy.test(u))return{absoluteURL:void 0,isExternal:!1,to:u};let c=u,f=!1;if(Dm)try{let p=new URL(window.location.href),h=u.startsWith("//")?new URL(p.protocol+u):new URL(u),v=Oa(h.pathname,s);h.origin===p.origin&&v!=null?u=v+h.search+h.hash:f=!0}catch{fa(!1,`<Link to="${u}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`)}return{absoluteURL:c,isExternal:f,to:u}}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");var Hm=["POST","PUT","PATCH","DELETE"];new Set(Hm);var Wy=["GET",...Hm];new Set(Wy);var $i=A.createContext(null);$i.displayName="DataRouter";var Ko=A.createContext(null);Ko.displayName="DataRouterState";var Jy=A.createContext(!1),Um=A.createContext({isTransitioning:!1});Um.displayName="ViewTransition";var Fy=A.createContext(new Map);Fy.displayName="Fetchers";var Iy=A.createContext(null);Iy.displayName="Await";var Jt=A.createContext(null);Jt.displayName="Navigation";var Fl=A.createContext(null);Fl.displayName="Location";var ia=A.createContext({outlet:null,matches:[],isDataRoute:!1});ia.displayName="Route";var gd=A.createContext(null);gd.displayName="RouteError";var Bm="REACT_ROUTER_ERROR",Py="REDIRECT",eb="ROUTE_ERROR_RESPONSE";function tb(i){if(i.startsWith(`${Bm}:${Py}:{`))try{let s=JSON.parse(i.slice(28));if(typeof s=="object"&&s&&typeof s.status=="number"&&typeof s.statusText=="string"&&typeof s.location=="string"&&typeof s.reloadDocument=="boolean"&&typeof s.replace=="boolean")return s}catch{}}function ab(i){if(i.startsWith(`${Bm}:${eb}:{`))try{let s=JSON.parse(i.slice(40));if(typeof s=="object"&&s&&typeof s.status=="number"&&typeof s.statusText=="string")return new Xy(s.status,s.statusText,s.data)}catch{}}function nb(i,{relative:s}={}){Ye(Il(),"useHref() may be used only in the context of a <Router> component.");let{basename:u,navigator:c}=A.useContext(Jt),{hash:f,pathname:p,search:h}=Pl(i,{relative:s}),v=p;return u!=="/"&&(v=p==="/"?u:Da([u,p])),c.createHref({pathname:v,search:h,hash:f})}function Il(){return A.useContext(Fl)!=null}function Ua(){return Ye(Il(),"useLocation() may be used only in the context of a <Router> component."),A.useContext(Fl).location}var Lm="You should call navigate() in a React.useEffect(), not when your component is first rendered.";function qm(i){A.useContext(Jt).static||A.useLayoutEffect(i)}function gn(){let{isDataRoute:i}=A.useContext(ia);return i?yb():ib()}function ib(){Ye(Il(),"useNavigate() may be used only in the context of a <Router> component.");let i=A.useContext($i),{basename:s,navigator:u}=A.useContext(Jt),{matches:c}=A.useContext(ia),{pathname:f}=Ua(),p=JSON.stringify(_m(c)),h=A.useRef(!1);return qm(()=>{h.current=!0}),A.useCallback((x,g={})=>{if(fa(h.current,Lm),!h.current)return;if(typeof x=="number"){u.go(x);return}let b=Mm(x,JSON.parse(p),f,g.relative==="path");i==null&&s!=="/"&&(b.pathname=b.pathname==="/"?s:Da([s,b.pathname])),(g.replace?u.replace:u.push)(b,g.state,g)},[s,u,p,f,i])}var lb=A.createContext(null);function rb(i){let s=A.useContext(ia).outlet;return A.useMemo(()=>s&&A.createElement(lb.Provider,{value:i},s),[s,i])}function xd(){let{matches:i}=A.useContext(ia),s=i[i.length-1];return s?s.params:{}}function Pl(i,{relative:s}={}){let{matches:u}=A.useContext(ia),{pathname:c}=Ua(),f=JSON.stringify(_m(u));return A.useMemo(()=>Mm(i,JSON.parse(f),c,s==="path"),[i,f,c,s])}function ob(i,s){return Ym(i,s)}function Ym(i,s,u,c,f){Ye(Il(),"useRoutes() may be used only in the context of a <Router> component.");let{navigator:p}=A.useContext(Jt),{matches:h}=A.useContext(ia),v=h[h.length-1],x=v?v.params:{},g=v?v.pathname:"/",b=v?v.pathnameBase:"/",y=v&&v.route;{let Q=y&&y.path||"";Gm(g,!y||Q.endsWith("*")||Q.endsWith("*?"),`You rendered descendant <Routes> (or called \`useRoutes()\`) at "${g}" (under <Route path="${Q}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${Q}"> to <Route path="${Q==="/"?"*":`${Q}/*`}">.`)}let k=Ua(),D;if(s){let Q=typeof s=="string"?Yi(s):s;Ye(b==="/"||Q.pathname?.startsWith(b),`When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${b}" but pathname "${Q.pathname}" was given in the \`location\` prop.`),D=Q}else D=k;let _=D.pathname||"/",q=_;if(b!=="/"){let Q=b.replace(/^\//,"").split("/");q="/"+_.replace(/^\//,"").split("/").slice(Q.length).join("/")}let Y=Nm(i,{pathname:q});fa(y||Y!=null,`No routes matched location "${D.pathname}${D.search}${D.hash}" `),fa(Y==null||Y[Y.length-1].route.element!==void 0||Y[Y.length-1].route.Component!==void 0||Y[Y.length-1].route.lazy!==void 0,`Matched leaf route at location "${D.pathname}${D.search}${D.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);let U=fb(Y&&Y.map(Q=>Object.assign({},Q,{params:Object.assign({},x,Q.params),pathname:Da([b,p.encodeLocation?p.encodeLocation(Q.pathname.replace(/\?/g,"%3F").replace(/#/g,"%23")).pathname:Q.pathname]),pathnameBase:Q.pathnameBase==="/"?b:Da([b,p.encodeLocation?p.encodeLocation(Q.pathnameBase.replace(/\?/g,"%3F").replace(/#/g,"%23")).pathname:Q.pathnameBase])})),h,u,c,f);return s&&U?A.createElement(Fl.Provider,{value:{location:{pathname:"/",search:"",hash:"",state:null,key:"default",...D},navigationType:"POP"}},U):U}function sb(){let i=xb(),s=Ky(i)?`${i.status} ${i.statusText}`:i instanceof Error?i.message:JSON.stringify(i),u=i instanceof Error?i.stack:null,c="rgba(200,200,200, 0.5)",f={padding:"0.5rem",backgroundColor:c},p={padding:"2px 4px",backgroundColor:c},h=null;return console.error("Error handled by React Router default ErrorBoundary:",i),h=A.createElement(A.Fragment,null,A.createElement("p",null,"💿 Hey developer 👋"),A.createElement("p",null,"You can provide a way better UX than this when your app throws errors by providing your own ",A.createElement("code",{style:p},"ErrorBoundary")," or"," ",A.createElement("code",{style:p},"errorElement")," prop on your route.")),A.createElement(A.Fragment,null,A.createElement("h2",null,"Unexpected Application Error!"),A.createElement("h3",{style:{fontStyle:"italic"}},s),u?A.createElement("pre",{style:f},u):null,h)}var cb=A.createElement(sb,null),$m=class extends A.Component{constructor(i){super(i),this.state={location:i.location,revalidation:i.revalidation,error:i.error}}static getDerivedStateFromError(i){return{error:i}}static getDerivedStateFromProps(i,s){return s.location!==i.location||s.revalidation!=="idle"&&i.revalidation==="idle"?{error:i.error,location:i.location,revalidation:i.revalidation}:{error:i.error!==void 0?i.error:s.error,location:s.location,revalidation:i.revalidation||s.revalidation}}componentDidCatch(i,s){this.props.onError?this.props.onError(i,s):console.error("React Router caught the following error during render",i)}render(){let i=this.state.error;if(this.context&&typeof i=="object"&&i&&"digest"in i&&typeof i.digest=="string"){const u=ab(i.digest);u&&(i=u)}let s=i!==void 0?A.createElement(ia.Provider,{value:this.props.routeContext},A.createElement(gd.Provider,{value:i,children:this.props.component})):this.props.children;return this.context?A.createElement(ub,{error:i},s):s}};$m.contextType=Jy;var Tu=new WeakMap;function ub({children:i,error:s}){let{basename:u}=A.useContext(Jt);if(typeof s=="object"&&s&&"digest"in s&&typeof s.digest=="string"){let c=tb(s.digest);if(c){let f=Tu.get(s);if(f)throw f;let p=Om(c.location,u);if(Dm&&!Tu.get(s))if(p.isExternal||c.reloadDocument)window.location.href=p.absoluteURL||p.to;else{const h=Promise.resolve().then(()=>window.__reactRouterDataRouter.navigate(p.to,{replace:c.replace}));throw Tu.set(s,h),h}return A.createElement("meta",{httpEquiv:"refresh",content:`0;url=${p.absoluteURL||p.to}`})}}return i}function db({routeContext:i,match:s,children:u}){let c=A.useContext($i);return c&&c.static&&c.staticContext&&(s.route.errorElement||s.route.ErrorBoundary)&&(c.staticContext._deepestRenderedBoundaryId=s.route.id),A.createElement(ia.Provider,{value:i},u)}function fb(i,s=[],u=null,c=null,f=null){if(i==null){if(!u)return null;if(u.errors)i=u.matches;else if(s.length===0&&!u.initialized&&u.matches.length>0)i=u.matches;else return null}let p=i,h=u?.errors;if(h!=null){let b=p.findIndex(y=>y.route.id&&h?.[y.route.id]!==void 0);Ye(b>=0,`Could not find a matching route for errors on route IDs: ${Object.keys(h).join(",")}`),p=p.slice(0,Math.min(p.length,b+1))}let v=!1,x=-1;if(u)for(let b=0;b<p.length;b++){let y=p[b];if((y.route.HydrateFallback||y.route.hydrateFallbackElement)&&(x=b),y.route.id){let{loaderData:k,errors:D}=u,_=y.route.loader&&!k.hasOwnProperty(y.route.id)&&(!D||D[y.route.id]===void 0);if(y.route.lazy||_){v=!0,x>=0?p=p.slice(0,x+1):p=[p[0]];break}}}let g=u&&c?(b,y)=>{c(b,{location:u.location,params:u.matches?.[0]?.params??{},unstable_pattern:Zy(u.matches),errorInfo:y})}:void 0;return p.reduceRight((b,y,k)=>{let D,_=!1,q=null,Y=null;u&&(D=h&&y.route.id?h[y.route.id]:void 0,q=y.route.errorElement||cb,v&&(x<0&&k===0?(Gm("route-fallback",!1,"No `HydrateFallback` element provided to render during initial hydration"),_=!0,Y=null):x===k&&(_=!0,Y=y.route.hydrateFallbackElement||null)));let U=s.concat(p.slice(0,k+1)),Q=()=>{let Z;return D?Z=q:_?Z=Y:y.route.Component?Z=A.createElement(y.route.Component,null):y.route.element?Z=y.route.element:Z=b,A.createElement(db,{match:y,routeContext:{outlet:b,matches:U,isDataRoute:u!=null},children:Z})};return u&&(y.route.ErrorBoundary||y.route.errorElement||k===0)?A.createElement($m,{location:u.location,revalidation:u.revalidation,component:q,error:D,children:Q(),routeContext:{outlet:null,matches:U,isDataRoute:!0},onError:g}):Q()},null)}function yd(i){return`${i} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function hb(i){let s=A.useContext($i);return Ye(s,yd(i)),s}function pb(i){let s=A.useContext(Ko);return Ye(s,yd(i)),s}function mb(i){let s=A.useContext(ia);return Ye(s,yd(i)),s}function bd(i){let s=mb(i),u=s.matches[s.matches.length-1];return Ye(u.route.id,`${i} can only be used on routes that contain a unique "id"`),u.route.id}function gb(){return bd("useRouteId")}function xb(){let i=A.useContext(gd),s=pb("useRouteError"),u=bd("useRouteError");return i!==void 0?i:s.errors?.[u]}function yb(){let{router:i}=hb("useNavigate"),s=bd("useNavigate"),u=A.useRef(!1);return qm(()=>{u.current=!0}),A.useCallback(async(f,p={})=>{fa(u.current,Lm),u.current&&(typeof f=="number"?await i.navigate(f):await i.navigate(f,{fromRouteId:s,...p}))},[i,s])}var F0={};function Gm(i,s,u){!s&&!F0[i]&&(F0[i]=!0,fa(!1,u))}A.memo(bb);function bb({routes:i,future:s,state:u,onError:c}){return Ym(i,void 0,u,c,s)}function vb(i){return rb(i.context)}function dt(i){Ye(!1,"A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.")}function jb({basename:i="/",children:s=null,location:u,navigationType:c="POP",navigator:f,static:p=!1,unstable_useTransitions:h}){Ye(!Il(),"You cannot render a <Router> inside another <Router>. You should never have more than one in your app.");let v=i.replace(/^\/*/,"/"),x=A.useMemo(()=>({basename:v,navigator:f,static:p,unstable_useTransitions:h,future:{}}),[v,f,p,h]);typeof u=="string"&&(u=Yi(u));let{pathname:g="/",search:b="",hash:y="",state:k=null,key:D="default"}=u,_=A.useMemo(()=>{let q=Oa(g,v);return q==null?null:{location:{pathname:q,search:b,hash:y,state:k,key:D},navigationType:c}},[v,g,b,y,k,D,c]);return fa(_!=null,`<Router basename="${v}"> is not able to match the URL "${g}${b}${y}" because it does not start with the basename, so the <Router> won't render anything.`),_==null?null:A.createElement(Jt.Provider,{value:x},A.createElement(Fl.Provider,{children:s,value:_}))}function Sb({children:i,location:s}){return ob(Fu(i),s)}function Fu(i,s=[]){let u=[];return A.Children.forEach(i,(c,f)=>{if(!A.isValidElement(c))return;let p=[...s,f];if(c.type===A.Fragment){u.push.apply(u,Fu(c.props.children,p));return}Ye(c.type===dt,`[${typeof c.type=="string"?c.type:c.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`),Ye(!c.props.index||!c.props.children,"An index route cannot have child routes.");let h={id:c.props.id||p.join("-"),caseSensitive:c.props.caseSensitive,element:c.props.element,Component:c.props.Component,index:c.props.index,path:c.props.path,middleware:c.props.middleware,loader:c.props.loader,action:c.props.action,hydrateFallbackElement:c.props.hydrateFallbackElement,HydrateFallback:c.props.HydrateFallback,errorElement:c.props.errorElement,ErrorBoundary:c.props.ErrorBoundary,hasErrorBoundary:c.props.hasErrorBoundary===!0||c.props.ErrorBoundary!=null||c.props.errorElement!=null,shouldRevalidate:c.props.shouldRevalidate,handle:c.props.handle,lazy:c.props.lazy};c.props.children&&(h.children=Fu(c.props.children,p)),u.push(h)}),u}var Do="get",Oo="application/x-www-form-urlencoded";function Zo(i){return typeof HTMLElement<"u"&&i instanceof HTMLElement}function wb(i){return Zo(i)&&i.tagName.toLowerCase()==="button"}function Cb(i){return Zo(i)&&i.tagName.toLowerCase()==="form"}function Ab(i){return Zo(i)&&i.tagName.toLowerCase()==="input"}function zb(i){return!!(i.metaKey||i.altKey||i.ctrlKey||i.shiftKey)}function Eb(i,s){return i.button===0&&(!s||s==="_self")&&!zb(i)}var jo=null;function Tb(){if(jo===null)try{new FormData(document.createElement("form"),0),jo=!1}catch{jo=!0}return jo}var Nb=new Set(["application/x-www-form-urlencoded","multipart/form-data","text/plain"]);function Nu(i){return i!=null&&!Nb.has(i)?(fa(!1,`"${i}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${Oo}"`),null):i}function kb(i,s){let u,c,f,p,h;if(Cb(i)){let v=i.getAttribute("action");c=v?Oa(v,s):null,u=i.getAttribute("method")||Do,f=Nu(i.getAttribute("enctype"))||Oo,p=new FormData(i)}else if(wb(i)||Ab(i)&&(i.type==="submit"||i.type==="image")){let v=i.form;if(v==null)throw new Error('Cannot submit a <button> or <input type="submit"> without a <form>');let x=i.getAttribute("formaction")||v.getAttribute("action");if(c=x?Oa(x,s):null,u=i.getAttribute("formmethod")||v.getAttribute("method")||Do,f=Nu(i.getAttribute("formenctype"))||Nu(v.getAttribute("enctype"))||Oo,p=new FormData(v,i),!Tb()){let{name:g,type:b,value:y}=i;if(b==="image"){let k=g?`${g}.`:"";p.append(`${k}x`,"0"),p.append(`${k}y`,"0")}else g&&p.append(g,y)}}else{if(Zo(i))throw new Error('Cannot submit element that is not <form>, <button>, or <input type="submit|image">');u=Do,c=null,f=Oo,h=i}return p&&f==="text/plain"&&(h=p,p=void 0),{action:c,method:u.toLowerCase(),encType:f,formData:p,body:h}}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");function vd(i,s){if(i===!1||i===null||typeof i>"u")throw new Error(s)}function Rb(i,s,u,c){let f=typeof i=="string"?new URL(i,typeof window>"u"?"server://singlefetch/":window.location.origin):i;return u?f.pathname.endsWith("/")?f.pathname=`${f.pathname}_.${c}`:f.pathname=`${f.pathname}.${c}`:f.pathname==="/"?f.pathname=`_root.${c}`:s&&Oa(f.pathname,s)==="/"?f.pathname=`${s.replace(/\/$/,"")}/_root.${c}`:f.pathname=`${f.pathname.replace(/\/$/,"")}.${c}`,f}async function _b(i,s){if(i.id in s)return s[i.id];try{let u=await import(i.module);return s[i.id]=u,u}catch(u){return console.error(`Error loading route module \`${i.module}\`, reloading page...`),console.error(u),window.__reactRouterContext&&window.__reactRouterContext.isSpaMode,window.location.reload(),new Promise(()=>{})}}function Mb(i){return i==null?!1:i.href==null?i.rel==="preload"&&typeof i.imageSrcSet=="string"&&typeof i.imageSizes=="string":typeof i.rel=="string"&&typeof i.href=="string"}async function Db(i,s,u){let c=await Promise.all(i.map(async f=>{let p=s.routes[f.route.id];if(p){let h=await _b(p,u);return h.links?h.links():[]}return[]}));return Bb(c.flat(1).filter(Mb).filter(f=>f.rel==="stylesheet"||f.rel==="preload").map(f=>f.rel==="stylesheet"?{...f,rel:"prefetch",as:"style"}:{...f,rel:"prefetch"}))}function I0(i,s,u,c,f,p){let h=(x,g)=>u[g]?x.route.id!==u[g].route.id:!0,v=(x,g)=>u[g].pathname!==x.pathname||u[g].route.path?.endsWith("*")&&u[g].params["*"]!==x.params["*"];return p==="assets"?s.filter((x,g)=>h(x,g)||v(x,g)):p==="data"?s.filter((x,g)=>{let b=c.routes[x.route.id];if(!b||!b.hasLoader)return!1;if(h(x,g)||v(x,g))return!0;if(x.route.shouldRevalidate){let y=x.route.shouldRevalidate({currentUrl:new URL(f.pathname+f.search+f.hash,window.origin),currentParams:u[0]?.params||{},nextUrl:new URL(i,window.origin),nextParams:x.params,defaultShouldRevalidate:!0});if(typeof y=="boolean")return y}return!0}):[]}function Ob(i,s,{includeHydrateFallback:u}={}){return Hb(i.map(c=>{let f=s.routes[c.route.id];if(!f)return[];let p=[f.module];return f.clientActionModule&&(p=p.concat(f.clientActionModule)),f.clientLoaderModule&&(p=p.concat(f.clientLoaderModule)),u&&f.hydrateFallbackModule&&(p=p.concat(f.hydrateFallbackModule)),f.imports&&(p=p.concat(f.imports)),p}).flat(1))}function Hb(i){return[...new Set(i)]}function Ub(i){let s={},u=Object.keys(i).sort();for(let c of u)s[c]=i[c];return s}function Bb(i,s){let u=new Set;return new Set(s),i.reduce((c,f)=>{let p=JSON.stringify(Ub(f));return u.has(p)||(u.add(p),c.push({key:p,link:f})),c},[])}function Qm(){let i=A.useContext($i);return vd(i,"You must render this element inside a <DataRouterContext.Provider> element"),i}function Lb(){let i=A.useContext(Ko);return vd(i,"You must render this element inside a <DataRouterStateContext.Provider> element"),i}var jd=A.createContext(void 0);jd.displayName="FrameworkContext";function Vm(){let i=A.useContext(jd);return vd(i,"You must render this element inside a <HydratedRouter> element"),i}function qb(i,s){let u=A.useContext(jd),[c,f]=A.useState(!1),[p,h]=A.useState(!1),{onFocus:v,onBlur:x,onMouseEnter:g,onMouseLeave:b,onTouchStart:y}=s,k=A.useRef(null);A.useEffect(()=>{if(i==="render"&&h(!0),i==="viewport"){let q=U=>{U.forEach(Q=>{h(Q.isIntersecting)})},Y=new IntersectionObserver(q,{threshold:.5});return k.current&&Y.observe(k.current),()=>{Y.disconnect()}}},[i]),A.useEffect(()=>{if(c){let q=setTimeout(()=>{h(!0)},100);return()=>{clearTimeout(q)}}},[c]);let D=()=>{f(!0)},_=()=>{f(!1),h(!1)};return u?i!=="intent"?[p,k,{}]:[p,k,{onFocus:Bl(v,D),onBlur:Bl(x,_),onMouseEnter:Bl(g,D),onMouseLeave:Bl(b,_),onTouchStart:Bl(y,D)}]:[!1,k,{}]}function Bl(i,s){return u=>{i&&i(u),u.defaultPrevented||s(u)}}function Yb({page:i,...s}){let{router:u}=Qm(),c=A.useMemo(()=>Nm(u.routes,i,u.basename),[u.routes,i,u.basename]);return c?A.createElement(Gb,{page:i,matches:c,...s}):null}function $b(i){let{manifest:s,routeModules:u}=Vm(),[c,f]=A.useState([]);return A.useEffect(()=>{let p=!1;return Db(i,s,u).then(h=>{p||f(h)}),()=>{p=!0}},[i,s,u]),c}function Gb({page:i,matches:s,...u}){let c=Ua(),{future:f,manifest:p,routeModules:h}=Vm(),{basename:v}=Qm(),{loaderData:x,matches:g}=Lb(),b=A.useMemo(()=>I0(i,s,g,p,c,"data"),[i,s,g,p,c]),y=A.useMemo(()=>I0(i,s,g,p,c,"assets"),[i,s,g,p,c]),k=A.useMemo(()=>{if(i===c.pathname+c.search+c.hash)return[];let q=new Set,Y=!1;if(s.forEach(Q=>{let Z=p.routes[Q.route.id];!Z||!Z.hasLoader||(!b.some(V=>V.route.id===Q.route.id)&&Q.route.id in x&&h[Q.route.id]?.shouldRevalidate||Z.hasClientLoader?Y=!0:q.add(Q.route.id))}),q.size===0)return[];let U=Rb(i,v,f.unstable_trailingSlashAwareDataRequests,"data");return Y&&q.size>0&&U.searchParams.set("_routes",s.filter(Q=>q.has(Q.route.id)).map(Q=>Q.route.id).join(",")),[U.pathname+U.search]},[v,f.unstable_trailingSlashAwareDataRequests,x,c,p,b,s,i,h]),D=A.useMemo(()=>Ob(y,p),[y,p]),_=$b(y);return A.createElement(A.Fragment,null,k.map(q=>A.createElement("link",{key:q,rel:"prefetch",as:"fetch",href:q,...u})),D.map(q=>A.createElement("link",{key:q,rel:"modulepreload",href:q,...u})),_.map(({key:q,link:Y})=>A.createElement("link",{key:q,nonce:u.nonce,...Y,crossOrigin:Y.crossOrigin??u.crossOrigin})))}function Qb(...i){return s=>{i.forEach(u=>{typeof u=="function"?u(s):u!=null&&(u.current=s)})}}var Vb=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";try{Vb&&(window.__reactRouterVersion="7.13.0")}catch{}function Xb({basename:i,children:s,unstable_useTransitions:u,window:c}){let f=A.useRef();f.current==null&&(f.current=wy({window:c,v5Compat:!0}));let p=f.current,[h,v]=A.useState({action:p.action,location:p.location}),x=A.useCallback(g=>{u===!1?v(g):A.startTransition(()=>v(g))},[u]);return A.useLayoutEffect(()=>p.listen(x),[p,x]),A.createElement(jb,{basename:i,children:s,location:h.location,navigationType:h.action,navigator:p,unstable_useTransitions:u})}var Xm=/^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,Ze=A.forwardRef(function({onClick:s,discover:u="render",prefetch:c="none",relative:f,reloadDocument:p,replace:h,state:v,target:x,to:g,preventScrollReset:b,viewTransition:y,unstable_defaultShouldRevalidate:k,...D},_){let{basename:q,unstable_useTransitions:Y}=A.useContext(Jt),U=typeof g=="string"&&Xm.test(g),Q=Om(g,q);g=Q.to;let Z=nb(g,{relative:f}),[V,te,ee]=qb(c,D),$=Jb(g,{replace:h,state:v,target:x,preventScrollReset:b,relative:f,viewTransition:y,unstable_defaultShouldRevalidate:k,unstable_useTransitions:Y});function J(Oe){s&&s(Oe),Oe.defaultPrevented||$(Oe)}let he=A.createElement("a",{...D,...ee,href:Q.absoluteURL||Z,onClick:Q.isExternal||p?s:J,ref:Qb(_,te),target:x,"data-discover":!U&&u==="render"?"true":void 0});return V&&!U?A.createElement(A.Fragment,null,he,A.createElement(Yb,{page:Z})):he});Ze.displayName="Link";var Kb=A.forwardRef(function({"aria-current":s="page",caseSensitive:u=!1,className:c="",end:f=!1,style:p,to:h,viewTransition:v,children:x,...g},b){let y=Pl(h,{relative:g.relative}),k=Ua(),D=A.useContext(Ko),{navigator:_,basename:q}=A.useContext(Jt),Y=D!=null&&tv(y)&&v===!0,U=_.encodeLocation?_.encodeLocation(y).pathname:y.pathname,Q=k.pathname,Z=D&&D.navigation&&D.navigation.location?D.navigation.location.pathname:null;u||(Q=Q.toLowerCase(),Z=Z?Z.toLowerCase():null,U=U.toLowerCase()),Z&&q&&(Z=Oa(Z,q)||Z);const V=U!=="/"&&U.endsWith("/")?U.length-1:U.length;let te=Q===U||!f&&Q.startsWith(U)&&Q.charAt(V)==="/",ee=Z!=null&&(Z===U||!f&&Z.startsWith(U)&&Z.charAt(U.length)==="/"),$={isActive:te,isPending:ee,isTransitioning:Y},J=te?s:void 0,he;typeof c=="function"?he=c($):he=[c,te?"active":null,ee?"pending":null,Y?"transitioning":null].filter(Boolean).join(" ");let Oe=typeof p=="function"?p($):p;return A.createElement(Ze,{...g,"aria-current":J,className:he,ref:b,style:Oe,to:h,viewTransition:v},typeof x=="function"?x($):x)});Kb.displayName="NavLink";var Zb=A.forwardRef(({discover:i="render",fetcherKey:s,navigate:u,reloadDocument:c,replace:f,state:p,method:h=Do,action:v,onSubmit:x,relative:g,preventScrollReset:b,viewTransition:y,unstable_defaultShouldRevalidate:k,...D},_)=>{let{unstable_useTransitions:q}=A.useContext(Jt),Y=Pb(),U=ev(v,{relative:g}),Q=h.toLowerCase()==="get"?"get":"post",Z=typeof v=="string"&&Xm.test(v),V=te=>{if(x&&x(te),te.defaultPrevented)return;te.preventDefault();let ee=te.nativeEvent.submitter,$=ee?.getAttribute("formmethod")||h,J=()=>Y(ee||te.currentTarget,{fetcherKey:s,method:$,navigate:u,replace:f,state:p,relative:g,preventScrollReset:b,viewTransition:y,unstable_defaultShouldRevalidate:k});q&&u!==!1?A.startTransition(()=>J()):J()};return A.createElement("form",{ref:_,method:Q,action:U,onSubmit:c?x:V,...D,"data-discover":!Z&&i==="render"?"true":void 0})});Zb.displayName="Form";function Wb(i){return`${i} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function Km(i){let s=A.useContext($i);return Ye(s,Wb(i)),s}function Jb(i,{target:s,replace:u,state:c,preventScrollReset:f,relative:p,viewTransition:h,unstable_defaultShouldRevalidate:v,unstable_useTransitions:x}={}){let g=gn(),b=Ua(),y=Pl(i,{relative:p});return A.useCallback(k=>{if(Eb(k,s)){k.preventDefault();let D=u!==void 0?u:Kl(b)===Kl(y),_=()=>g(i,{replace:D,state:c,preventScrollReset:f,relative:p,viewTransition:h,unstable_defaultShouldRevalidate:v});x?A.startTransition(()=>_()):_()}},[b,g,y,u,c,s,i,f,p,h,v,x])}var Fb=0,Ib=()=>`__${String(++Fb)}__`;function Pb(){let{router:i}=Km("useSubmit"),{basename:s}=A.useContext(Jt),u=gb(),c=i.fetch,f=i.navigate;return A.useCallback(async(p,h={})=>{let{action:v,method:x,encType:g,formData:b,body:y}=kb(p,s);if(h.navigate===!1){let k=h.fetcherKey||Ib();await c(k,u,h.action||v,{unstable_defaultShouldRevalidate:h.unstable_defaultShouldRevalidate,preventScrollReset:h.preventScrollReset,formData:b,body:y,formMethod:h.method||x,formEncType:h.encType||g,flushSync:h.flushSync})}else await f(h.action||v,{unstable_defaultShouldRevalidate:h.unstable_defaultShouldRevalidate,preventScrollReset:h.preventScrollReset,formData:b,body:y,formMethod:h.method||x,formEncType:h.encType||g,replace:h.replace,state:h.state,fromRouteId:u,flushSync:h.flushSync,viewTransition:h.viewTransition})},[c,f,s,u])}function ev(i,{relative:s}={}){let{basename:u}=A.useContext(Jt),c=A.useContext(ia);Ye(c,"useFormAction must be used inside a RouteContext");let[f]=c.matches.slice(-1),p={...Pl(i||".",{relative:s})},h=Ua();if(i==null){p.search=h.search;let v=new URLSearchParams(p.search),x=v.getAll("index");if(x.some(b=>b==="")){v.delete("index"),x.filter(y=>y).forEach(y=>v.append("index",y));let b=v.toString();p.search=b?`?${b}`:""}}return(!i||i===".")&&f.route.index&&(p.search=p.search?p.search.replace(/^\?/,"?index&"):"?index"),u!=="/"&&(p.pathname=p.pathname==="/"?u:Da([u,p.pathname])),Kl(p)}function tv(i,{relative:s}={}){let u=A.useContext(Um);Ye(u!=null,"`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");let{basename:c}=Km("useViewTransitionState"),f=Pl(i,{relative:s});if(!u.isTransitioning)return!1;let p=Oa(u.currentLocation.pathname,c)||u.currentLocation.pathname,h=Oa(u.nextLocation.pathname,c)||u.nextLocation.pathname;return $o(f.pathname,h)!=null||$o(f.pathname,p)!=null}var lt=function(){return lt=Object.assign||function(s){for(var u,c=1,f=arguments.length;c<f;c++){u=arguments[c];for(var p in u)Object.prototype.hasOwnProperty.call(u,p)&&(s[p]=u[p])}return s},lt.apply(this,arguments)};function Oi(i,s,u){if(u||arguments.length===2)for(var c=0,f=s.length,p;c<f;c++)(p||!(c in s))&&(p||(p=Array.prototype.slice.call(s,0,c)),p[c]=s[c]);return i.concat(p||Array.prototype.slice.call(s))}var Be="-ms-",Ql="-moz-",Ae="-webkit-",Zm="comm",Wo="rule",Sd="decl",av="@import",nv="@namespace",Wm="@keyframes",iv="@layer",Jm=Math.abs,wd=String.fromCharCode,Iu=Object.assign;function lv(i,s){return at(i,0)^45?(((s<<2^at(i,0))<<2^at(i,1))<<2^at(i,2))<<2^at(i,3):0}function Fm(i){return i.trim()}function _a(i,s){return(i=s.exec(i))?i[0]:i}function de(i,s,u){return i.replace(s,u)}function Ho(i,s,u){return i.indexOf(s,u)}function at(i,s){return i.charCodeAt(s)|0}function Yn(i,s,u){return i.slice(s,u)}function ea(i){return i.length}function Im(i){return i.length}function Gl(i,s){return s.push(i),i}function rv(i,s){return i.map(s).join("")}function P0(i,s){return i.filter(function(u){return!_a(u,s)})}var Jo=1,Hi=1,Pm=0,Wt=0,et=0,Gi="";function Fo(i,s,u,c,f,p,h,v){return{value:i,root:s,parent:u,type:c,props:f,children:p,line:Jo,column:Hi,length:h,return:"",siblings:v}}function un(i,s){return Iu(Fo("",null,null,"",null,null,0,i.siblings),i,{length:-i.length},s)}function Ti(i){for(;i.root;)i=un(i.root,{children:[i]});Gl(i,i.siblings)}function ov(){return et}function sv(){return et=Wt>0?at(Gi,--Wt):0,Hi--,et===10&&(Hi=1,Jo--),et}function aa(){return et=Wt<Pm?at(Gi,Wt++):0,Hi++,et===10&&(Hi=1,Jo++),et}function fn(){return at(Gi,Wt)}function Uo(){return Wt}function Io(i,s){return Yn(Gi,i,s)}function Zl(i){switch(i){case 0:case 9:case 10:case 13:case 32:return 5;case 33:case 43:case 44:case 47:case 62:case 64:case 126:case 59:case 123:case 125:return 4;case 58:return 3;case 34:case 39:case 40:case 91:return 2;case 41:case 93:return 1}return 0}function cv(i){return Jo=Hi=1,Pm=ea(Gi=i),Wt=0,[]}function uv(i){return Gi="",i}function ku(i){return Fm(Io(Wt-1,Pu(i===91?i+2:i===40?i+1:i)))}function dv(i){for(;(et=fn())&&et<33;)aa();return Zl(i)>2||Zl(et)>3?"":" "}function fv(i,s){for(;--s&&aa()&&!(et<48||et>102||et>57&&et<65||et>70&&et<97););return Io(i,Uo()+(s<6&&fn()==32&&aa()==32))}function Pu(i){for(;aa();)switch(et){case i:return Wt;case 34:case 39:i!==34&&i!==39&&Pu(et);break;case 40:i===41&&Pu(i);break;case 92:aa();break}return Wt}function hv(i,s){for(;aa()&&i+et!==57;)if(i+et===84&&fn()===47)break;return"/*"+Io(s,Wt-1)+"*"+wd(i===47?i:aa())}function pv(i){for(;!Zl(fn());)aa();return Io(i,Wt)}function mv(i){return uv(Bo("",null,null,null,[""],i=cv(i),0,[0],i))}function Bo(i,s,u,c,f,p,h,v,x){for(var g=0,b=0,y=h,k=0,D=0,_=0,q=1,Y=1,U=1,Q=0,Z="",V=f,te=p,ee=c,$=Z;Y;)switch(_=Q,Q=aa()){case 40:if(_!=108&&at($,y-1)==58){Ho($+=de(ku(Q),"&","&\f"),"&\f",Jm(g?v[g-1]:0))!=-1&&(U=-1);break}case 34:case 39:case 91:$+=ku(Q);break;case 9:case 10:case 13:case 32:$+=dv(_);break;case 92:$+=fv(Uo()-1,7);continue;case 47:switch(fn()){case 42:case 47:Gl(gv(hv(aa(),Uo()),s,u,x),x),(Zl(_||1)==5||Zl(fn()||1)==5)&&ea($)&&Yn($,-1,void 0)!==" "&&($+=" ");break;default:$+="/"}break;case 123*q:v[g++]=ea($)*U;case 125*q:case 59:case 0:switch(Q){case 0:case 125:Y=0;case 59+b:U==-1&&($=de($,/\f/g,"")),D>0&&(ea($)-y||q===0&&_===47)&&Gl(D>32?tm($+";",c,u,y-1,x):tm(de($," ","")+";",c,u,y-2,x),x);break;case 59:$+=";";default:if(Gl(ee=em($,s,u,g,b,f,v,Z,V=[],te=[],y,p),p),Q===123)if(b===0)Bo($,s,ee,ee,V,p,y,v,te);else{switch(k){case 99:if(at($,3)===110)break;case 108:if(at($,2)===97)break;default:b=0;case 100:case 109:case 115:}b?Bo(i,ee,ee,c&&Gl(em(i,ee,ee,0,0,f,v,Z,f,V=[],y,te),te),f,te,y,v,c?V:te):Bo($,ee,ee,ee,[""],te,0,v,te)}}g=b=D=0,q=U=1,Z=$="",y=h;break;case 58:y=1+ea($),D=_;default:if(q<1){if(Q==123)--q;else if(Q==125&&q++==0&&sv()==125)continue}switch($+=wd(Q),Q*q){case 38:U=b>0?1:($+="\f",-1);break;case 44:v[g++]=(ea($)-1)*U,U=1;break;case 64:fn()===45&&($+=ku(aa())),k=fn(),b=y=ea(Z=$+=pv(Uo())),Q++;break;case 45:_===45&&ea($)==2&&(q=0)}}return p}function em(i,s,u,c,f,p,h,v,x,g,b,y){for(var k=f-1,D=f===0?p:[""],_=Im(D),q=0,Y=0,U=0;q<c;++q)for(var Q=0,Z=Yn(i,k+1,k=Jm(Y=h[q])),V=i;Q<_;++Q)(V=Fm(Y>0?D[Q]+" "+Z:de(Z,/&\f/g,D[Q])))&&(x[U++]=V);return Fo(i,s,u,f===0?Wo:v,x,g,b,y)}function gv(i,s,u,c){return Fo(i,s,u,Zm,wd(ov()),Yn(i,2,-2),0,c)}function tm(i,s,u,c,f){return Fo(i,s,u,Sd,Yn(i,0,c),Yn(i,c+1,-1),c,f)}function eg(i,s,u){switch(lv(i,s)){case 5103:return Ae+"print-"+i+i;case 5737:case 4201:case 3177:case 3433:case 1641:case 4457:case 2921:case 5572:case 6356:case 5844:case 3191:case 6645:case 3005:case 4215:case 6389:case 5109:case 5365:case 5621:case 3829:case 6391:case 5879:case 5623:case 6135:case 4599:return Ae+i+i;case 4855:return Ae+i.replace("add","source-over").replace("substract","source-out").replace("intersect","source-in").replace("exclude","xor")+i;case 4789:return Ql+i+i;case 5349:case 4246:case 4810:case 6968:case 2756:return Ae+i+Ql+i+Be+i+i;case 5936:switch(at(i,s+11)){case 114:return Ae+i+Be+de(i,/[svh]\w+-[tblr]{2}/,"tb")+i;case 108:return Ae+i+Be+de(i,/[svh]\w+-[tblr]{2}/,"tb-rl")+i;case 45:return Ae+i+Be+de(i,/[svh]\w+-[tblr]{2}/,"lr")+i}case 6828:case 4268:case 2903:return Ae+i+Be+i+i;case 6165:return Ae+i+Be+"flex-"+i+i;case 5187:return Ae+i+de(i,/(\w+).+(:[^]+)/,Ae+"box-$1$2"+Be+"flex-$1$2")+i;case 5443:return Ae+i+Be+"flex-item-"+de(i,/flex-|-self/g,"")+(_a(i,/flex-|baseline/)?"":Be+"grid-row-"+de(i,/flex-|-self/g,""))+i;case 4675:return Ae+i+Be+"flex-line-pack"+de(i,/align-content|flex-|-self/g,"")+i;case 5548:return Ae+i+Be+de(i,"shrink","negative")+i;case 5292:return Ae+i+Be+de(i,"basis","preferred-size")+i;case 6060:return Ae+"box-"+de(i,"-grow","")+Ae+i+Be+de(i,"grow","positive")+i;case 4554:return Ae+de(i,/([^-])(transform)/g,"$1"+Ae+"$2")+i;case 6187:return de(de(de(i,/(zoom-|grab)/,Ae+"$1"),/(image-set)/,Ae+"$1"),i,"")+i;case 5495:case 3959:return de(i,/(image-set\([^]*)/,Ae+"$1$`$1");case 4968:return de(de(i,/(.+:)(flex-)?(.*)/,Ae+"box-pack:$3"+Be+"flex-pack:$3"),/space-between/,"justify")+Ae+i+i;case 4200:if(!_a(i,/flex-|baseline/))return Be+"grid-column-align"+Yn(i,s)+i;break;case 2592:case 3360:return Be+de(i,"template-","")+i;case 4384:case 3616:return u&&u.some(function(c,f){return s=f,_a(c.props,/grid-\w+-end/)})?~Ho(i+(u=u[s].value),"span",0)?i:Be+de(i,"-start","")+i+Be+"grid-row-span:"+(~Ho(u,"span",0)?_a(u,/\d+/):+_a(u,/\d+/)-+_a(i,/\d+/))+";":Be+de(i,"-start","")+i;case 4896:case 4128:return u&&u.some(function(c){return _a(c.props,/grid-\w+-start/)})?i:Be+de(de(i,"-end","-span"),"span ","")+i;case 4095:case 3583:case 4068:case 2532:return de(i,/(.+)-inline(.+)/,Ae+"$1$2")+i;case 8116:case 7059:case 5753:case 5535:case 5445:case 5701:case 4933:case 4677:case 5533:case 5789:case 5021:case 4765:if(ea(i)-1-s>6)switch(at(i,s+1)){case 109:if(at(i,s+4)!==45)break;case 102:return de(i,/(.+:)(.+)-([^]+)/,"$1"+Ae+"$2-$3$1"+Ql+(at(i,s+3)==108?"$3":"$2-$3"))+i;case 115:return~Ho(i,"stretch",0)?eg(de(i,"stretch","fill-available"),s,u)+i:i}break;case 5152:case 5920:return de(i,/(.+?):(\d+)(\s*\/\s*(span)?\s*(\d+))?(.*)/,function(c,f,p,h,v,x,g){return Be+f+":"+p+g+(h?Be+f+"-span:"+(v?x:+x-+p)+g:"")+i});case 4949:if(at(i,s+6)===121)return de(i,":",":"+Ae)+i;break;case 6444:switch(at(i,at(i,14)===45?18:11)){case 120:return de(i,/(.+:)([^;\s!]+)(;|(\s+)?!.+)?/,"$1"+Ae+(at(i,14)===45?"inline-":"")+"box$3$1"+Ae+"$2$3$1"+Be+"$2box$3")+i;case 100:return de(i,":",":"+Be)+i}break;case 5719:case 2647:case 2135:case 3927:case 2391:return de(i,"scroll-","scroll-snap-")+i}return i}function Go(i,s){for(var u="",c=0;c<i.length;c++)u+=s(i[c],c,i,s)||"";return u}function xv(i,s,u,c){switch(i.type){case iv:if(i.children.length)break;case av:case nv:case Sd:return i.return=i.return||i.value;case Zm:return"";case Wm:return i.return=i.value+"{"+Go(i.children,c)+"}";case Wo:if(!ea(i.value=i.props.join(",")))return""}return ea(u=Go(i.children,c))?i.return=i.value+"{"+u+"}":""}function yv(i){var s=Im(i);return function(u,c,f,p){for(var h="",v=0;v<s;v++)h+=i[v](u,c,f,p)||"";return h}}function bv(i){return function(s){s.root||(s=s.return)&&i(s)}}function vv(i,s,u,c){if(i.length>-1&&!i.return)switch(i.type){case Sd:i.return=eg(i.value,i.length,u);return;case Wm:return Go([un(i,{value:de(i.value,"@","@"+Ae)})],c);case Wo:if(i.length)return rv(u=i.props,function(f){switch(_a(f,c=/(::plac\w+|:read-\w+)/)){case":read-only":case":read-write":Ti(un(i,{props:[de(f,/:(read-\w+)/,":"+Ql+"$1")]})),Ti(un(i,{props:[f]})),Iu(i,{props:P0(u,c)});break;case"::placeholder":Ti(un(i,{props:[de(f,/:(plac\w+)/,":"+Ae+"input-$1")]})),Ti(un(i,{props:[de(f,/:(plac\w+)/,":"+Ql+"$1")]})),Ti(un(i,{props:[de(f,/:(plac\w+)/,Be+"input-$1")]})),Ti(un(i,{props:[f]})),Iu(i,{props:P0(u,c)});break}return""})}}var jv={animationIterationCount:1,aspectRatio:1,borderImageOutset:1,borderImageSlice:1,borderImageWidth:1,boxFlex:1,boxFlexGroup:1,boxOrdinalGroup:1,columnCount:1,columns:1,flex:1,flexGrow:1,flexPositive:1,flexShrink:1,flexNegative:1,flexOrder:1,gridRow:1,gridRowEnd:1,gridRowSpan:1,gridRowStart:1,gridColumn:1,gridColumnEnd:1,gridColumnSpan:1,gridColumnStart:1,msGridRow:1,msGridRowSpan:1,msGridColumn:1,msGridColumnSpan:1,fontWeight:1,lineHeight:1,opacity:1,order:1,orphans:1,scale:1,tabSize:1,widows:1,zIndex:1,zoom:1,WebkitLineClamp:1,fillOpacity:1,floodOpacity:1,stopOpacity:1,strokeDasharray:1,strokeDashoffset:1,strokeMiterlimit:1,strokeOpacity:1,strokeWidth:1},Dt={},Ui=typeof process<"u"&&Dt!==void 0&&(Dt.REACT_APP_SC_ATTR||Dt.SC_ATTR)||"data-styled",tg="active",ag="data-styled-version",Po="6.3.9",Cd=`/*!sc*/
`,Vl=typeof window<"u"&&typeof document<"u",Kt=Ve.createContext===void 0,Sv=!!(typeof SC_DISABLE_SPEEDY=="boolean"?SC_DISABLE_SPEEDY:typeof process<"u"&&Dt!==void 0&&Dt.REACT_APP_SC_DISABLE_SPEEDY!==void 0&&Dt.REACT_APP_SC_DISABLE_SPEEDY!==""?Dt.REACT_APP_SC_DISABLE_SPEEDY!=="false"&&Dt.REACT_APP_SC_DISABLE_SPEEDY:typeof process<"u"&&Dt!==void 0&&Dt.SC_DISABLE_SPEEDY!==void 0&&Dt.SC_DISABLE_SPEEDY!==""&&Dt.SC_DISABLE_SPEEDY!=="false"&&Dt.SC_DISABLE_SPEEDY),wv={},Ad=Object.freeze([]),Bi=Object.freeze({});function ng(i,s,u){return u===void 0&&(u=Bi),i.theme!==u.theme&&i.theme||s||u.theme}var ig=new Set(["a","abbr","address","area","article","aside","audio","b","bdi","bdo","blockquote","body","button","br","canvas","caption","cite","code","col","colgroup","data","datalist","dd","del","details","dfn","dialog","div","dl","dt","em","embed","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","header","hgroup","hr","html","i","iframe","img","input","ins","kbd","label","legend","li","main","map","mark","menu","meter","nav","object","ol","optgroup","option","output","p","picture","pre","progress","q","rp","rt","ruby","s","samp","search","section","select","slot","small","span","strong","sub","summary","sup","table","tbody","td","template","textarea","tfoot","th","thead","time","tr","u","ul","var","video","wbr","circle","clipPath","defs","ellipse","feBlend","feColorMatrix","feComponentTransfer","feComposite","feConvolveMatrix","feDiffuseLighting","feDisplacementMap","feDistantLight","feDropShadow","feFlood","feFuncA","feFuncB","feFuncG","feFuncR","feGaussianBlur","feImage","feMerge","feMergeNode","feMorphology","feOffset","fePointLight","feSpecularLighting","feSpotLight","feTile","feTurbulence","filter","foreignObject","g","image","line","linearGradient","marker","mask","path","pattern","polygon","polyline","radialGradient","rect","stop","svg","switch","symbol","text","textPath","tspan","use"]),Cv=/[!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~-]+/g,Av=/(^-|-$)/g;function am(i){return i.replace(Cv,"-").replace(Av,"")}var zv=/(a)(d)/gi,nm=function(i){return String.fromCharCode(i+(i>25?39:97))};function ed(i){var s,u="";for(s=Math.abs(i);s>52;s=s/52|0)u=nm(s%52)+u;return(nm(s%52)+u).replace(zv,"$1-$2")}var Ru,Hn=function(i,s){for(var u=s.length;u;)i=33*i^s.charCodeAt(--u);return i},lg=function(i){return Hn(5381,i)};function zd(i){return ed(lg(i)>>>0)}function Ev(i){return i.displayName||i.name||"Component"}function _u(i){return typeof i=="string"&&!0}var rg=typeof Symbol=="function"&&Symbol.for,og=rg?Symbol.for("react.memo"):60115,Tv=rg?Symbol.for("react.forward_ref"):60112,Nv={childContextTypes:!0,contextType:!0,contextTypes:!0,defaultProps:!0,displayName:!0,getDefaultProps:!0,getDerivedStateFromError:!0,getDerivedStateFromProps:!0,mixins:!0,propTypes:!0,type:!0},kv={name:!0,length:!0,prototype:!0,caller:!0,callee:!0,arguments:!0,arity:!0},sg={$$typeof:!0,compare:!0,defaultProps:!0,displayName:!0,propTypes:!0,type:!0},Rv=((Ru={})[Tv]={$$typeof:!0,render:!0,defaultProps:!0,displayName:!0,propTypes:!0},Ru[og]=sg,Ru);function im(i){return("type"in(s=i)&&s.type.$$typeof)===og?sg:"$$typeof"in i?Rv[i.$$typeof]:Nv;var s}var _v=Object.defineProperty,Mv=Object.getOwnPropertyNames,lm=Object.getOwnPropertySymbols,Dv=Object.getOwnPropertyDescriptor,Ov=Object.getPrototypeOf,rm=Object.prototype;function cg(i,s,u){if(typeof s!="string"){if(rm){var c=Ov(s);c&&c!==rm&&cg(i,c,u)}var f=Mv(s);lm&&(f=f.concat(lm(s)));for(var p=im(i),h=im(s),v=0;v<f.length;++v){var x=f[v];if(!(x in kv||u&&u[x]||h&&x in h||p&&x in p)){var g=Dv(s,x);try{_v(i,x,g)}catch{}}}}return i}function $n(i){return typeof i=="function"}function Ed(i){return typeof i=="object"&&"styledComponentId"in i}function Bn(i,s){return i&&s?"".concat(i," ").concat(s):i||s||""}function Qo(i,s){return i.join("")}function Wl(i){return i!==null&&typeof i=="object"&&i.constructor.name===Object.name&&!("props"in i&&i.$$typeof)}function td(i,s,u){if(u===void 0&&(u=!1),!u&&!Wl(i)&&!Array.isArray(i))return s;if(Array.isArray(s))for(var c=0;c<s.length;c++)i[c]=td(i[c],s[c]);else if(Wl(s))for(var c in s)i[c]=td(i[c],s[c]);return i}function Td(i,s){Object.defineProperty(i,"toString",{value:s})}function mn(i){for(var s=[],u=1;u<arguments.length;u++)s[u-1]=arguments[u];return new Error("An error occurred. See https://github.com/styled-components/styled-components/blob/main/packages/styled-components/src/utils/errors.md#".concat(i," for more information.").concat(s.length>0?" Args: ".concat(s.join(", ")):""))}var Hv=(function(){function i(s){this.groupSizes=new Uint32Array(512),this.length=512,this.tag=s,this._cGroup=0,this._cIndex=0}return i.prototype.indexOfGroup=function(s){if(s===this._cGroup)return this._cIndex;var u=this._cIndex;if(s>this._cGroup)for(var c=this._cGroup;c<s;c++)u+=this.groupSizes[c];else for(c=this._cGroup-1;c>=s;c--)u-=this.groupSizes[c];return this._cGroup=s,this._cIndex=u,u},i.prototype.insertRules=function(s,u){if(s>=this.groupSizes.length){for(var c=this.groupSizes,f=c.length,p=f;s>=p;)if((p<<=1)<0)throw mn(16,"".concat(s));this.groupSizes=new Uint32Array(p),this.groupSizes.set(c),this.length=p;for(var h=f;h<p;h++)this.groupSizes[h]=0}for(var v=this.indexOfGroup(s+1),x=0,g=(h=0,u.length);h<g;h++)this.tag.insertRule(v,u[h])&&(this.groupSizes[s]++,v++,x++);x>0&&this._cGroup>s&&(this._cIndex+=x)},i.prototype.clearGroup=function(s){if(s<this.length){var u=this.groupSizes[s],c=this.indexOfGroup(s),f=c+u;this.groupSizes[s]=0;for(var p=c;p<f;p++)this.tag.deleteRule(c);u>0&&this._cGroup>s&&(this._cIndex-=u)}},i.prototype.getGroup=function(s){var u="";if(s>=this.length||this.groupSizes[s]===0)return u;for(var c=this.groupSizes[s],f=this.indexOfGroup(s),p=f+c,h=f;h<p;h++)u+=this.tag.getRule(h)+Cd;return u},i})(),Lo=new Map,Vo=new Map,qo=1,_i=function(i){if(Lo.has(i))return Lo.get(i);for(;Vo.has(qo);)qo++;var s=qo++;return Lo.set(i,s),Vo.set(s,i),s},Uv=function(i,s){qo=s+1,Lo.set(i,s),Vo.set(s,i)},Bv="style[".concat(Ui,"][").concat(ag,'="').concat(Po,'"]'),Lv=new RegExp("^".concat(Ui,'\\.g(\\d+)\\[id="([\\w\\d-]+)"\\].*?"([^"]*)')),om=function(i){return typeof ShadowRoot<"u"&&i instanceof ShadowRoot||"host"in i&&i.nodeType===11},ad=function(i){if(!i)return document;if(om(i))return i;if("getRootNode"in i){var s=i.getRootNode();if(om(s))return s}return document},qv=function(i,s,u){for(var c,f=u.split(","),p=0,h=f.length;p<h;p++)(c=f[p])&&i.registerName(s,c)},Yv=function(i,s){for(var u,c=((u=s.textContent)!==null&&u!==void 0?u:"").split(Cd),f=[],p=0,h=c.length;p<h;p++){var v=c[p].trim();if(v){var x=v.match(Lv);if(x){var g=0|parseInt(x[1],10),b=x[2];g!==0&&(Uv(b,g),qv(i,b,x[3]),i.getTag().insertRules(g,f)),f.length=0}else f.push(v)}}},Mu=function(i){for(var s=ad(i.options.target).querySelectorAll(Bv),u=0,c=s.length;u<c;u++){var f=s[u];f&&f.getAttribute(Ui)!==tg&&(Yv(i,f),f.parentNode&&f.parentNode.removeChild(f))}};function $v(){return typeof __webpack_nonce__<"u"?__webpack_nonce__:null}var ug=function(i){var s=document.head,u=i||s,c=document.createElement("style"),f=(function(v){var x=Array.from(v.querySelectorAll("style[".concat(Ui,"]")));return x[x.length-1]})(u),p=f!==void 0?f.nextSibling:null;c.setAttribute(Ui,tg),c.setAttribute(ag,Po);var h=$v();return h&&c.setAttribute("nonce",h),u.insertBefore(c,p),c},Gv=(function(){function i(s){this.element=ug(s),this.element.appendChild(document.createTextNode("")),this.sheet=(function(u){var c;if(u.sheet)return u.sheet;for(var f=(c=u.getRootNode().styleSheets)!==null&&c!==void 0?c:document.styleSheets,p=0,h=f.length;p<h;p++){var v=f[p];if(v.ownerNode===u)return v}throw mn(17)})(this.element),this.length=0}return i.prototype.insertRule=function(s,u){try{return this.sheet.insertRule(u,s),this.length++,!0}catch{return!1}},i.prototype.deleteRule=function(s){this.sheet.deleteRule(s),this.length--},i.prototype.getRule=function(s){var u=this.sheet.cssRules[s];return u&&u.cssText?u.cssText:""},i})(),Qv=(function(){function i(s){this.element=ug(s),this.nodes=this.element.childNodes,this.length=0}return i.prototype.insertRule=function(s,u){if(s<=this.length&&s>=0){var c=document.createTextNode(u);return this.element.insertBefore(c,this.nodes[s]||null),this.length++,!0}return!1},i.prototype.deleteRule=function(s){this.element.removeChild(this.nodes[s]),this.length--},i.prototype.getRule=function(s){return s<this.length?this.nodes[s].textContent:""},i})(),Vv=(function(){function i(s){this.rules=[],this.length=0}return i.prototype.insertRule=function(s,u){return s<=this.length&&(s===this.length?this.rules.push(u):this.rules.splice(s,0,u),this.length++,!0)},i.prototype.deleteRule=function(s){this.rules.splice(s,1),this.length--},i.prototype.getRule=function(s){return s<this.length?this.rules[s]:""},i})(),sm=Vl,Xv={isServer:!Vl,useCSSOMInjection:!Sv},Xo=(function(){function i(s,u,c){s===void 0&&(s=Bi),u===void 0&&(u={});var f=this;this.options=lt(lt({},Xv),s),this.gs=u,this.names=new Map(c),this.server=!!s.isServer,!this.server&&Vl&&sm&&(sm=!1,Mu(this)),Td(this,function(){return(function(p){for(var h=p.getTag(),v=h.length,x="",g=function(y){var k=(function(U){return Vo.get(U)})(y);if(k===void 0)return"continue";var D=p.names.get(k);if(D===void 0||!D.size)return"continue";var _=h.getGroup(y);if(_.length===0)return"continue";var q=Ui+".g"+y+'[id="'+k+'"]',Y="";D.forEach(function(U){U.length>0&&(Y+=U+",")}),x+=_+q+'{content:"'+Y+'"}'+Cd},b=0;b<v;b++)g(b);return x})(f)})}return i.registerId=function(s){return _i(s)},i.prototype.rehydrate=function(){!this.server&&Vl&&Mu(this)},i.prototype.reconstructWithOptions=function(s,u){u===void 0&&(u=!0);var c=new i(lt(lt({},this.options),s),this.gs,u&&this.names||void 0);return!this.server&&Vl&&s.target!==this.options.target&&ad(this.options.target)!==ad(s.target)&&Mu(c),c},i.prototype.allocateGSInstance=function(s){return this.gs[s]=(this.gs[s]||0)+1},i.prototype.getTag=function(){return this.tag||(this.tag=(s=(function(u){var c=u.useCSSOMInjection,f=u.target;return u.isServer?new Vv(f):c?new Gv(f):new Qv(f)})(this.options),new Hv(s)));var s},i.prototype.hasNameForId=function(s,u){var c,f;return(f=(c=this.names.get(s))===null||c===void 0?void 0:c.has(u))!==null&&f!==void 0&&f},i.prototype.registerName=function(s,u){_i(s);var c=this.names.get(s);c?c.add(u):this.names.set(s,new Set([u]))},i.prototype.insertRules=function(s,u,c){this.registerName(s,u),this.getTag().insertRules(_i(s),c)},i.prototype.clearNames=function(s){this.names.has(s)&&this.names.get(s).clear()},i.prototype.clearRules=function(s){this.getTag().clearGroup(_i(s)),this.clearNames(s)},i.prototype.clearTag=function(){this.tag=void 0},i})(),Kv=/&/g,Ma=47,Un=42;function cm(i){if(i.indexOf("}")===-1)return!1;for(var s=i.length,u=0,c=0,f=!1,p=0;p<s;p++){var h=i.charCodeAt(p);if(c!==0||f||h!==Ma||i.charCodeAt(p+1)!==Un)if(f)h===Un&&i.charCodeAt(p+1)===Ma&&(f=!1,p++);else if(h!==34&&h!==39||p!==0&&i.charCodeAt(p-1)===92){if(c===0){if(h===123)u++;else if(h===125&&--u<0)return!0}}else c===0?c=h:c===h&&(c=0);else f=!0,p++}return u!==0||c!==0}function dg(i,s){return i.map(function(u){return u.type==="rule"&&(u.value="".concat(s," ").concat(u.value),u.value=u.value.replaceAll(",",",".concat(s," ")),u.props=u.props.map(function(c){return"".concat(s," ").concat(c)})),Array.isArray(u.children)&&u.type!=="@keyframes"&&(u.children=dg(u.children,s)),u})}function Zv(i){var s,u,c,f=Bi,p=f.options,h=p===void 0?Bi:p,v=f.plugins,x=v===void 0?Ad:v,g=function(_,q,Y){return Y.startsWith(u)&&Y.endsWith(u)&&Y.replaceAll(u,"").length>0?".".concat(s):_},b=x.slice();b.push(function(_){_.type===Wo&&_.value.includes("&")&&(c||(c=new RegExp("\\".concat(u,"\\b"),"g")),_.props[0]=_.props[0].replace(Kv,u).replace(c,g))}),h.prefix&&b.push(vv),b.push(xv);var y=[],k=yv(b.concat(bv(function(_){return y.push(_)}))),D=function(_,q,Y,U){q===void 0&&(q=""),Y===void 0&&(Y=""),U===void 0&&(U="&"),s=U,u=q,c=void 0;var Q=(function(V){if(!cm(V))return V;for(var te=V.length,ee="",$=0,J=0,he=0,Oe=!1,G=0;G<te;G++){var K=V.charCodeAt(G);if(he!==0||Oe||K!==Ma||V.charCodeAt(G+1)!==Un)if(Oe)K===Un&&V.charCodeAt(G+1)===Ma&&(Oe=!1,G++);else if(K!==34&&K!==39||G!==0&&V.charCodeAt(G-1)===92){if(he===0)if(K===123)J++;else if(K===125){if(--J<0){for(var ze=G+1;ze<te;){var Me=V.charCodeAt(ze);if(Me===59||Me===10)break;ze++}ze<te&&V.charCodeAt(ze)===59&&ze++,J=0,G=ze-1,$=ze;continue}J===0&&(ee+=V.substring($,G+1),$=G+1)}else K===59&&J===0&&(ee+=V.substring($,G+1),$=G+1)}else he===0?he=K:he===K&&(he=0);else Oe=!0,G++}if($<te){var be=V.substring($);cm(be)||(ee+=be)}return ee})((function(V){if(V.indexOf("//")===-1)return V;for(var te=V.length,ee=[],$=0,J=0,he=0,Oe=0;J<te;){var G=V.charCodeAt(J);if(G!==34&&G!==39||J!==0&&V.charCodeAt(J-1)===92)if(he===0)if(G===Ma&&J+1<te&&V.charCodeAt(J+1)===Un){for(J+=2;J+1<te&&(V.charCodeAt(J)!==Un||V.charCodeAt(J+1)!==Ma);)J++;J+=2}else if(G===40&&J>=3&&(32|V.charCodeAt(J-1))==108&&(32|V.charCodeAt(J-2))==114&&(32|V.charCodeAt(J-3))==117)Oe=1,J++;else if(Oe>0)G===41?Oe--:G===40&&Oe++,J++;else if(G===Un&&J+1<te&&V.charCodeAt(J+1)===Ma)J>$&&ee.push(V.substring($,J)),$=J+=2;else if(G===Ma&&J+1<te&&V.charCodeAt(J+1)===Ma){for(J>$&&ee.push(V.substring($,J));J<te&&V.charCodeAt(J)!==10;)J++;$=J}else J++;else J++;else he===0?he=G:he===G&&(he=0),J++}return $===0?V:($<te&&ee.push(V.substring($)),ee.join(""))})(_)),Z=mv(Y||q?"".concat(Y," ").concat(q," { ").concat(Q," }"):Q);return h.namespace&&(Z=dg(Z,h.namespace)),y=[],Go(Z,k),y};return D.hash=x.length?x.reduce(function(_,q){return q.name||mn(15),Hn(_,q.name)},5381).toString():"",D}var Wv=new Xo,nd=Zv(),id={shouldForwardProp:void 0,styleSheet:Wv,stylis:nd},fg=Kt?{Provider:function(i){return i.children},Consumer:function(i){return(0,i.children)(id)}}:Ve.createContext(id);fg.Consumer;Kt||Ve.createContext(void 0);function ld(){return Kt?id:Ve.useContext(fg)}var hg=(function(){function i(s,u){var c=this;this.inject=function(f,p){p===void 0&&(p=nd);var h=c.name+p.hash;f.hasNameForId(c.id,h)||f.insertRules(c.id,h,p(c.rules,h,"@keyframes"))},this.name=s,this.id="sc-keyframes-".concat(s),this.rules=u,Td(this,function(){throw mn(12,String(c.name))})}return i.prototype.getName=function(s){return s===void 0&&(s=nd),this.name+s.hash},i})();function Jv(i,s){return s==null||typeof s=="boolean"||s===""?"":typeof s!="number"||s===0||i in jv||i.startsWith("--")?String(s).trim():"".concat(s,"px")}var Fv=function(i){return i>="A"&&i<="Z"};function um(i){for(var s="",u=0;u<i.length;u++){var c=i[u];if(u===1&&c==="-"&&i[0]==="-")return i;Fv(c)?s+="-"+c.toLowerCase():s+=c}return s.startsWith("ms-")?"-"+s:s}var pg=function(i){return i==null||i===!1||i===""},mg=function(i){var s=[];for(var u in i){var c=i[u];i.hasOwnProperty(u)&&!pg(c)&&(Array.isArray(c)&&c.isCss||$n(c)?s.push("".concat(um(u),":"),c,";"):Wl(c)?s.push.apply(s,Oi(Oi(["".concat(u," {")],mg(c),!1),["}"],!1)):s.push("".concat(um(u),": ").concat(Jv(u,c),";")))}return s};function pn(i,s,u,c,f){if(f===void 0&&(f=[]),typeof i=="string")return i&&f.push(i),f;if(pg(i))return f;if(Ed(i))return f.push(".".concat(i.styledComponentId)),f;if($n(i)){if(!$n(h=i)||h.prototype&&h.prototype.isReactComponent||!s)return f.push(i),f;var p=i(s);return pn(p,s,u,c,f)}var h;if(i instanceof hg)return u?(i.inject(u,c),f.push(i.getName(c))):f.push(i),f;if(Wl(i)){for(var v=mg(i),x=0;x<v.length;x++)f.push(v[x]);return f}if(!Array.isArray(i))return f.push(i.toString()),f;for(x=0;x<i.length;x++)pn(i[x],s,u,c,f);return f}function gg(i){for(var s=0;s<i.length;s+=1){var u=i[s];if($n(u)&&!Ed(u))return!1}return!0}var Iv=lg(Po),Pv=(function(){function i(s,u,c){this.rules=s,this.staticRulesId="",this.isStatic=(c===void 0||c.isStatic)&&gg(s),this.componentId=u,this.baseHash=Hn(Iv,u),this.baseStyle=c,Xo.registerId(u)}return i.prototype.generateAndInjectStyles=function(s,u,c){var f=this.baseStyle?this.baseStyle.generateAndInjectStyles(s,u,c).className:"";if(this.isStatic&&!c.hash)if(this.staticRulesId&&u.hasNameForId(this.componentId,this.staticRulesId))f=Bn(f,this.staticRulesId);else{var p=Qo(pn(this.rules,s,u,c)),h=ed(Hn(this.baseHash,p)>>>0);if(!u.hasNameForId(this.componentId,h)){var v=c(p,".".concat(h),void 0,this.componentId);u.insertRules(this.componentId,h,v)}f=Bn(f,h),this.staticRulesId=h}else{for(var x=Hn(this.baseHash,c.hash),g="",b=0;b<this.rules.length;b++){var y=this.rules[b];if(typeof y=="string")g+=y;else if(y){var k=Qo(pn(y,s,u,c));x=Hn(Hn(x,String(b)),k),g+=k}}if(g){var D=ed(x>>>0);if(!u.hasNameForId(this.componentId,D)){var _=c(g,".".concat(D),void 0,this.componentId);u.insertRules(this.componentId,D,_)}f=Bn(f,D)}}return{className:f,css:typeof window>"u"?u.getTag().getGroup(_i(this.componentId)):""}},i})(),Li=Kt?{Provider:function(i){return i.children},Consumer:function(i){return(0,i.children)(void 0)}}:Ve.createContext(void 0);Li.Consumer;function e2(){var i=Kt?void 0:Ve.useContext(Li);if(!i)throw mn(18);return i}function t2(i){if(Kt)return i.children;var s=Ve.useContext(Li),u=Ve.useMemo(function(){return(function(c,f){if(!c)throw mn(14);if($n(c)){var p=c(f);return p}if(Array.isArray(c)||typeof c!="object")throw mn(8);return f?lt(lt({},f),c):c})(i.theme,s)},[i.theme,s]);return i.children?Ve.createElement(Li.Provider,{value:u},i.children):null}var Du={};function a2(i,s,u){var c=Ed(i),f=i,p=!_u(i),h=s.attrs,v=h===void 0?Ad:h,x=s.componentId,g=x===void 0?(function(V,te){var ee=typeof V!="string"?"sc":am(V);Du[ee]=(Du[ee]||0)+1;var $="".concat(ee,"-").concat(zd(Po+ee+Du[ee]));return te?"".concat(te,"-").concat($):$})(s.displayName,s.parentComponentId):x,b=s.displayName,y=b===void 0?(function(V){return _u(V)?"styled.".concat(V):"Styled(".concat(Ev(V),")")})(i):b,k=s.displayName&&s.componentId?"".concat(am(s.displayName),"-").concat(s.componentId):s.componentId||g,D=c&&f.attrs?f.attrs.concat(v).filter(Boolean):v,_=s.shouldForwardProp;if(c&&f.shouldForwardProp){var q=f.shouldForwardProp;if(s.shouldForwardProp){var Y=s.shouldForwardProp;_=function(V,te){return q(V,te)&&Y(V,te)}}else _=q}var U=new Pv(u,k,c?f.componentStyle:void 0);function Q(V,te){return(function(ee,$,J){var he=ee.attrs,Oe=ee.componentStyle,G=ee.defaultProps,K=ee.foldedComponentIds,ze=ee.styledComponentId,Me=ee.target,be=Kt?void 0:Ve.useContext(Li),M=ld(),X=ee.shouldForwardProp||M.shouldForwardProp,ie=ng($,be,G)||(Kt?void 0:Bi),fe=(function(We,Ne,la){for(var ra,wt=lt(lt({},Ne),{className:void 0,theme:la}),Gn=0;Gn<We.length;Gn+=1){var Ot=$n(ra=We[Gn])?ra(wt):ra;for(var oa in Ot)oa==="className"?wt.className=Bn(wt.className,Ot[oa]):oa==="style"?wt.style=lt(lt({},wt.style),Ot[oa]):wt[oa]=Ot[oa]}return"className"in Ne&&typeof Ne.className=="string"&&(wt.className=Bn(wt.className,Ne.className)),wt})(he,$,ie),je=fe.as||Me,w={};for(var H in fe)fe[H]===void 0||H[0]==="$"||H==="as"||H==="theme"&&fe.theme===ie||(H==="forwardedAs"?w.as=fe.forwardedAs:X&&!X(H,je)||(w[H]=fe[H]));var W=(function(We,Ne){var la=ld(),ra=We.generateAndInjectStyles(Ne,la.styleSheet,la.stylis);return ra})(Oe,fe),F=W.className,re=W.css,ce=Bn(K,ze);F&&(ce+=" "+F),fe.className&&(ce+=" "+fe.className),w[_u(je)&&!ig.has(je)?"class":"className"]=ce,J&&(w.ref=J);var ve=A.createElement(je,w);return Kt&&re?Ve.createElement(Ve.Fragment,null,Ve.createElement("style",{precedence:"styled-components",href:"sc-".concat(ze,"-").concat(F),children:re}),ve):ve})(Z,V,te)}Q.displayName=y;var Z=Ve.forwardRef(Q);return Z.attrs=D,Z.componentStyle=U,Z.displayName=y,Z.shouldForwardProp=_,Z.foldedComponentIds=c?Bn(f.foldedComponentIds,f.styledComponentId):"",Z.styledComponentId=k,Z.target=c?f.target:i,Object.defineProperty(Z,"defaultProps",{get:function(){return this._foldedDefaultProps},set:function(V){this._foldedDefaultProps=c?(function(te){for(var ee=[],$=1;$<arguments.length;$++)ee[$-1]=arguments[$];for(var J=0,he=ee;J<he.length;J++)td(te,he[J],!0);return te})({},f.defaultProps,V):V}}),Td(Z,function(){return".".concat(Z.styledComponentId)}),p&&cg(Z,i,{attrs:!0,componentStyle:!0,displayName:!0,foldedComponentIds:!0,shouldForwardProp:!0,styledComponentId:!0,target:!0}),Z}function dm(i,s){for(var u=[i[0]],c=0,f=s.length;c<f;c+=1)u.push(s[c],i[c+1]);return u}var fm=function(i){return Object.assign(i,{isCss:!0})};function Nd(i){for(var s=[],u=1;u<arguments.length;u++)s[u-1]=arguments[u];if($n(i)||Wl(i))return fm(pn(dm(Ad,Oi([i],s,!0))));var c=i;return s.length===0&&c.length===1&&typeof c[0]=="string"?pn(c):fm(pn(dm(c,s)))}function rd(i,s,u){if(u===void 0&&(u=Bi),!s)throw mn(1,s);var c=function(f){for(var p=[],h=1;h<arguments.length;h++)p[h-1]=arguments[h];return i(s,u,Nd.apply(void 0,Oi([f],p,!1)))};return c.attrs=function(f){return rd(i,s,lt(lt({},u),{attrs:Array.prototype.concat(u.attrs,f).filter(Boolean)}))},c.withConfig=function(f){return rd(i,s,lt(lt({},u),f))},c}var xg=function(i){return rd(a2,i)},C=xg;ig.forEach(function(i){C[i]=xg(i)});var n2=(function(){function i(s,u){this.rules=s,this.componentId=u,this.isStatic=gg(s),Xo.registerId(this.componentId+1)}return i.prototype.createStyles=function(s,u,c,f){var p=f(Qo(pn(this.rules,u,c,f)),""),h=this.componentId+s;c.insertRules(h,h,p)},i.prototype.removeStyles=function(s,u){u.clearRules(this.componentId+s)},i.prototype.renderStyles=function(s,u,c,f){s>2&&Xo.registerId(this.componentId+s);var p=this.componentId+s;this.isStatic?c.hasNameForId(p,p)||this.createStyles(s,u,c,f):(this.removeStyles(s,c),this.createStyles(s,u,c,f))},i})();function i2(i){for(var s=[],u=1;u<arguments.length;u++)s[u-1]=arguments[u];var c=Nd.apply(void 0,Oi([i],s,!1)),f="sc-global-".concat(zd(JSON.stringify(c))),p=new n2(c,f),h=new WeakMap,v=function(g){var b=ld(),y=Kt?void 0:Ve.useContext(Li),k=h.get(b.styleSheet);if(k===void 0&&(k=b.styleSheet.allocateGSInstance(f),h.set(b.styleSheet,k)),(typeof window>"u"||!b.styleSheet.server)&&x(k,g,b.styleSheet,y,b.stylis),Kt||Ve.useLayoutEffect(function(){return b.styleSheet.server||x(k,g,b.styleSheet,y,b.stylis),function(){var q;p.removeStyles(k,b.styleSheet),q=b.styleSheet.options.target,typeof document<"u"&&(q??document).querySelectorAll('style[data-styled-global="'.concat(f,'"]')).forEach(function(Y){return Y.remove()})}},[k,g,b.styleSheet,y,b.stylis]),Kt){var D=f+k,_=typeof window>"u"?b.styleSheet.getTag().getGroup(_i(D)):"";if(_)return Ve.createElement("style",{key:"".concat(f,"-").concat(k),"data-styled-global":f,children:_})}return null};function x(g,b,y,k,D){if(p.isStatic)p.renderStyles(g,wv,y,D);else{var _=lt(lt({},b),{theme:ng(b,k,v.defaultProps)});p.renderStyles(g,_,y,D)}}return Ve.memo(v)}function St(i){for(var s=[],u=1;u<arguments.length;u++)s[u-1]=arguments[u];var c=Qo(Nd.apply(void 0,Oi([i],s,!1))),f=zd(c);return new hg(f,c)}const l2=i2`
 
   :root {
    --color-navy: #0B1A33;
    --color-gold: #C9A84C;
    --color-white: #FFFFFF;
  }

  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }

  html {
    scroll-behavior: smooth;
  }

  body {
    font-family: 'DM Sans', sans-serif;
    color: ${({theme:i})=>i.colors.text};
    background-color: ${({theme:i})=>i.colors.background};
    line-height: 1.6;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  h1, h2, h3, h4, h5, h6 {
    font-family: 'Playfair Display', serif;
    font-weight: 700;
    line-height: 1.2;
    color: ${({theme:i})=>i.colors.navy};
  }

  a {
    text-decoration: none;
    color: inherit;
    transition: color 0.3s ease;
  }
`,r2={colors:{navy:"#0B1A33",navyLight:"#162845",gold:"#C9A84C",goldHover:"#B08D35",white:"#FFFFFF",text:"#333333",textLight:"#E0E0E0",background:"#F9FAFB",border:"#E5E7EB"},fonts:{display:"'Playfair Display', serif",body:"'DM Sans', sans-serif"},breakpoints:{mobile:"576px",tablet:"992px",desktop:"1200px"},spacing:{xs:"4px",sm:"8px",md:"16px",lg:"24px",xl:"32px",xxl:"64px"}};const yg=(...i)=>i.filter((s,u,c)=>!!s&&s.trim()!==""&&c.indexOf(s)===u).join(" ").trim();const o2=i=>i.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();const s2=i=>i.replace(/^([A-Z])|[\s-_]+(\w)/g,(s,u,c)=>c?c.toUpperCase():u.toLowerCase());const hm=i=>{const s=s2(i);return s.charAt(0).toUpperCase()+s.slice(1)};var c2={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};const u2=i=>{for(const s in i)if(s.startsWith("aria-")||s==="role"||s==="title")return!0;return!1};const d2=A.forwardRef(({color:i="currentColor",size:s=24,strokeWidth:u=2,absoluteStrokeWidth:c,className:f="",children:p,iconNode:h,...v},x)=>A.createElement("svg",{ref:x,...c2,width:s,height:s,stroke:i,strokeWidth:c?Number(u)*24/Number(s):u,className:yg("lucide",f),...!p&&!u2(v)&&{"aria-hidden":"true"},...v},[...h.map(([g,b])=>A.createElement(g,b)),...Array.isArray(p)?p:[p]]));const I=(i,s)=>{const u=A.forwardRef(({className:c,...f},p)=>A.createElement(d2,{ref:p,iconNode:s,className:yg(`lucide-${o2(hm(i))}`,`lucide-${i}`,c),...f}));return u.displayName=hm(i),u};const f2=[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]],Xl=I("activity",f2);const h2=[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]],bg=I("arrow-left",h2);const p2=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],m2=I("arrow-right",p2);const g2=[["path",{d:"m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526",key:"1yiouv"}],["circle",{cx:"12",cy:"8",r:"6",key:"1vp47v"}]],vg=I("award",g2);const x2=[["path",{d:"M10 16c.5.3 1.2.5 2 .5s1.5-.2 2-.5",key:"1u7htd"}],["path",{d:"M15 12h.01",key:"1k8ypt"}],["path",{d:"M19.38 6.813A9 9 0 0 1 20.8 10.2a2 2 0 0 1 0 3.6 9 9 0 0 1-17.6 0 2 2 0 0 1 0-3.6A9 9 0 0 1 12 3c2 0 3.5 1.1 3.5 2.5s-.9 2.5-2 2.5c-.8 0-1.5-.4-1.5-1",key:"11xh7x"}],["path",{d:"M9 12h.01",key:"157uk2"}]],y2=I("baby",x2);const b2=[["path",{d:"M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",key:"3c2336"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],v2=I("badge-check",b2);const j2=[["path",{d:"M10.268 21a2 2 0 0 0 3.464 0",key:"vwvbt9"}],["path",{d:"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",key:"11g9vi"}]],es=I("bell",j2);const S2=[["path",{d:"M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16",key:"jecpp"}],["rect",{width:"20",height:"14",x:"2",y:"6",rx:"2",key:"i6l2r4"}]],pm=I("briefcase",S2);const w2=[["path",{d:"M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2",key:"5owen"}],["circle",{cx:"7",cy:"17",r:"2",key:"u2ysq9"}],["path",{d:"M9 17h6",key:"r8uit2"}],["circle",{cx:"17",cy:"17",r:"2",key:"axvx0g"}]],Jl=I("car",w2);const C2=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],A2=I("chevron-down",C2);const z2=[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]],Ln=I("chevron-left",z2);const E2=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],hn=I("chevron-right",E2);const T2=[["path",{d:"M21.801 10A10 10 0 1 1 17 3.335",key:"yps3ct"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]],N2=I("circle-check-big",T2);const k2=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],jg=I("circle-check",k2);const R2=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M8 12h8",key:"1wcyev"}],["path",{d:"M12 8v8",key:"napkw2"}]],_2=I("circle-plus",R2);const M2=[["path",{d:"M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z",key:"p7xjir"}]],Sg=I("cloud",M2);const D2=[["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M17 20v2",key:"1rnc9c"}],["path",{d:"M17 2v2",key:"11trls"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M2 17h2",key:"7oei6x"}],["path",{d:"M2 7h2",key:"asdhe0"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"M20 17h2",key:"1fpfkl"}],["path",{d:"M20 7h2",key:"1o8tra"}],["path",{d:"M7 20v2",key:"4gnj0m"}],["path",{d:"M7 2v2",key:"1i4yhu"}],["rect",{x:"4",y:"4",width:"16",height:"16",rx:"2",key:"1vbyd7"}],["rect",{x:"8",y:"8",width:"8",height:"8",rx:"1",key:"z9xiuo"}]],O2=I("cpu",D2);const H2=[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]],U2=I("credit-card",H2);const B2=[["path",{d:"M11.25 16.25h1.5L12 17z",key:"w7jh35"}],["path",{d:"M16 14v.5",key:"1lajdz"}],["path",{d:"M4.42 11.247A13.152 13.152 0 0 0 4 14.556C4 18.728 7.582 21 12 21s8-2.272 8-6.444a11.702 11.702 0 0 0-.493-3.309",key:"u7s9ue"}],["path",{d:"M8 14v.5",key:"1nzgdb"}],["path",{d:"M8.5 8.5c-.384 1.05-1.083 2.028-2.344 2.5-1.931.722-3.576-.297-3.656-1-.113-.994 1.177-6.53 4-7 1.923-.321 3.651.845 3.651 2.235A7.497 7.497 0 0 1 14 5.277c0-1.39 1.844-2.598 3.767-2.277 2.823.47 4.113 6.006 4 7-.08.703-1.725 1.722-3.656 1-1.261-.472-1.855-1.45-2.239-2.5",key:"v8hric"}]],L2=I("dog",B2);const q2=[["path",{d:"M11 20H2",key:"nlcfvz"}],["path",{d:"M11 4.562v16.157a1 1 0 0 0 1.242.97L19 20V5.562a2 2 0 0 0-1.515-1.94l-4-1A2 2 0 0 0 11 4.561z",key:"au4z13"}],["path",{d:"M11 4H8a2 2 0 0 0-2 2v14",key:"74r1mk"}],["path",{d:"M14 12h.01",key:"1jfl7z"}],["path",{d:"M22 20h-3",key:"vhrsz"}]],Y2=I("door-open",q2);const $2=[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]],wg=I("download",$2);const G2=[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],od=I("eye",G2);const Q2=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]],mm=I("globe",Q2);const V2=[["path",{d:"M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",key:"mvr1a0"}]],X2=I("heart",V2);const K2=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]],Z2=I("info",K2);const W2=[["rect",{width:"20",height:"20",x:"2",y:"2",rx:"5",ry:"5",key:"2e1cvw"}],["path",{d:"M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z",key:"9exkf1"}],["line",{x1:"17.5",x2:"17.51",y1:"6.5",y2:"6.5",key:"r4j83e"}]],J2=I("instagram",W2);const F2=[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]],I2=I("layout-dashboard",F2);const P2=[["path",{d:"M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z",key:"c2jq9f"}],["rect",{width:"4",height:"12",x:"2",y:"9",key:"mk3on5"}],["circle",{cx:"4",cy:"4",r:"2",key:"bt5ra8"}]],e5=I("linkedin",P2);const t5=[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 10 0v4",key:"fwvmzm"}]],qi=I("lock",t5);const a5=[["path",{d:"m10 17 5-5-5-5",key:"1bsop3"}],["path",{d:"M15 12H3",key:"6jk70r"}],["path",{d:"M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4",key:"u53s6r"}]],n5=I("log-in",a5);const i5=[["path",{d:"m16 17 5-5-5-5",key:"1bji2h"}],["path",{d:"M21 12H9",key:"dn1m92"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}]],Cg=I("log-out",i5);const l5=[["path",{d:"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7",key:"132q7q"}],["rect",{x:"2",y:"4",width:"20",height:"16",rx:"2",key:"izxlao"}]],kd=I("mail",l5);const r5=[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]],Ag=I("map-pin",r5);const o5=[["path",{d:"M4 5h16",key:"1tepv9"}],["path",{d:"M4 12h16",key:"1lakjw"}],["path",{d:"M4 19h16",key:"1djgab"}]],s5=I("menu",o5);const c5=[["path",{d:"M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",key:"1sd12s"}]],u5=I("message-circle",c5);const d5=[["path",{d:"M5 12h14",key:"1ays0h"}]],f5=I("minus",d5);const h5=[["path",{d:"M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z",key:"1a0edw"}],["path",{d:"M12 22V12",key:"d0xqtd"}],["polyline",{points:"3.29 7 12 12 20.71 7",key:"ousv84"}],["path",{d:"m7.5 4.27 9 5.15",key:"1c824w"}]],sd=I("package",h5);const p5=[["path",{d:"M13 2a9 9 0 0 1 9 9",key:"1itnx2"}],["path",{d:"M13 6a5 5 0 0 1 5 5",key:"11nki7"}],["path",{d:"M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",key:"9njp5v"}]],zg=I("phone-call",p5);const m5=[["path",{d:"M14 6h8",key:"yd68k4"}],["path",{d:"m18 2 4 4-4 4",key:"pucp1d"}],["path",{d:"M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",key:"9njp5v"}]],Eg=I("phone-forwarded",m5);const g5=[["path",{d:"M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",key:"9njp5v"}]],cd=I("phone",g5);const x5=[["path",{d:"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",key:"10ikf1"}]],y5=I("play",x5);const b5=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],v5=I("plus",b5);const j5=[["rect",{width:"5",height:"5",x:"3",y:"3",rx:"1",key:"1tu5fj"}],["rect",{width:"5",height:"5",x:"16",y:"3",rx:"1",key:"1v8r4q"}],["rect",{width:"5",height:"5",x:"3",y:"16",rx:"1",key:"1x03jg"}],["path",{d:"M21 16h-3a2 2 0 0 0-2 2v3",key:"177gqh"}],["path",{d:"M21 21v.01",key:"ents32"}],["path",{d:"M12 7v3a2 2 0 0 1-2 2H7",key:"8crl2c"}],["path",{d:"M3 12h.01",key:"nlz23k"}],["path",{d:"M12 3h.01",key:"n36tog"}],["path",{d:"M12 16v.01",key:"133mhm"}],["path",{d:"M16 12h1",key:"1slzba"}],["path",{d:"M21 12v.01",key:"1lwtk9"}],["path",{d:"M12 21v-1",key:"1880an"}]],Mi=I("qr-code",j5);const S5=[["path",{d:"M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z",key:"rib7q0"}],["path",{d:"M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z",key:"1ymkrd"}]],gm=I("quote",S5);const w5=[["path",{d:"M3 7V5a2 2 0 0 1 2-2h2",key:"aa7l1z"}],["path",{d:"M17 3h2a2 2 0 0 1 2 2v2",key:"4qcy5o"}],["path",{d:"M21 17v2a2 2 0 0 1-2 2h-2",key:"6vwrx8"}],["path",{d:"M7 21H5a2 2 0 0 1-2-2v-2",key:"ioqczr"}]],ud=I("scan",w5);const C5=[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]],A5=I("search",C5);const z5=[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]],E5=I("send",z5);const T5=[["path",{d:"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",key:"1i5ecw"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],Tg=I("settings",T5);const N5=[["circle",{cx:"18",cy:"5",r:"3",key:"gq8acd"}],["circle",{cx:"6",cy:"12",r:"3",key:"w7nqdw"}],["circle",{cx:"18",cy:"19",r:"3",key:"1xt0gg"}],["line",{x1:"8.59",x2:"15.42",y1:"13.51",y2:"17.49",key:"47mynk"}],["line",{x1:"15.41",x2:"8.59",y1:"6.51",y2:"10.49",key:"1n3mei"}]],k5=I("share-2",N5);const R5=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M12 8v4",key:"1got3b"}],["path",{d:"M12 16h.01",key:"1drbdi"}]],Ng=I("shield-alert",R5);const _5=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],Zt=I("shield-check",_5);const M5=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]],Xt=I("shield",M5);const D5=[["path",{d:"M16 10a4 4 0 0 1-8 0",key:"1ltviw"}],["path",{d:"M3.103 6.034h17.794",key:"awc11p"}],["path",{d:"M3.4 5.467a2 2 0 0 0-.4 1.2V20a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6.667a2 2 0 0 0-.4-1.2l-2-2.667A2 2 0 0 0 17 2H7a2 2 0 0 0-1.6.8z",key:"o988cm"}]],Yo=I("shopping-bag",D5);const O5=[["circle",{cx:"8",cy:"21",r:"1",key:"jimo8o"}],["circle",{cx:"19",cy:"21",r:"1",key:"13723u"}],["path",{d:"M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12",key:"9zh506"}]],er=I("shopping-cart",O5);const H5=[["rect",{width:"14",height:"20",x:"5",y:"2",rx:"2",ry:"2",key:"1yt0o3"}],["path",{d:"M12 18h.01",key:"mhygvu"}]],ts=I("smartphone",H5);const U5=[["path",{d:"M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",key:"r04s7s"}]],Ll=I("star",U5);const B5=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]],L5=I("target",B5);const q5=[["path",{d:"M10 11v6",key:"nco0om"}],["path",{d:"M14 11v6",key:"outv1u"}],["path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",key:"miytrc"}],["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",key:"e791ji"}]],Y5=I("trash-2",q5);const $5=[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]],dd=I("triangle-alert",$5);const G5=[["path",{d:"M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2",key:"wrbu53"}],["path",{d:"M15 18H9",key:"1lyqi6"}],["path",{d:"M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14",key:"lysw3i"}],["circle",{cx:"17",cy:"18",r:"2",key:"332jqn"}],["circle",{cx:"7",cy:"18",r:"2",key:"19iecd"}]],Q5=I("truck",G5);const V5=[["path",{d:"M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z",key:"pff0z6"}]],X5=I("twitter",V5);const K5=[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["line",{x1:"19",x2:"19",y1:"8",y2:"14",key:"1bvyxn"}],["line",{x1:"22",x2:"16",y1:"11",y2:"11",key:"1shjgl"}]],Z5=I("user-plus",K5);const W5=[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]],qn=I("user",W5);const J5=[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]],Rd=I("users",J5);const F5=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],kg=I("x",F5);const I5=[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]],_d=I("zap",I5),Rg=A.createContext(),tr=()=>A.useContext(Rg),P5=({children:i})=>{const[s,u]=A.useState(()=>{try{const g=localStorage.getItem("tarkshya_cart");if(g&&g!=="undefined")return JSON.parse(g)}catch(g){console.error("Failed to parse cart from localStorage",g),localStorage.removeItem("tarkshya_cart")}return[]});A.useEffect(()=>{localStorage.setItem("tarkshya_cart",JSON.stringify(s))},[s]);const c=(g,b=1)=>{u(y=>{if(y.find(_=>_.productId===g.id))return y.map(_=>_.productId===g.id?{..._,quantity:_.quantity+b}:_);let D=null;if(g.photos){if(Array.isArray(g.photos))D=g.photos[0];else if(typeof g.photos=="string")try{D=JSON.parse(g.photos)[0]}catch{D=g.photos}}return[...y,{productId:g.id,name:g.name,price:g.mrp||0,image:D,quantity:b}]})},f=g=>{u(b=>b.filter(y=>y.productId!==g))},p=(g,b)=>{b<1||u(y=>y.map(k=>k.productId===g?{...k,quantity:b}:k))},h=()=>u([]),v=s.reduce((g,b)=>g+b.price*b.quantity,0),x=s.reduce((g,b)=>g+b.quantity,0);return l.jsx(Rg.Provider,{value:{cart:s,addToCart:c,removeFromCart:f,updateQuantity:p,clearCart:h,cartTotal:v,cartCount:x},children:i})},ej=A.createContext(),as=()=>{const i=A.useContext(ej);if(!i)throw new Error("useLanguage must be used within a LanguageProvider");return i},tj=C.button`
  padding: 12px 24px;
  font-family: ${({theme:i})=>i.fonts.body};
  font-weight: 700;
  font-size: 1rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  border: 2px solid transparent;

  ${({$variant:i,theme:s})=>i==="outline"?`
    background: transparent;
    color: ${s.colors.white};
    border-color: ${s.colors.white};
    &:hover {
      background: ${s.colors.white};
      color: ${s.colors.navy};
    }
  `:i==="secondary"?`
    background: ${s.colors.navy};
    color: ${s.colors.white};
    &:hover {
      background: ${s.colors.navyLight};
      transform: translateY(-2px);
    }
  `:`
    background: ${s.colors.gold};
    color: ${s.colors.navy};
    &:hover {
      background: ${s.colors.goldHover};
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(201, 168, 76, 0.3);
    }
  `}
`,qe=({children:i,variant:s="primary",...u})=>l.jsx(tj,{$variant:s,...u,children:i}),_g="/assets/new_logo-CnGHiGGP.png",ns={en:{nav:{home:"Home",qrSafety:"QR Safety",cloudMonitoring:"Cloud Monitoring",gpsTracking:"GPS Tracking",initiative:"Initiative",b2b:"B2B Solutions",login:"LOGIN / DASHBOARD"},hero:{taglineDim:"The Next Evolution of",taglineHighlight:"SMART SAFETY IDS",subtext:"V-KAWACH provides a high-security ecosystem that protects your vehicle, family, and property through advanced QR-based communication.",getStarted:"GET STARTED",watchDemo:"WATCH DEMO",learnMore:"LEARN MORE"},sections:{categories:{title:"Top",highlight:"Categories",subtext:"Explore our wide range of safety solutions for all your needs"},safetyIds:{title:"V-Kawach",highlight:"Safety IDs",subtext:"Next-Gen Emergency QR Ecosystem for People & Property"},securityProducts:{title:"Advanced",highlight:"Security",subtext:"Intelligent monitoring and protection for your high-value assets"},services:{title:"Key",highlight:"Features",subtext:"V-KAWACH keeps journeys safe with advanced monitoring & alerts"},features:{title:"Security",highlight:"Features",subtext:"Advanced technology to keep you and your loved ones secure"},initiative:{title:"Social",highlight:"Initiative",subtext:"Mission Rakshak: Empowering safety for the common citizen.",p1:"At V-KAWACH (A product by Tarkshya Solution), we believe safety is a fundamental right, not a luxury. Mission Rakshak is our dedicated initiative to bring smart security to everyone.",p2:"Through subsidized programs and community awareness, we aim to protect 100,000+ lives by 2026. Join us in making India safer."}},about:{title:"About",highlight:"V-KAWACH",content:`<b>V-KAWACH</b>, a proud product of <b>Tarkshya Solution</b>, is a next-generation digital safety ecosystem driven by a core mission: to make Indian roads, communities, and daily life safer. By leveraging <b>privacy-first call masking</b> and advanced technology, we make communication during emergencies effortless, secure, and instantaneous.

Whether it is an improperly parked vehicle, a lost pet, or a critical emergency involving a loved one—V-KAWACH ensures that immediate help reaches you without ever exposing your personal information, such as your mobile number. Our intelligent system seamlessly connects you to real-world solutions while keeping your identity completely protected.

Our vision goes beyond simply offering a product; we are dedicated to building a <b>secure future</b> where communication is seamless and privacy is never compromised. Powered by continuous innovation and a <b>user-centric approach</b>, V-KAWACH is committed to ensuring round-the-clock (<b>24/7</b>) safety and peace of mind for you and your family.

• <b>Next-Gen Safety:</b> A comprehensive digital ecosystem for modern security needs.
• <b>Privacy-First Approach:</b> 100% secure call masking that hides your mobile number.
• <b>Instant Emergency Connectivity:</b> Fast, reliable, and anonymous communication when you need it the most.
• <b>24/7 Protection:</b> Uncompromised safety for you, your loved ones, and your assets.`,stats:{activeUsers:"Vision: Safe Users",scansProtected:"Scans Protected",monitoring:"Cloud Monitoring"}},footer:{tagline:"Securing your World",description:"V-KAWACH (A product by Tarkshya Solution) provides cutting-edge digital and physical security ecosystems, protecting what matters most with Indian innovation.",quickLinks:"Quick Links",aboutUs:"About Us",privacyPolicy:"Privacy Policy",termsConditions:"Terms & Conditions",contactUs:"Contact Us",rights:"All rights reserved."},smartQR:{title:"Smart QR Identity",subtitle:"Protect what matters with our advanced QR technology. Vehicles, pets, and loved ones — secured with instant connectivity and privacy.",getYourID:"Get Your Smart ID",howItWorks:"How It Works",steps:{scan:{title:"Scan",desc:"Anyone who finds your lost item or vehicle scans the QR code using any smartphone camera."},connect:{title:"Connect",desc:"They are instantly redirected to a secure page to contact the owner."},call:{title:"Call Owner",desc:"They can call you immediately. Your number stays private via our call masking technology."}},featuresTitle:"Key Features",features:["Call Masking (Privacy Protection)","Instant SMS & WhatsApp Alerts","Emergency Contact Integration","No App Required for Finder","Weatherproof & Durable Tags"],orderNow:"Order Now"},cloudMonitoring:{title:"Live Cloud Monitoring",subtitle:"Secure CCTV Backup & Anti-Theft Protection",badge:"COMING SOON",infoTitle:"Secure Your Premises with Cloud Intelligence",infoDesc:"Traditional CCTV systems are vulnerable to theft and damage. Our cloud monitoring solution ensures your footage is safe.",featuresTitle:"Features:",features:["Real-time Cloud Backup","Motion Detection Alerts","Anti-Theft Device Protection","Remote Access via Mobile"]},gpsTracking:{title:"Advanced GPS Tracking",subtitle:"Real-time Location & Fleet Management",badge:"COMING SOON",infoTitle:"Precision Tracking for Every Asset",infoDesc:"Whether it's a fleet of trucks or a personal vehicle, stay connected with real-time location data.",featuresTitle:"Features:",features:["Live Location Tracking","Geofencing Alerts","Speed Monitoring","Route Playback","Fuel Usage Analytics"]},social:{title:"Mission Rakshak",subtitle:"Our commitment to safer roads and connected communities.",storyTitle:"The Story",storyPart1:"Mission Rakshak was born from a simple realization: in an emergency, every second counts.",storyPart2:"Through Mission Rakshak, we distribute subsidized Smart QR stickers to public transport, elderly citizens, and school children.",stats:{vision:"Vision",visionDesc:"Impact 10,000+ Lives",partners:"Looking for",partnersDesc:"Partners",initiative:"Initiative",initiativeDesc:"Our Social Initiative"},formTitle:"Become a franchise partner",form:{name:"Full Name",namePlaceholder:"Enter your name",email:"Email Address",emailPlaceholder:"email@example.com",phone:"Phone Number",phonePlaceholder:"+91 00000 00000",message:"Message",messagePlaceholder:"How would you like to contribute?",submit:"Join the Mission",submitting:"Sending...",success:"Redirecting to WhatsApp..."}},auth:{login:{title:"Secure Your Ecosystem",subtitle:"Join India's most advanced vehicle and personal security network.",features:[{title:"Bank-Grade Security",desc:"256-bit encryption for all your personal data"},{title:"Fleet Safety",desc:"Real-time vehicle status and driver safety"},{title:"Instant Alerts",desc:"Emergency notifications via SMS and Call"},{title:"Cloud Backup",desc:"Never lose your critical security records"}],cardTitle:"Welcome Back",cardDesc:"Enter your credentials to access your dashboard.",email:"Email Address",emailPlaceholder:"name@company.com",password:"Password",passwordPlaceholder:"••••••••",submit:"ACCESS PORTAL",submitting:"Authenticating...",noAccount:"New to Ecosystem?",registerNow:"Register Now"},signup:{title:"Initialize Identity",subtitle:"Secure your assets and loved ones with our next-gen safety ecosystem.",cardTitle:"Create Account",cardDesc:"Join the ecosystem to manage your smart assets.",name:"Full Name",namePlaceholder:"Enter your full name",email:"Email Address",emailPlaceholder:"name@company.com",password:"Password",passwordPlaceholder:"Create a password",confirmPassword:"Confirm Password",confirmPasswordPlaceholder:"Confirm your password",submit:"REGISTER",submitting:"Creating Account...",hasAccount:"Already part of Network?",loginHere:"Login Here"}},products:{catalog:"Product Catalog",viewDetails:"VIEW DETAILS",material:"MATERIAL",warranty:"WARRANTY",off:"OFF",addedToCart:"Added to Cart!",items:{"kids-safety-bracelet":"Kid's Safety Bracelet","luggage-smart-tag":"Luggage Smart Tag","pet-id-tag":"Pet ID Tag","vehicle-safety-sticker":"Vehicle Safety Sticker"}},cart:{breadcrumb:"Home / Cart",title:"Shopping Cart",empty:{title:"Your cart is empty",desc:"It looks like you haven't added any safety IDs to your cart yet. Protect your assets today!",button:"BROWSE PRODUCTS"},items:{secureId:"SECURE IDENTITY"},summary:{title:"Order Summary",subtotal:"Subtotal",shipping:"Shipping",shippingFree:"FREE",platformFee:"Platform Fee",total:"Total",checkout:"PROCEED TO CHECKOUT",protection:"All payments are secured with bank-grade encryption. Your data is 100% private."}},checkout:{returnCart:"Return to Cart",title:"Shipping Logistics",form:{consignee:"Consignee Name",consigneePlaceholder:"Full name of receiver",contact:"Contact Email",contactPlaceholder:"email@example.com",phone:"Mobile Number",phonePlaceholder:"+91 00000 00000",address:"Shipping Address",addressPlaceholder:"House No, Building, Street, Area",city:"City / Town",cityPlaceholder:"Enter city",pincode:"Pincode / ZIP",pincodePlaceholder:"000000"},summary:{title:"Logistics Summary",subtotal:"Consolidated Total",logistics:"Shipping & Handling",complimentary:"COMPLIMENTARY",total:"Payable Amount",payment:{title:"Payment Protocol",desc:"Currently accepting Cash on Delivery (COD). Digital payment gateway integration is in progress."},submit:"INITIALIZE ORDER",submitting:"COMMITTING...",encryption:"AES-256 BIT ENCRYPTED"}},orderSuccess:{title:"Order Initialized",subtitle:"Your safety ecosystem is being prepared. We have sent a confirmation email to your registered address.",nextStepsTitle:"WHAT HAPPENS NEXT?",steps:["Quality check of your Smart QR Tags","Dispatched via our logistics partner","Delivery at your doorstep within 3-5 days"],returnHome:"BACK TO HOME",dashboard:"GO TO DASHBOARD",secure:"BANK-GRADE SECURITY",downloadInvoice:"INVOICE PDF"},dashboard:{sidebar:{orders:"My Orders",tags:"My QR Tags",profile:"Profile Settings",logout:"Logout"},welcome:{greet:"Welcome Back,",ordersDesc:"orders in your account",qrTitle:"My QR Identity",qrDesc:"Manage your smart safety assets",profileTitle:"Profile Settings",profileDesc:"Manage your identity and security"},stats:{totalOrders:"Total Orders",secureTags:"Secure Tags",pending:"Pending Orders"},topbar:{path:"Dashboard /",orders:"Orders",tags:"QR Tags",profile:"Profile"},orders:{title:"Order History",empty:"No orders found in your account.",table:{id:"Order ID",date:"Date",items:"Items",amount:"Amount",payment:"Payment",status:"Status"}},tags:{title:"My Smart Tags",empty:"You haven't activated any tags yet.",card:{code:"Tag Code:",preview:"Preview",download:"Download"}},profile:{title:"Edit Profile",name:"Full Name",phone:"Phone Number",passwordTitle:"Security",passwordDesc:"Change your account password",currentPassword:"Current Password",newPassword:"New Password",currentPlaceholder:"••••••••",newPlaceholder:"••••••••",save:"SAVE CHANGES"}},common:{loading:"LOADING...",loadFailed:"Failed to load data",profileUpdated:"Profile updated successfully",error:"Something went wrong"},publicProfile:{loading:"FETCHING IDENTITY...",invalid:{title:"Security Cluster Not Found",desc:"This QR code is either invalid or has not been activated yet."},header:{badge:"Verified Asset",assetId:"Asset ID:"},banner:"Securely managed by V-KAWACH protocol",owner:"Valued Owner",locationVerified:"Location Verified",form:{phonePlaceholder:"Enter mobile to connect...",callButton:"CALL OWNER",connecting:"CONNECTING...",emergency:"EMERGENCY — CALL 112",shareLocation:"SHARE LIVE LOCATION"},howItWorks:{title:"How it works",steps:[{label:"Scan QR"},{label:"Verify"},{label:"Connect"}]},footer:{protocol:"V-KAWACH Protocol Active",terms:"Terms",privacy:"Privacy",about:"About"}},admin:{sidebar:{masterPanel:"Master Panel",bulkManage:"Bulk Manage",logout:"Logout"},stats:{activeQRs:"Active QRs",totalScans:"Total Scans"}},legal:{back:"Back to Home",subtitle:"Official documentation and policies",loading:"FETCHING DOCUMENTATION...",fallback:"Content is being updated. Please check back later.",error:"Unable to load content. Please try again."},services:{backToHome:"Back to Home",items:{"instant-call-masking":{title:"Instant Call Masking",content:"<p>V-KAWACH's Instant Call Masking technology protects your privacy by hiding your real phone number during every call. When someone scans your QR tag and initiates a call, our system connects both parties through a secure masked number — your actual number is never revealed.</p><h2>How It Works</h2><p>Our telephony layer intercepts the call request and routes it through a virtual number. The caller sees only a masked ID, while you receive the call on your registered device. Both parties are connected seamlessly in real time.</p><h2>Key Benefits</h2><ul><li>Your real phone number stays 100% private</li><li>Works with any smartphone — no app needed for the caller</li><li>Instant connection in emergencies</li><li>Full call logs available in your dashboard</li><li>Works across India with local number support</li></ul>"},"emergency-helplines":{title:"Emergency Helplines",content:"<p>V-KAWACH integrates direct access to India's critical emergency helplines right from your QR scan page. Whether it's police, ambulance, or fire services — help is always one tap away.</p><h2>Integrated Helplines</h2><ul><li>Police — 100</li><li>Ambulance — 108</li><li>Fire — 101</li><li>National Emergency — 112</li><li>Women Helpline — 1091</li></ul><p>These helplines are embedded directly into every public-facing QR scan page, ensuring that anyone who finds your item or vehicle can immediately reach emergency services if needed.</p>"},"location-sharing":{title:"Live Location Sharing",content:"<p>V-KAWACH enables real-time GPS location sharing directly from the QR scan page. With a single tap, the finder can share their current location with you via WhatsApp — so you know exactly where your lost item or vehicle is.</p><h2>How It Works</h2><p>When someone scans your QR code, they see a 'Share Live Location' button. Tapping it opens WhatsApp pre-filled with their GPS coordinates, which are sent directly to your registered number.</p><h2>Benefits</h2><ul><li>No app installation required for the finder</li><li>Instant GPS coordinates via WhatsApp</li><li>Works on all modern smartphones</li><li>Helps recover lost vehicles, pets, and belongings faster</li></ul>"},"data-privacy":{title:"Data Privacy",content:"<p>At V-KAWACH, your personal data is protected with bank-grade security. We follow strict data minimization principles — we collect only what's necessary and never sell your data to third parties.</p><h2>Our Privacy Commitments</h2><ul><li>256-bit end-to-end encryption for all personal data</li><li>Phone numbers are never exposed — masked during every interaction</li><li>QR codes carry no personal information — they only link to a secure server</li><li>You can delete your data anytime from your dashboard</li><li>Full compliance with Indian data protection standards</li></ul>"},"family-control":{title:"Family Control",content:"<p>V-KAWACH's Family Control feature lets you manage safety profiles for every member of your household — children, elderly parents, pets, and vehicles — all from a single dashboard.</p><h2>Features</h2><ul><li>Create separate QR profiles for each family member</li><li>Set emergency contacts per profile</li><li>Receive instant alerts when any family QR is scanned</li><li>Monitor all scan activity in real time</li><li>Customize messages for each profile (lost, found, emergency)</li></ul>"},"verified-id":{title:"Verified Identity",content:"<p>Every V-KAWACH QR tag is linked to a verified digital identity. Our verification system ensures that each QR code is authentic, tamper-proof, and traceable — providing trust for both owners and finders.</p><h2>Verification Process</h2><ul><li>Mobile number verification via OTP during registration</li><li>Unique cryptographic QR code generation per user</li><li>Anti-counterfeit protection built into every tag</li><li>Real-time verification badge on every scan page</li></ul>"},"app-support":{title:"App Support",content:"<p>V-KAWACH is designed to work without requiring any app installation for the person who finds your QR tag. Everything works directly in the browser — making it universally accessible.</p><h2>Compatibility</h2><ul><li>Works on any smartphone with a camera</li><li>No app download required for finders</li><li>Full dashboard available as a Progressive Web App (PWA)</li><li>Supports Android and iOS</li><li>Optimized for low-bandwidth conditions</li></ul>"},"audio-alerts":{title:"Audio Alerts",content:"<p>V-KAWACH supports audio alert integration for connected smart devices. When your QR is scanned, you can receive real-time audio notifications on your registered devices, ensuring you never miss a critical alert.</p><h2>Alert Types</h2><ul><li>QR scan notification with location</li><li>Emergency distress signals</li><li>Incoming call alerts from masked numbers</li><li>Battery-low alerts for GPS-enabled tags</li></ul>"},"qr-security":{title:"QR Security",content:"<p>V-KAWACH's QR codes are built with multi-layer security. Each code is uniquely generated, server-verified, and tamper-evident — ensuring that your digital identity cannot be cloned or misused.</p><h2>Security Features</h2><ul><li>One-time cryptographic key per QR code</li><li>Server-side verification on every scan</li><li>Anti-clone detection system</li><li>Waterproof and scratch-resistant physical tags</li><li>Automatic deactivation of compromised codes</li></ul>"},verified:{title:"Verified Protocol",content:"<p>The V-KAWACH Verified Protocol is our end-to-end trust framework that ensures every interaction — from QR scan to owner contact — is authenticated, logged, and secure.</p><h2>Protocol Layers</h2><ul><li>Layer 1: QR Code Authenticity Check</li><li>Layer 2: Owner Identity Verification</li><li>Layer 3: Call Masking & Privacy Shield</li><li>Layer 4: Interaction Logging & Audit Trail</li><li>Layer 5: Emergency Escalation Path</li></ul>"},"instant-alerts":{title:"Instant Alerts",content:"<p>V-KAWACH sends real-time alerts the moment your QR code is scanned anywhere. Whether via SMS, WhatsApp, or in-app notification — you're always informed instantly.</p><h2>Alert Channels</h2><ul><li>SMS to your registered number</li><li>WhatsApp message with scan location</li><li>In-app push notification</li><li>Email alert with timestamp and GPS coordinates</li></ul>"},"smart-tracking":{title:"Smart Tracking",content:"<p>V-KAWACH's Smart Tracking feature provides real-time visibility of your assets. Combined with GPS-enabled tags and QR scan data, you always know where your belongings are.</p><h2>Tracking Features</h2><ul><li>Real-time GPS location on scan</li><li>Historical scan log with timestamps</li><li>Geofence alerts when assets leave a defined area</li><li>Route playback for vehicles</li></ul>"},"emergency-help":{title:"Emergency Help",content:"<p>V-KAWACH's Emergency Help system is designed to connect people in distress with the right resources instantly. Every QR scan page includes direct emergency access and owner contact options.</p><h2>Emergency Features</h2><ul><li>One-tap dial to emergency services (112)</li><li>Instant owner notification on scan</li><li>Pre-filled emergency message templates</li><li>Location sharing with emergency contacts</li></ul>"}}},categoryDetails:{initializing:"INITIALIZING SECURITY LAYER...",notFound:"Security Cluster Not Found",discoverMore:"DISCOVER MORE",relatedProducts:"Related Security Hardware",productsDesc:"Explore our specialized hardware modules for this category",viewSpecs:"VIEW SPECS",precisionSecurity:"PRECISION SECURITY",advancedProtocols:"Advanced Security Protocols",standardProtocols:"Standard V-KAWACH security protocols are active for this category.",strategicProtection:"Strategic Protection",verifiedSecurity:"Verified Security",certifiedHardware:"CERTIFIED HARDWARE",stats:{scanRate:"Success Rate",alertSpeed:"Alert Speed",encryption:"Encryption"}},productDetails:{initializing:"FETCHING HARDWARE SPECS...",notFound:"Hardware Module Not Found",badge:"SECURITY HARDWARE",encryption:"ENCRYPTION",delivery:"DELIVERY",addToCart:"ADD TO ECOSYSTEM",keyFeatures:"Key Features",description:"Description"},b2bPage:{title:"Smart Brand QR",subtitle:"Digital Transformation for your FMCG Products",content:"Transform your FMCG products (like Edible Oil, Packaging) into digital assets. With our Smart Brand QR, provide your customers instant access to FSSAI details, product brochures, and customer care information.",cta:"Contact for B2B"}},hi:{nav:{home:"होम",qrSafety:"क्यूआर सुरक्षा",cloudMonitoring:"क्लाउड मॉनिटरिंग",gpsTracking:"जीपीएस ट्रैकिंग",initiative:"पहल",b2b:"व्यापारिक समाधान",login:"लॉगिन / डैशबोर्ड"},hero:{taglineDim:"स्मार्ट सुरक्षा का",taglineHighlight:"वी-कवच सुरक्षा आईडी",subtext:"वी-कवच (V-KAWACH) एक उच्च-सुरक्षा पारिस्थितिकी तंत्र प्रदान करता है जो उन्नत क्यूआर-आधारित संचार के माध्यम से आपके वाहन, परिवार और संपत्ति की रक्षा करता है।",getStarted:"शुरू करें",watchDemo:"डेमो देखें",learnMore:"अधिक जानें"},sections:{categories:{title:"शीर्ष",highlight:"श्रेणियाँ",subtext:"अपनी सभी आवश्यकताओं के लिए सुरक्षा समाधानों की हमारी विस्तृत श्रृंखला देखें"},safetyIds:{title:"वी-कवच",highlight:"सुरक्षा आईडी",subtext:"लोगों और संपत्ति के लिए अगली पीढ़ी का आपातकालीन क्यूआर पारिस्थितिकी तंत्र"},securityProducts:{title:"उन्नत",highlight:"सुरक्षा",subtext:"आपकी उच्च-मूल्य वाली संपत्तियों के लिए बुद्धिमान निगरानी और सुरक्षा"},services:{title:"प्रमुख",highlight:"विशेषताएं",subtext:"वी-कवच उन्नत निगरानी और अलर्ट के साथ यात्रा को सुरक्षित रखता है"},features:{title:"सुरक्षा",highlight:"विशेषताएं",subtext:"आपको और आपके प्रियजनों को सुरक्षित रखने के लिए उन्नत तकनीक"},initiative:{title:"सामाजिक",highlight:"पहल",subtext:"मिशन रक्षक: सामान्य नागरिक के लिए सुरक्षा सशक्त बनाना।",p1:"वी-कवच (तार्क्ष्य समाधान का एक उत्पाद) में, हमारा मानना है कि सुरक्षा एक मौलिक अधिकार है, विलासिता नहीं। मिशन रक्षक हर किसी के लिए स्मार्ट सुरक्षा लाने की हमारी समर्पित पहल है।",p2:"रियायती कार्यक्रमों और सामुदायिक जागरूकता के माध्यम से, हमारा लक्ष्य 2026 तक 100,000+ जीवन की रक्षा करना है। भारत को सुरक्षित बनाने में हमारे साथ जुड़ें।"}},about:{title:"वी-कवच",highlight:"के बारे में",content:`<b>वी-कवच</b>, <b>तार्क्ष्य समाधान</b> का एक गौरवशाली उत्पाद, एक अगली पीढ़ी का डिजिटल सुरक्षा पारिस्थितिकी तंत्र है, जो एक मुख्य मिशन द्वारा संचालित है: भारतीय सड़कों, समुदायों और दैनिक जीवन को सुरक्षित बनाना। <b>गोपनीयता-प्रथम कॉल मास्किंग</b> और उन्नत तकनीक का लाभ उठाकर, हम आपात स्थिति के दौरान संचार को सहज, सुरक्षित और तत्काल बनाते हैं।

चाहे वह गलत तरीके से खड़ा वाहन हो, खोया हुआ पालतू जानवर हो, या किसी प्रियजन से जुड़ी महत्वपूर्ण आपात स्थिति हो—वी-कवच सुनिश्चित करता है कि आपके मोबाइल नंबर जैसे व्यक्तिगत जानकारी को उजागर किए बिना तत्काल सहायता आप तक पहुंचे। हमारा बुद्धिमान सिस्टम आपकी पहचान को पूरी तरह से सुरक्षित रखते हुए आपको वास्तविक दुनिया के समाधानों से सहजता से जोड़ता है।

हमारा विज़न केवल एक उत्पाद पेश करने से कहीं आगे है; हम एक <b>सुरक्षित भविष्य</b> के निर्माण के लिए समर्पित हैं जहाँ संचार निर्बाध हो और गोपनीयता से कभी समझौता न हो। निरंतर नवाचार और <b>उपयोगकर्ता-केंद्रित दृष्टिकोण</b> द्वारा संचालित, वी-कवच आपके और आपके परिवार के लिए चौबीसों घंटे (<b>24/7</b>) सुरक्षा और मानसिक शांति सुनिश्चित करने के लिए प्रतिबद्ध है।

• <b>नेक्स्ट-जेन सुरक्षा:</b> आधुनिक सुरक्षा आवश्यकताओं के लिए एक व्यापक डिजिटल पारिस्थितिकी तंत्र।
• <b>गोपनीयता-प्रथम दृष्टिकोण:</b> 100% सुरक्षित कॉल मास्किंग जो आपके मोबाइल नंबर को छुपाती है।
• <b>तत्काल आपातकालीन कनेक्टिविटी:</b> जब आपको इसकी सबसे अधिक आवश्यकता हो, तो तेज़, विश्वसनीय और अनाम संचार।
• <b>24/7 सुरक्षा:</b> आपके, आपके प्रियजनों और आपकी संपत्ति के लिए समझौता रहित सुरक्षा।`,stats:{activeUsers:"10k+ सुरक्षित उपयोगकर्ता",scansProtected:"100% गोपनीयता सुनिश्चित",monitoring:"24/7 आपातकालीन हेल्पलाइन"}},footer:{tagline:"आपकी दुनिया को सुरक्षित करना",description:"वी-कवच (तार्क्ष्य समाधान का एक उत्पाद) अत्याधुनिक डिजिटल और भौतिक सुरक्षा पारिस्थितिकी तंत्र प्रदान करता है, जो भारतीय नवाचार के साथ सबसे महत्वपूर्ण चीजों की रक्षा करता है।",quickLinks:"त्वरित संपर्क",aboutUs:"हमारे बारे में",privacyPolicy:"गोपनीयता नीति",termsConditions:"नियम और शर्तें",contactUs:"संपर्क करें",rights:"सर्वाधिकार सुरक्षित।"},smartQR:{title:"स्मार्ट क्यूआर पहचान",subtitle:"हमारी उन्नत क्यूआर तकनीक से सुरक्षित रहें। वाहन, पालतू जानवर और प्रियजन — तत्काल कनेक्टिविटी और गोपनीयता के साथ सुरक्षित।",getYourID:"अपनी स्मार्ट आईडी प्राप्त करें",howItWorks:"यह कैसे काम करता है",steps:{scan:{title:"स्कैन",desc:"कोई भी व्यक्ति जिसे आपका खोया हुआ सामान या वाहन मिलता है, वह किसी भी स्मार्टफोन कैमरे का उपयोग करके क्यूआर कोड स्कैन करता है।"},connect:{title:"जुड़ें",desc:"वे तुरंत मालिक से संपर्क करने के लिए एक सुरक्षित पृष्ठ पर भेज दिए जाते हैं।"},call:{title:"मालिक को कॉल करें",desc:"वे आपको तुरंत कॉल कर सकते हैं। आपका नंबर हमारी कॉल मास्किंग तकनीक के माध्यम से निजी रहता है।"}},featuresTitle:"प्रमुख विशेषताएं",features:["कॉल मास्किंग","एसएमएस और व्हाट्सएप अलर्ट","आपातकालीन संपर्क","कोई ऐप आवश्यक नहीं","टिकाऊ टैग"],orderNow:"अभी ऑर्डर करें"},cloudMonitoring:{title:"लाइव क्लाउड मॉनिटरिंग",subtitle:"सुरक्षित सीसीटीवी बैकअप",badge:"जल्द आ रहा है",infoTitle:"क्लाउड इंटेलिजेंस से सुरक्षित करें",infoDesc:"हमारा क्लाउड मॉनिटरिंग समाधान सुनिश्चित करता है कि आपका फुटेज सुरक्षित रहे।",featuresTitle:"विशेषताएं:",features:["रियल-टाइम बैकअप","मोशन डिटेक्शन","एंटी-थेफ्ट सुरक्षा","रिमोट एक्सेस"]},gpsTracking:{title:"उन्नत जीपीएस ट्रैकिंग",subtitle:"रियल-टाइम स्थान प्रबंधन",badge:"जल्द आ रहा है",infoTitle:"हर संपत्ति के लिए सटीक ट्रैकिंग",infoDesc:"रीयल-टाइम स्थान डेटा से जुड़े रहें।",featuresTitle:"विशेषताएं:",features:["लाइव ट्रैकिंग","जियोफेंसिंग","गति निगरानी","रूट प्लेबैक","ईंधन विश्लेषण"]},social:{title:"मिशन रक्षक",subtitle:"सुरक्षित सड़कों के लिए हमारी प्रतिबद्धता।",storyTitle:"कहानी",storyPart1:"मिशन रक्षक का जन्म एक साधारण अहसास से हुआ था: आपात स्थिति में, हर सेकंड मायने रखता है।",storyPart2:"हम सार्वजनिक परिवहन, बुजुर्गों और बच्चों को रियायती स्मार्ट क्यूआर स्टिकर वितरित करते हैं।",stats:{vision:"दृष्टि",visionDesc:"10,000+ जीवन प्रभावित",partners:"तलाश",partnersDesc:"पार्टनर्स",initiative:"पहल",initiativeDesc:"हमारी पहल"},formTitle:"फ्रैंचाइज़ी पार्टनर बनें",form:{name:"पूरा नाम",namePlaceholder:"अपना नाम दर्ज करें",email:"ईमेल पता",emailPlaceholder:"email@example.com",phone:"फ़ोन नंबर",phonePlaceholder:"+91 00000 00000",message:"संदेश",messagePlaceholder:"आप कैसे योगदान देना चाहेंगे?",submit:"मिशन में शामिल हों",submitting:"भेज रहा है...",success:"व्हाट्सएप पर भेज रहा है..."}},auth:{login:{title:"अपने इकोसिस्टम को सुरक्षित करें",subtitle:"भारत के सबसे उन्नत सुरक्षा नेटवर्क में शामिल हों।",features:[{title:"बैंक-ग्रेड सुरक्षा",desc:"256-बिट एन्क्रिप्शन"},{title:"बेड़े की सुरक्षा",desc:"रियल-टाइम वाहन स्थिति"},{title:"तत्काल अलर्ट",desc:"एसएमएस और कॉल अलर्ट"},{title:"क्लाउड बैकअप",desc:"सुरक्षित रिकॉर्ड"}],cardTitle:"वापसी पर स्वागत है",cardDesc:"प्रवेश के लिए अपनी साख दर्ज करें।",email:"ईमेल पता",emailPlaceholder:"name@company.com",password:"पासवर्ड",passwordPlaceholder:"••••••••",submit:"पोर्टल एक्सेस करें",submitting:"प्रमाणित किया जा रहा है...",noAccount:"इकोसिस्टम में नए हैं?",registerNow:"अभी रजिस्टर करें"},signup:{title:"पहचान प्रारंभ करें",subtitle:"अगली पीढ़ी के सुरक्षा इकोसिस्टम से जुड़ें।",cardTitle:"खाता बनाएं",cardDesc:"अपनी संपत्तियों के प्रबंधन के लिए शामिल हों।",name:"पूरा नाम",namePlaceholder:"अपना नाम दर्ज करें",email:"ईमेल पता",emailPlaceholder:"name@company.com",password:"पासवर्ड",passwordPlaceholder:"पासवर्ड बनाएं",confirmPassword:"पुष्टि करें",confirmPasswordPlaceholder:"पासवर्ड की पुष्टि करें",submit:"रजिस्टर करें",submitting:"खाता बनाया जा रहा है...",hasAccount:"पहले से सदस्य हैं?",loginHere:"यहाँ लॉगिन करें"}},products:{catalog:"उत्पाद कैटलॉग",viewDetails:"विवरण देखें",material:"सामग्री",warranty:"वारंटी",off:"छूट",addedToCart:"कार्ट में जोड़ा गया!",items:{"kids-safety-bracelet":"बच्चों का सुरक्षा ब्रेसलेट","luggage-smart-tag":"सामान का स्मार्ट टैग","pet-id-tag":"पालतू जानवर आईडी टैग","vehicle-safety-sticker":"वाहन सुरक्षा स्टिकर"}},cart:{breadcrumb:"होम / कार्ट",title:"शॉपिंग कार्ट",empty:{title:"आपकी कार्ट खाली है",desc:"ऐसा लगता है कि आपने अभी तक अपनी कार्ट में कोई सुरक्षा आईडी नहीं जोड़ी है। आज ही अपनी संपत्ति सुरक्षित करें!",button:"उत्पाद देखें"},items:{secureId:"सुरक्षित पहचान"},summary:{title:"ऑर्डर सारांश",subtotal:"उप-योग",shipping:"शिपिंग",shippingFree:"मुफ्त",platformFee:"प्लेटफॉर्म शुल्क",total:"कुल",checkout:"चेकआउट करें",protection:"सभी भुगतान बैंक-ग्रेड एन्क्रिप्शन के साथ सुरक्षित हैं। आपका डेटा 100% निजी है।"}},checkout:{returnCart:"कार्ट पर वापस जाएं",title:"शिपिंग और रसद",form:{consignee:"प्राप्तकर्ता का नाम",consigneePlaceholder:"प्राप्तकर्ता का पूरा नाम",contact:"संपर्क ईमेल",contactPlaceholder:"email@example.com",phone:"मोबाइल नंबर",phonePlaceholder:"+91 00000 00000",address:"शिपिंग का पता",addressPlaceholder:"घर नंबर, बिल्डिंग, सड़क, क्षेत्र",city:"शहर / कस्बा",cityPlaceholder:"शहर दर्ज करें",pincode:"पिनकोड",pincodePlaceholder:"000000"},summary:{title:"रसद सारांश",subtotal:"कुल राशि",logistics:"शिपिंग और हैंडलिंग",complimentary:"नि:शुल्क",total:"देय राशि",payment:{title:"भुगतान प्रोटोकॉल",desc:"वर्तमान में कैश ऑन डिलीवरी (COD) स्वीकार की जा रही है। डिजिटल भुगतान गेटवे जल्द ही शुरू होगा।"},submit:"ऑर्डर सबमिट करें",submitting:"प्रोसेस हो रहा है...",encryption:"एईएस-256 बिट एन्क्रिप्टेड"}},orderSuccess:{title:"ऑर्डर सफल",subtitle:"आपका सुरक्षा इकोसिस्टम तैयार किया जा रहा है। हमने आपके पंजीकृत ईमेल पर पुष्टि भेज दी है।",nextStepsTitle:"आगे क्या होगा?",steps:["स्मार्ट क्यूआर टैग्स की गुणवत्ता जांच","लॉजिस्टिक्स पार्टनर के माध्यम से शिपिंग","3-5 दिनों के भीतर आपके घर तक डिलीवरी"],returnHome:"होम पर वापस",dashboard:"डैशबोर्ड पर जाएं",secure:"बैंक-ग्रेड सुरक्षा",downloadInvoice:"इनवॉइस पीडीएफ"},dashboard:{sidebar:{orders:"मेरे ऑर्डर",tags:"मेरे क्यूआर टैग",profile:"प्रोफ़ाइल",logout:"लॉगआउट"},welcome:{greet:"स्वागत है,",ordersDesc:"आपके खाते में ऑर्डर",qrTitle:"मेरी क्यूआर पहचान",qrDesc:"अपनी स्मार्ट सुरक्षा संपत्तियों का प्रबंधन करें",profileTitle:"प्रोफ़ाइल सेटिंग्स",profileDesc:"अपनी पहचान और सुरक्षा का प्रबंधन करें"},stats:{totalOrders:"कुल ऑर्डर",secureTags:"सुरक्षित टैग",pending:"लंबित ऑर्डर"},topbar:{path:"डैशबोर्ड /",orders:"ऑर्डर",tags:"क्यूआर टैग",profile:"प्रोफ़ाइल"},orders:{title:"ऑर्डर इतिहास",empty:"आपके खाते में कोई ऑर्डर नहीं मिला।",table:{id:"ऑर्डर आईडी",date:"तारीख",items:"आइटम",amount:"राशि",payment:"भुगतान",status:"स्थिति"}},tags:{title:"मेरे स्मार्ट टैग",empty:"आपने अभी तक कोई टैग सक्रिय नहीं किया है।",card:{code:"टैग कोड:",preview:"पूर्वावलोकन",download:"डाउनलोड"}},profile:{title:"प्रोफ़ाइल संपादित करें",name:"पूरा नाम",phone:"फ़ोन नंबर",passwordTitle:"सुरक्षा",passwordDesc:"अपना खाता पासवर्ड बदलें",currentPassword:"वर्तमान पासवर्ड",newPassword:"नया पासवर्ड",currentPlaceholder:"••••••••",newPlaceholder:"••••••••",save:"बदलाव सहेजें"}},common:{loading:"लोड हो रहा है...",loadFailed:"डेटा लोड करने में विफल",profileUpdated:"प्रोफ़ाइल सफलतापूर्वक अपडेट की गई",error:"कुछ गलत हो गया"},publicProfile:{loading:"पहचान प्राप्त की जा रही है...",invalid:{title:"सुरक्षा क्लस्टर नहीं मिला",desc:"यह क्यूआर कोड या तो अमान्य है या अभी तक सक्रिय नहीं किया गया है।"},header:{badge:"सत्यापित संपत्ति",assetId:"संपत्ति आईडी:"},banner:"वी-कवच प्रोटोकॉल द्वारा सुरक्षित",owner:"सम्मानित मालिक",locationVerified:"स्थान सत्यापित",form:{phonePlaceholder:"जुड़ने के लिए मोबाइल दर्ज करें...",callButton:"मालिक को कॉल करें",connecting:"जुड़ रहा है...",emergency:"आपातकालीन — 112 पर कॉल करें",shareLocation:"लाइव लोकेशन साझा करें"},howItWorks:{title:"यह कैसे काम करता है",steps:[{label:"क्यूआर स्कैन करें"},{label:"सत्यापित करें"},{label:"जुड़ें"}]},footer:{protocol:"वी-कवच प्रोटोकॉल सक्रिय",terms:"नियम",privacy:"गोपनीयता",about:"परिचय"}},admin:{sidebar:{masterPanel:"मास्टर पैनल",bulkManage:"थोक प्रबंधन",logout:"लॉगआउट"},stats:{activeQRs:"सक्रिय क्यूआर",totalScans:"कुल स्कैन"}},legal:{back:"होम पर वापस",subtitle:"आधिकारिक दस्तावेज और नीतियां",loading:"दस्तावेज प्राप्त किए जा रहे हैं...",fallback:"सामग्री अपडेट की जा रही है। कृपया बाद में देखें।",error:"सामग्री लोड करने में असमर्थ। कृपया पुनः प्रयास करें।"},services:{backToHome:"होम पर वापस",items:{"instant-call-masking":{title:"तत्काल कॉल मास्किंग",content:"<p>V-KAWACH की तत्काल कॉल मास्किंग तकनीक हर कॉल के दौरान आपके असली फोन नंबर को छिपाकर आपकी गोपनीयता की रक्षा करती है। जब कोई आपका QR टैग स्कैन करके कॉल शुरू करता है, तो हमारा सिस्टम दोनों पक्षों को एक सुरक्षित मास्क्ड नंबर के माध्यम से जोड़ता है।</p><h2>मुख्य लाभ</h2><ul><li>आपका असली फोन नंबर 100% निजी रहता है</li><li>कॉलर के लिए कोई ऐप की जरूरत नहीं</li><li>आपातकाल में तत्काल कनेक्शन</li><li>डैशबोर्ड में पूरा कॉल लॉग</li></ul>"},"emergency-helplines":{title:"आपातकालीन हेल्पलाइन",content:"<p>V-KAWACH आपके QR स्कैन पेज से भारत की महत्वपूर्ण आपातकालीन हेल्पलाइन तक सीधी पहुंच एकीकृत करता है।</p><h2>एकीकृत हेल्पलाइन</h2><ul><li>पुलिस — 100</li><li>एम्बुलेंस — 108</li><li>दमकल — 101</li><li>राष्ट्रीय आपातकाल — 112</li><li>महिला हेल्पलाइन — 1091</li></ul>"},"location-sharing":{title:"लाइव लोकेशन शेयरिंग",content:"<p>V-KAWACH QR स्कैन पेज से सीधे रियल-टाइम GPS लोकेशन शेयरिंग सक्षम करता है। एक टैप से खोजकर्ता WhatsApp के माध्यम से अपनी वर्तमान लोकेशन आपके साथ शेयर कर सकता है।</p><h2>लाभ</h2><ul><li>खोजकर्ता के लिए कोई ऐप की जरूरत नहीं</li><li>WhatsApp के माध्यम से तुरंत GPS निर्देशांक</li><li>सभी आधुनिक स्मार्टफोन पर काम करता है</li></ul>"},"data-privacy":{title:"डेटा गोपनीयता",content:"<p>V-KAWACH में, आपका व्यक्तिगत डेटा बैंक-ग्रेड सुरक्षा के साथ संरक्षित है। हम केवल आवश्यक डेटा संग्रहीत करते हैं और इसे कभी तीसरे पक्ष को नहीं बेचते।</p><h2>हमारी गोपनीयता प्रतिबद्धताएं</h2><ul><li>256-बिट एन्क्रिप्शन</li><li>फोन नंबर कभी उजागर नहीं होते</li><li>QR कोड में कोई व्यक्तिगत जानकारी नहीं</li><li>डैशबोर्ड से कभी भी डेटा हटाएं</li></ul>"},"family-control":{title:"पारिवारिक नियंत्रण",content:"<p>V-KAWACH का फैमिली कंट्रोल फीचर आपको अपने परिवार के हर सदस्य — बच्चों, बुजुर्ग माता-पिता, पालतू जानवरों और वाहनों — के लिए एकल डैशबोर्ड से सुरक्षा प्रोफाइल प्रबंधित करने देता है।</p><h2>सुविधाएं</h2><ul><li>प्रत्येक परिवार सदस्य के लिए अलग QR प्रोफाइल</li><li>प्रति प्रोफाइल आपातकालीन संपर्क</li><li>किसी भी QR स्कैन पर तुरंत अलर्ट</li></ul>"},"verified-id":{title:"सत्यापित पहचान",content:"<p>हर V-KAWACH QR टैग एक सत्यापित डिजिटल पहचान से जुड़ा है। हमारी सत्यापन प्रणाली सुनिश्चित करती है कि प्रत्येक QR कोड प्रामाणिक, छेड़छाड़-रोधी और ट्रेस करने योग्य है।</p><h2>सत्यापन प्रक्रिया</h2><ul><li>OTP के माध्यम से मोबाइल नंबर सत्यापन</li><li>प्रति उपयोगकर्ता अद्वितीय QR कोड</li><li>एंटी-काउंटरफीट सुरक्षा</li></ul>"},"app-support":{title:"ऐप सपोर्ट",content:"<p>V-KAWACH बिना किसी ऐप इंस्टॉलेशन के काम करने के लिए डिज़ाइन किया गया है। सब कुछ सीधे ब्राउज़र में काम करता है।</p><h2>संगतता</h2><ul><li>कैमरे वाले किसी भी स्मार्टफोन पर काम करता है</li><li>खोजकर्ताओं के लिए कोई ऐप डाउनलोड आवश्यक नहीं</li><li>Android और iOS पर समर्थित</li></ul>"},"audio-alerts":{title:"ऑडियो अलर्ट",content:"<p>V-KAWACH कनेक्टेड स्मार्ट डिवाइस के लिए ऑडियो अलर्ट एकीकरण का समर्थन करता है। जब आपका QR स्कैन होता है, तो आप अपने पंजीकृत डिवाइस पर रियल-टाइम ऑडियो सूचनाएं प्राप्त कर सकते हैं।</p><h2>अलर्ट प्रकार</h2><ul><li>लोकेशन के साथ QR स्कैन सूचना</li><li>आपातकालीन संकट संकेत</li><li>मास्क्ड नंबर से इनकमिंग कॉल अलर्ट</li></ul>"},"qr-security":{title:"क्यूआर सुरक्षा",content:"<p>V-KAWACH के QR कोड बहु-परत सुरक्षा के साथ बनाए गए हैं। प्रत्येक कोड अद्वितीय रूप से उत्पन्न, सर्वर-सत्यापित और छेड़छाड़-स्पष्ट है।</p><h2>सुरक्षा सुविधाएं</h2><ul><li>प्रति QR कोड वन-टाइम क्रिप्टोग्राफिक की</li><li>प्रत्येक स्कैन पर सर्वर-साइड सत्यापन</li><li>एंटी-क्लोन डिटेक्शन सिस्टम</li><li>वाटरप्रूफ और स्क्रैच-प्रतिरोधी भौतिक टैग</li></ul>"},verified:{title:"सत्यापित प्रोटोकॉल",content:"<p>V-KAWACH सत्यापित प्रोटोकॉल हमारा एंड-टू-एंड ट्रस्ट फ्रेमवर्क है जो सुनिश्चित करता है कि QR स्कैन से लेकर मालिक संपर्क तक हर इंटरैक्शन प्रमाणित और सुरक्षित हो।</p><h2>प्रोटोकॉल परतें</h2><ul><li>परत 1: QR कोड प्रामाणिकता जांच</li><li>परत 2: मालिक पहचान सत्यापन</li><li>परत 3: कॉल मास्किंग और गोपनीयता शील्ड</li><li>परत 4: इंटरैक्शन लॉगिंग</li><li>परत 5: आपातकालीन एस्केलेशन</li></ul>"},"instant-alerts":{title:"तत्काल अलर्ट",content:"<p>V-KAWACH आपके QR कोड के स्कैन होते ही रियल-टाइम अलर्ट भेजता है।</p><h2>अलर्ट चैनल</h2><ul><li>आपके पंजीकृत नंबर पर SMS</li><li>स्कैन लोकेशन के साथ WhatsApp संदेश</li><li>इन-ऐप पुश नोटिफिकेशन</li><li>टाइमस्टैम्प के साथ ईमेल अलर्ट</li></ul>"},"smart-tracking":{title:"स्मार्ट ट्रैकिंग",content:"<p>V-KAWACH की स्मार्ट ट्रैकिंग सुविधा आपकी संपत्तियों की रियल-टाइम दृश्यता प्रदान करती है।</p><h2>ट्रैकिंग सुविधाएं</h2><ul><li>स्कैन पर रियल-टाइम GPS लोकेशन</li><li>टाइमस्टैम्प के साथ ऐतिहासिक स्कैन लॉग</li><li>जियोफेंस अलर्ट</li><li>वाहनों के लिए रूट प्लेबैक</li></ul>"},"emergency-help":{title:"आपातकालीन सहायता",content:"<p>V-KAWACH की आपातकालीन सहायता प्रणाली संकट में लोगों को तुरंत सही संसाधनों से जोड़ने के लिए डिज़ाइन की गई है।</p><h2>आपातकालीन सुविधाएं</h2><ul><li>आपातकालीन सेवाओं (112) पर वन-टैप डायल</li><li>स्कैन पर तुरंत मालिक सूचना</li><li>प्री-फिल्ड आपातकालीन संदेश टेम्पलेट</li></ul>"}}},categoryDetails:{initializing:"सुरक्षा परत शुरू की जा रही है...",notFound:"सुरक्षा क्लस्टर नहीं मिला",discoverMore:"अधिक जानें",relatedProducts:"संबंधित सुरक्षा हार्डवेयर",productsDesc:"इस श्रेणी के लिए हमारे विशेष हार्डवेयर मॉड्यूल देखें",viewSpecs:"विवरण देखें",precisionSecurity:"सटीक सुरक्षा",advancedProtocols:"उन्नत सुरक्षा प्रोटोकॉल",standardProtocols:"इस श्रेणी के लिए मानक वी-कवच सुरक्षा प्रोटोकॉल सक्रिय हैं।",strategicProtection:"रणनीतिक सुरक्षा",verifiedSecurity:"सत्यापित सुरक्षा",certifiedHardware:"प्रमाणित हार्डवेयर",stats:{scanRate:"सफलता दर",alertSpeed:"अलर्ट स्पीड",encryption:"एन्क्रिप्शन"}},productDetails:{initializing:"हार्डवेयर विवरण प्राप्त किया जा रहा है...",notFound:"हार्डवेयर मॉड्यूल नहीं मिला",badge:"सुरक्षा हार्डवेयर",encryption:"एन्क्रिप्शन",delivery:"डिलीवरी",addToCart:"कार्ट में जोड़ें",keyFeatures:"प्रमुख विशेषताएं",description:"विवरण"},b2bPage:{title:"Smart Brand QR",subtitle:"आपके FMCG उत्पादों के लिए डिजिटल परिवर्तन",content:"Smart Brand QR: अपने FMCG उत्पादों (जैसे एडिबल ऑयल, पैकेजिंग) को डिजिटल बनाएं। हमारे स्मार्ट QR के साथ ग्राहकों को तुरंत FSSAI डिटेल्स, प्रोडक्ट ब्रोशर और कस्टमर केयर की जानकारी दिखाएं।",cta:"B2B के लिए संपर्क करें"}}},aj=C.header`
  position: sticky;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 1000;
  background-color: #ffffff;
  transition: all 0.3s ease;
  padding: 12px 0;
  border-bottom: 1px solid #eeeeee;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
`,nj=C.div`
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
`,ij=C(Ze)`
  display: flex;
  align-items: center;
  gap: 10px;
  color: #0b1a33;
  font-family: ${({theme:i})=>i.fonts.display};
  font-size: 1.5rem;
  font-weight: 700;
  text-decoration: none;
  white-space: nowrap;

  svg {
    color: ${({theme:i})=>i.colors.gold};
  }
`,lj=C.nav`
  display: none;

  @media (min-width: ${({theme:i})=>i.breakpoints.tablet}) {
    display: flex;
    align-items: center;
    gap: 15px;
  }
`,xm=C(Ze)`
  color: #333333;
  font-family: ${({theme:i})=>i.fonts.body};
  font-size: 0.9rem;
  font-weight: 700;
  position: relative;
  text-decoration: none;
  transition: all 0.3s ease;
  white-space: nowrap;

  &:hover, &.active {
    color: ${({theme:i})=>i.colors.gold};
  }

  &::after {
    content: '';
    position: absolute;
    bottom: -5px;
    left: 0;
    width: 0;
    height: 2px;
    background-color: ${({theme:i})=>i.colors.gold};
    transition: width 0.3s ease;
  }

  &:hover::after, &.active::after {
    width: 100%;
  }
`,rj=C.div`
  position: fixed;
  top: 0;
  right: 0;
  height: 100vh;
  width: 300px;
  background-color: ${({theme:i})=>i.colors.navy};
  box-shadow: -5px 0 15px rgba(0,0,0,0.5);
  transform: translateX(${({$isOpen:i})=>i?"0":"100%"});
  transition: transform 0.3s ease;
  z-index: 1001;
  padding: 80px 30px;
  display: flex;
  flex-direction: column;
  gap: 20px;

  @media (min-width: ${({theme:i})=>i.breakpoints.tablet}) {
    display: none;
  }
`,oj=C.button`
  background: none;
  border: none;
  color: #0b1a33;
  cursor: pointer;
  z-index: 1002;

  @media (min-width: ${({theme:i})=>i.breakpoints.tablet}) {
    display: none;
  }
`,sj=C(Ze)`
  position: relative;
  color: ${({theme:i})=>i.colors.navy};
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  
  &:hover { 
    transform: scale(1.15);
  }
  
  span {
    position: absolute;
    top: -8px;
    right: -8px;
    background: ${({theme:i})=>i.colors.gold};
    color: white;
    font-size: 10px;
    font-weight: 900;
    min-width: 18px;
    height: 18px;
    padding: 0 4px;
    border-radius: 9px;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px solid white;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  }
`,ym=C.button`
  background: #f8f9fa;
  border: 1px solid #eee;
  color: #333;
  padding: 6px 12px;
  border-radius: 8px;
  font-size: 0.8rem;
  font-weight: 800;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 5px;
  transition: all 0.3s ease;
  
  &:hover {
    background: #eee;
    border-color: ${({theme:i})=>i.colors.gold};
    color: ${({theme:i})=>i.colors.gold};
  }
`,Md=()=>{const[i,s]=A.useState(!1),[u,c]=A.useState(!1),f=Ua(),{cartCount:p}=tr(),{language:h,setLanguage:v}=as();f.pathname,A.useEffect(()=>{const b=()=>{s(window.scrollY>50)};return window.addEventListener("scroll",b),()=>window.removeEventListener("scroll",b)},[]);const x=ns[h].nav,g=[{name:x.home,path:"/"},{name:x.qrSafety,path:"/smart-qr"},{name:x.b2b,path:"/b2b-solutions"},{name:x.cloudMonitoring,path:"/cloud-monitoring"},{name:x.initiative,path:"/social-initiative"}];return l.jsx(aj,{children:l.jsxs(nj,{children:[l.jsxs(ij,{to:"/",children:[l.jsx("img",{src:_g,alt:"V-KAWACH Logo",onError:b=>{b.target.style.display="none",b.target.nextSibling.style.display="block"},style:{height:"55px",objectFit:"contain",borderRadius:"4px"}}),l.jsx(Zt,{size:32,style:{display:"none"}}),l.jsx("div",{children:l.jsx("div",{style:{lineHeight:"1",letterSpacing:"0.04em",fontSize:"1.8rem",fontWeight:800,whiteSpace:"nowrap"},children:"V-KAWACH"})})]}),l.jsxs(lj,{children:[g.map(b=>l.jsx(xm,{to:b.path,className:f.pathname===b.path?"active":"",children:b.name},b.path)),l.jsxs(sj,{to:"/cart",children:[l.jsx(er,{size:24}),p>0&&l.jsx("span",{children:p})]}),l.jsxs(ym,{onClick:()=>v(h==="en"?"hi":"en"),children:[l.jsx(mm,{size:16}),h==="en"?"HI":"EN"]}),l.jsx(qe,{as:Ze,to:"/dashboard",variant:"primary",children:x.login})]}),l.jsx(oj,{onClick:()=>c(!u),children:u?l.jsx(kg,{size:28}):l.jsx(s5,{size:28})}),l.jsxs(rj,{$isOpen:u,children:[g.map(b=>l.jsx(xm,{to:b.path,onClick:()=>c(!1),children:b.name},b.path)),l.jsxs(ym,{onClick:()=>v(h==="en"?"hi":"en"),style:{width:"fit-content"},children:[l.jsx(mm,{size:16}),h==="en"?"Hindi (हिन्दी)":"English"]}),l.jsx(qe,{as:Ze,to:"/dashboard",onClick:()=>c(!1),variant:"primary",style:{width:"100%"},children:x.login})]})]})})},cj=C.footer`
  background-color: ${({theme:i})=>i.colors.navy};
  color: ${({theme:i})=>i.colors.white};
  padding: 80px 0 30px;
  border-top: 1px solid rgba(255,255,255,0.1);
`,uj=C.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
  display: grid;
  grid-template-columns: 1fr;
  gap: 40px;

  @media (min-width: ${({theme:i})=>i.breakpoints.tablet}) {
    grid-template-columns: 2fr 1fr 1fr;
  }
`,Ou=C.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
`,dj=C.div`
  display: flex;
  align-items: center;
  gap: 10px;
  font-family: ${({theme:i})=>i.fonts.display};
  font-size: 1.5rem;
  font-weight: 700;
  margin-bottom: 20px;

  svg {
    color: ${({theme:i})=>i.colors.gold};
  }
`,fj=C.p`
  opacity: 0.7;
  max-width: 350px;
  font-size: 0.95rem;
`,bm=C.h4`
  color: ${({theme:i})=>i.colors.gold};
  font-size: 1.1rem;
  margin-bottom: 10px;
`,hj=C.ul`
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 12px;
`,ql=C(Ze)`
  opacity: 0.7;
  font-size: 0.95rem;
  
  &:hover {
    opacity: 1;
    color: ${({theme:i})=>i.colors.gold};
    padding-left: 5px;
  }
  transition: all 0.3s ease;
`,Hu=C.div`
  display: flex;
  align-items: center;
  gap: 12px;
  opacity: 0.7;
  font-size: 0.95rem;

  svg {
    color: ${({theme:i})=>i.colors.gold};
    min-width: 18px;
  }
`,pj=C.div`
  display: flex;
  gap: 15px;
  margin-top: 20px;

  a {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    border: 1px solid rgba(255,255,255,0.2);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;

    &:hover {
      background-color: ${({theme:i})=>i.colors.gold};
      color: ${({theme:i})=>i.colors.navy};
      border-color: ${({theme:i})=>i.colors.gold};
    }
  }
`,mj=C.div`
  text-align: center;
  padding-top: 40px;
  margin-top: 60px;
  border-top: 1px solid rgba(255,255,255,0.1);
  opacity: 0.5;
  font-size: 0.85rem;
`,gj=()=>l.jsxs(cj,{children:[l.jsxs(uj,{children:[l.jsxs(Ou,{children:[l.jsxs(dj,{children:[l.jsx("img",{src:_g,alt:"Tarkshya Solution Logo",style:{height:"32px",objectFit:"contain",borderRadius:"4px"}}),l.jsxs("div",{children:[l.jsx("div",{style:{lineHeight:"1"},children:"Tarkshya Solution"}),l.jsx("div",{style:{fontSize:"0.6rem",fontWeight:400,opacity:.8,marginTop:"2px",letterSpacing:"0.05em",fontFamily:"sans-serif",textTransform:"uppercase"},children:"Securing your World"})]})]}),l.jsx(fj,{children:"Tarkshya Solution provides cutting-edge digital and physical security ecosystems, protecting what matters most with Indian innovation."}),l.jsxs(pj,{children:[l.jsx("a",{href:"#",children:l.jsx(e5,{size:20})}),l.jsx("a",{href:"#",children:l.jsx(X5,{size:20})}),l.jsx("a",{href:"#",children:l.jsx(J2,{size:20})})]})]}),l.jsxs(Ou,{children:[l.jsx(bm,{children:"Quick Links"}),l.jsxs(hj,{children:[l.jsx("li",{children:l.jsx(ql,{to:"/",children:"Home"})},"home"),l.jsx("li",{children:l.jsx(ql,{to:"/smart-qr",children:"Smart QR Safety"})},"smart-qr"),l.jsx("li",{children:l.jsx(ql,{to:"/cloud-monitoring",children:"Cloud Monitoring"})},"cloud"),l.jsx("li",{children:l.jsx(ql,{to:"/gps-tracking",children:"GPS Tracking"})},"gps"),l.jsx("li",{children:l.jsx(ql,{to:"/social-initiative",children:"Mission Rakshak"})},"social")]})]}),l.jsxs(Ou,{children:[l.jsx(bm,{children:"Contact Us"}),l.jsxs(Hu,{children:[l.jsx(Ag,{size:18}),l.jsx("span",{children:"Chandausi, Uttar Pradesh - 244412"})]}),l.jsxs(Hu,{children:[l.jsx(kd,{size:18}),l.jsx("span",{children:"contact@tarkshya.com"})]}),l.jsxs(Hu,{children:[l.jsx(cd,{size:18}),l.jsx("span",{children:"+91 88813 84777"})]})]})]}),l.jsxs(mj,{children:["© ",new Date().getFullYear()," Tarkshya Solution. All rights reserved."]})]}),xj=C.main`
  min-height: 100vh;
  padding-top: 0; // Header is overlay for hero effects
`,yj=()=>l.jsxs(l.Fragment,{children:[l.jsx(Md,{}),l.jsx(xj,{children:l.jsx(vb,{})}),l.jsx(gj,{})]}),bj=C.section`
  padding: ${({theme:i})=>i.spacing.xxl} 0;
  background-color: ${({$bg:i,theme:s})=>i==="light"?s.colors.background:i==="white"?s.colors.white:i||s.colors.white};
`,vj=C.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
`,Qe=({children:i,bg:s="white",className:u})=>l.jsx(bj,{$bg:s,className:u,children:l.jsx(vj,{children:i})});let jj={data:""},Sj=i=>{if(typeof window=="object"){let s=(i?i.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return s.nonce=window.__nonce__,s.parentNode||(i||document.head).appendChild(s),s.firstChild}return i||jj},wj=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,Cj=/\/\*[^]*?\*\/|  +/g,vm=/\n+/g,dn=(i,s)=>{let u="",c="",f="";for(let p in i){let h=i[p];p[0]=="@"?p[1]=="i"?u=p+" "+h+";":c+=p[1]=="f"?dn(h,p):p+"{"+dn(h,p[1]=="k"?"":s)+"}":typeof h=="object"?c+=dn(h,s?s.replace(/([^,])+/g,v=>p.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,x=>/&/.test(x)?x.replace(/&/g,v):v?v+" "+x:x)):p):h!=null&&(p=/^--/.test(p)?p:p.replace(/[A-Z]/g,"-$&").toLowerCase(),f+=dn.p?dn.p(p,h):p+":"+h+";")}return u+(s&&f?s+"{"+f+"}":f)+c},Ra={},Mg=i=>{if(typeof i=="object"){let s="";for(let u in i)s+=u+Mg(i[u]);return s}return i},Aj=(i,s,u,c,f)=>{let p=Mg(i),h=Ra[p]||(Ra[p]=(x=>{let g=0,b=11;for(;g<x.length;)b=101*b+x.charCodeAt(g++)>>>0;return"go"+b})(p));if(!Ra[h]){let x=p!==i?i:(g=>{let b,y,k=[{}];for(;b=wj.exec(g.replace(Cj,""));)b[4]?k.shift():b[3]?(y=b[3].replace(vm," ").trim(),k.unshift(k[0][y]=k[0][y]||{})):k[0][b[1]]=b[2].replace(vm," ").trim();return k[0]})(i);Ra[h]=dn(f?{["@keyframes "+h]:x}:x,u?"":"."+h)}let v=u&&Ra.g?Ra.g:null;return u&&(Ra.g=Ra[h]),((x,g,b,y)=>{y?g.data=g.data.replace(y,x):g.data.indexOf(x)===-1&&(g.data=b?x+g.data:g.data+x)})(Ra[h],s,c,v),h},zj=(i,s,u)=>i.reduce((c,f,p)=>{let h=s[p];if(h&&h.call){let v=h(u),x=v&&v.props&&v.props.className||/^go/.test(v)&&v;h=x?"."+x:v&&typeof v=="object"?v.props?"":dn(v,""):v===!1?"":v}return c+f+(h??"")},"");function is(i){let s=this||{},u=i.call?i(s.p):i;return Aj(u.unshift?u.raw?zj(u,[].slice.call(arguments,1),s.p):u.reduce((c,f)=>Object.assign(c,f&&f.call?f(s.p):f),{}):u,Sj(s.target),s.g,s.o,s.k)}let Dg,fd,hd;is.bind({g:1});let Ha=is.bind({k:1});function Ej(i,s,u,c){dn.p=s,Dg=i,fd=u,hd=c}function xn(i,s){let u=this||{};return function(){let c=arguments;function f(p,h){let v=Object.assign({},p),x=v.className||f.className;u.p=Object.assign({theme:fd&&fd()},v),u.o=/ *go\d+/.test(x),v.className=is.apply(u,c)+(x?" "+x:"");let g=i;return i[0]&&(g=v.as||i,delete v.as),hd&&g[0]&&hd(v),Dg(g,v)}return f}}var Tj=i=>typeof i=="function",pd=(i,s)=>Tj(i)?i(s):i,Nj=(()=>{let i=0;return()=>(++i).toString()})(),kj=(()=>{let i;return()=>{if(i===void 0&&typeof window<"u"){let s=matchMedia("(prefers-reduced-motion: reduce)");i=!s||s.matches}return i}})(),Rj=20,Og="default",Hg=(i,s)=>{let{toastLimit:u}=i.settings;switch(s.type){case 0:return{...i,toasts:[s.toast,...i.toasts].slice(0,u)};case 1:return{...i,toasts:i.toasts.map(h=>h.id===s.toast.id?{...h,...s.toast}:h)};case 2:let{toast:c}=s;return Hg(i,{type:i.toasts.find(h=>h.id===c.id)?1:0,toast:c});case 3:let{toastId:f}=s;return{...i,toasts:i.toasts.map(h=>h.id===f||f===void 0?{...h,dismissed:!0,visible:!1}:h)};case 4:return s.toastId===void 0?{...i,toasts:[]}:{...i,toasts:i.toasts.filter(h=>h.id!==s.toastId)};case 5:return{...i,pausedAt:s.time};case 6:let p=s.time-(i.pausedAt||0);return{...i,pausedAt:void 0,toasts:i.toasts.map(h=>({...h,pauseDuration:h.pauseDuration+p}))}}},_j=[],Mj={toasts:[],pausedAt:void 0,settings:{toastLimit:Rj}},Di={},Ug=(i,s=Og)=>{Di[s]=Hg(Di[s]||Mj,i),_j.forEach(([u,c])=>{u===s&&c(Di[s])})},Bg=i=>Object.keys(Di).forEach(s=>Ug(i,s)),Dj=i=>Object.keys(Di).find(s=>Di[s].toasts.some(u=>u.id===i)),Dd=(i=Og)=>s=>{Ug(s,i)},Oj=(i,s="blank",u)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:s,ariaProps:{role:"status","aria-live":"polite"},message:i,pauseDuration:0,...u,id:u?.id||Nj()}),ar=i=>(s,u)=>{let c=Oj(s,i,u);return Dd(c.toasterId||Dj(c.id))({type:2,toast:c}),c.id},ft=(i,s)=>ar("blank")(i,s);ft.error=ar("error");ft.success=ar("success");ft.loading=ar("loading");ft.custom=ar("custom");ft.dismiss=(i,s)=>{let u={type:3,toastId:i};s?Dd(s)(u):Bg(u)};ft.dismissAll=i=>ft.dismiss(void 0,i);ft.remove=(i,s)=>{let u={type:4,toastId:i};s?Dd(s)(u):Bg(u)};ft.removeAll=i=>ft.remove(void 0,i);ft.promise=(i,s,u)=>{let c=ft.loading(s.loading,{...u,...u?.loading});return typeof i=="function"&&(i=i()),i.then(f=>{let p=s.success?pd(s.success,f):void 0;return p?ft.success(p,{id:c,...u,...u?.success}):ft.dismiss(c),f}).catch(f=>{let p=s.error?pd(s.error,f):void 0;p?ft.error(p,{id:c,...u,...u?.error}):ft.dismiss(c)}),i};var Hj=Ha`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,Uj=Ha`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,Bj=Ha`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,Lj=xn("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${i=>i.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${Hj} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${Uj} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${i=>i.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${Bj} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,qj=Ha`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,Yj=xn("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${i=>i.secondary||"#e0e0e0"};
  border-right-color: ${i=>i.primary||"#616161"};
  animation: ${qj} 1s linear infinite;
`,$j=Ha`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,Gj=Ha`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,Qj=xn("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${i=>i.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${$j} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${Gj} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${i=>i.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,Vj=xn("div")`
  position: absolute;
`,Xj=xn("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,Kj=Ha`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,Zj=xn("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${Kj} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,Wj=({toast:i})=>{let{icon:s,type:u,iconTheme:c}=i;return s!==void 0?typeof s=="string"?A.createElement(Zj,null,s):s:u==="blank"?null:A.createElement(Xj,null,A.createElement(Yj,{...c}),u!=="loading"&&A.createElement(Vj,null,u==="error"?A.createElement(Lj,{...c}):A.createElement(Qj,{...c})))},Jj=i=>`
0% {transform: translate3d(0,${i*-200}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,Fj=i=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${i*-150}%,-1px) scale(.6); opacity:0;}
`,Ij="0%{opacity:0;} 100%{opacity:1;}",Pj="0%{opacity:1;} 100%{opacity:0;}",e3=xn("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,t3=xn("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,a3=(i,s)=>{let u=i.includes("top")?1:-1,[c,f]=kj()?[Ij,Pj]:[Jj(u),Fj(u)];return{animation:s?`${Ha(c)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${Ha(f)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}};A.memo(({toast:i,position:s,style:u,children:c})=>{let f=i.height?a3(i.position||s||"top-center",i.visible):{opacity:0},p=A.createElement(Wj,{toast:i}),h=A.createElement(t3,{...i.ariaProps},pd(i.message,i));return A.createElement(e3,{className:i.className,style:{...f,...u,...i.style}},typeof c=="function"?c({icon:p,message:h}):A.createElement(A.Fragment,null,p,h))});Ej(A.createElement);is`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`;var na=ft;const So=window.location.hostname==="localhost"?"http://localhost:5001/api":"/api",ta={get:async i=>{const s=localStorage.getItem("admin_token"),u=await fetch(`${So}${i}`,{headers:{Authorization:s?`Bearer ${s}`:"","Content-Type":"application/json"}}),c=await u.json();if(!u.ok)throw{response:{data:c}};return{data:c}},post:async(i,s)=>{const u=localStorage.getItem("admin_token"),c=s instanceof FormData,f=await fetch(`${So}${i}`,{method:"POST",headers:{Authorization:u?`Bearer ${u}`:"",...c?{}:{"Content-Type":"application/json"}},body:c?s:JSON.stringify(s)}),p=await f.json();if(!f.ok)throw{response:{data:p}};return{data:p}},put:async(i,s)=>{const u=localStorage.getItem("admin_token"),c=s instanceof FormData,f=await fetch(`${So}${i}`,{method:"PUT",headers:{Authorization:u?`Bearer ${u}`:"",...c?{}:{"Content-Type":"application/json"}},body:c?s:JSON.stringify(s)}),p=await f.json();if(!f.ok)throw{response:{data:p}};return{data:p}},delete:async i=>{const s=localStorage.getItem("admin_token"),u=await fetch(`${So}${i}`,{method:"DELETE",headers:{Authorization:s?`Bearer ${s}`:"","Content-Type":"application/json"}}),c=await u.json();if(!u.ok)throw{response:{data:c}};return{data:c}}};St`
  0% { transform: translateY(0px); }
  50% { transform: translateY(-10px); }
  100% { transform: translateY(0px); }
`;const n3=C.section`
  min-height: 65vh;
  background-color: #0b1a33;
  background-image: 
    radial-gradient(circle at 2px 2px, rgba(255,255,255,0.05) 1px, transparent 0);
  background-size: 40px 40px;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
  padding-top: 100px;
  padding-bottom: 40px;
  z-index: 1;

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(circle at 70% 50%, rgba(201, 168, 76, 0.1) 0%, transparent 70%);
    pointer-events: none;
  }
`,i3=C.div`
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 40px;
  display: grid;
  grid-template-columns: 1fr;
  gap: 40px;
  align-items: center;
  position: relative;
  z-index: 2;

  @media (min-width: 1024px) {
    grid-template-columns: 1.4fr 0.6fr;
  }
`,l3=C.h1`
  font-size: 2.2rem;
  line-height: 1.2;
  margin-bottom: 25px;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: -0.5px;
  
  .dim {
    display: block;
    color: white;
    font-size: 2.4rem;
  }

  .highlight {
    color: #C9A84C;
    display: block;
    font-size: 4rem;
    margin-top: 5px;
    line-height: 1.1;
  }

  @media (min-width: 1024px) {
    font-size: 3.2rem;
    .dim {
      font-size: 3.2rem;
    }
    .highlight {
      font-size: 5.2rem;
    }
  }
`,r3=C.p`
  font-size: 1.1rem;
  opacity: 0.7;
  margin-bottom: 30px;
  max-width: 650px;
  line-height: 1.6;
`,o3=C.div`
  position: relative;
  max-width: 70%;
  margin: 0 auto;
  @media (min-width: 1024px) { margin: 0 0 0 auto; }
  img {
    width: 100%;
    border-radius: 30px;
    box-shadow: 0 50px 100px rgba(0,0,0,0.5);
    border: 1px solid rgba(255,255,255,0.1);
  }
`,wo=C(Ze)`
  background-color: ${i=>i.variant==="outline"?"transparent":"#C9A84C"};
  color: ${i=>i.variant==="outline"?"white":"#0b1a33"};
  border: 2px solid ${i=>i.variant==="outline"?"white":"#C9A84C"};
  padding: 14px 28px;
  border-radius: 8px;
  font-weight: 800;
  text-transform: uppercase;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 10px;
  transition: all 0.3s ease;
  &:hover {
    transform: translateY(-3px);
    background-color: ${i=>i.variant==="outline"?"white":"#B08D35"};
    color: #0b1a33;
  }
`,Co=C.div`
  text-align: center;
  margin-bottom: 60px;
  h2 {
    font-size: 2.5rem;
    color: #0b1a33;
    font-weight: 800;
    text-transform: uppercase;
    span { color: #C9A84C; }
  }
  p { color: #666; margin-top: 10px; font-size: 1.1rem; }
  .line {
    width: 80px;
    height: 4px;
    background: #C9A84C;
    margin: 20px auto;
  }
  }
`;C.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 30px;
  max-width: 1400px;
  margin: 0 auto 50px;
  padding: 0 20px;
  
  @media (max-width: 992px) {
    grid-template-columns: 1fr;
  }
`;C.div`
  background: white;
  padding: 40px 30px;
  border-radius: 30px;
  border: 1px solid #eee;
  text-align: center;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0; height: 5px;
    background: #C9A84C;
    transform: scaleX(0);
    transition: transform 0.4s ease;
  }
  
  &:hover {
    transform: translateY(-10px);
    border-color: #C9A84C;
    box-shadow: 0 20px 40px rgba(11, 26, 51, 0.1);
    &::before { transform: scaleX(1); }
    .icon-box { background: #0b1a33; color: #C9A84C; }
  }
  
  .icon-box {
    width: 80px;
    height: 80px;
    background: #f8f9fa;
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 25px;
    color: #0b1a33;
    transition: all 0.4s ease;
  }
  
  h3 { font-size: 1.2rem; color: #0b1a33; margin-bottom: 10px; font-weight: 800; }
  p { color: #666; font-size: 0.9rem; margin-bottom: 0; }
`;const jm=C.div`
  position: relative;
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 50px;
  
  @media (max-width: 768px) {
    padding: 0 10px;
  }
`,Ao=C.button`
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 45px;
  height: 45px;
  border-radius: 50%;
  background: white;
  border: 1px solid #eee;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  z-index: 10;
  color: #0b1a33;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  transition: all 0.3s ease;
  
  &:hover {
    background: #0b1a33;
    color: white;
    box-shadow: 0 6px 166px rgba(0,0,0,0.2);
  }
  
  &.left { left: 0; }
  &.right { right: 0; }

  @media (max-width: 768px) {
    display: none;
  }
`,s3=C.div`
  display: flex;
  overflow-x: auto;
  gap: 20px;
  padding: 10px 0 30px;
  scrollbar-width: none;
  &::-webkit-scrollbar { display: none; }
  
  & > * {
    flex: 0 0 200px;
  }

  @media (max-width: 768px) {
    & > * {
      flex: 0 0 160px;
    }
  }
`,c3=C(Ze)`
  background: white;
  border: 1px solid rgba(0,0,0,0.06);
  padding: 35px 20px;
  border-radius: 24px;
  text-align: center;
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  cursor: pointer;
  text-decoration: none;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 200px;
  box-shadow: 0 8px 24px rgba(0,0,0,0.04);

  &:hover {
    transform: translateY(-12px);
    box-shadow: 0 25px 50px rgba(11, 26, 51, 0.12);
    border-color: #C9A84C;
    
    .icon-box {
      background: #0b1a33;
      color: #C9A84C;
      transform: scale(1.08);
    }
    h3 { color: #C9A84C; }
  }

  .icon-box {
    width: 72px;
    height: 72px;
    margin-bottom: 22px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f0f4f8;
    border-radius: 18px;
    color: #0b1a33;
    transition: all 0.4s ease;

    svg {
      width: 34px;
      height: 34px;
      stroke-width: 1.5px;
    }
  }

  h3 {
    font-size: 0.9rem;
    font-weight: 800;
    text-transform: uppercase;
    color: #0b1a33;
    letter-spacing: 1px;
    margin: 0;
    transition: color 0.3s;
  }
`,u3=C.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 30px;
  max-width: 1400px;
  margin: 0 auto;
`,d3=C.div`
  background: white;
  border-radius: 24px;
  overflow: hidden;
  border: 1px solid #eee;
  transition: all 0.4s ease;
  position: relative;
  &:hover {
    transform: translateY(-12px);
    border-color: #C9A84C;
    box-shadow: 0 30px 60px rgba(11, 26, 51, 0.1);
  }
  .badge {
    position: absolute;
    top: 20px;
    right: 20px;
    background: #0b1a33;
    color: #C9A84C;
    padding: 6px 12px;
    border-radius: 100px;
    font-size: 0.75rem;
    font-weight: 700;
    z-index: 2;
  }
  .img-box {
    height: 250px;
    background: #f8f9fa;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    img { max-width: 80%; max-height: 80%; object-fit: contain; }
  }
  .content {
    padding: 25px;
    h3 { font-size: 1.25rem; font-weight: 800; color: #0b1a33; margin-bottom: 8px; }
    .features {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 20px;
      span {
        font-size: 0.7rem;
        background: #f0f2f5;
        color: #0b1a33;
        padding: 4px 8px;
        border-radius: 4px;
        font-weight: 600;
        text-align: center;
      }
    }
    .price-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      .price {
        font-size: 1.4rem;
        font-weight: 900;
        color: #0b1a33;
        span { font-size: 0.9rem; color: #999; text-decoration: line-through; margin-left: 5px; }
      }
      .discount { color: #2ecc71; font-weight: 700; font-size: 0.85rem; }
    }
  }
  .footer {
    padding: 0 25px 25px;
    display: flex;
    gap: 10px;
    button { flex: 1; }
  }
`,f3=C.div`
  display: flex;
  overflow-x: auto;
  gap: 20px;
  padding: 10px 0 30px;
  scrollbar-width: none;
  &::-webkit-scrollbar { display: none; }
  
  & > * {
    flex: 0 0 240px;
  }

  @media (max-width: 768px) {
    & > * {
      flex: 0 0 200px;
    }
  }
`,Ni=C(Ze)`
  background: #ffffff;
  border-radius: 24px;
  padding: 35px 20px;
  text-align: center;
  text-decoration: none;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.03);
  border: 1px solid rgba(0,0,0,0.05);
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 200px;

  &:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(11, 26, 51, 0.1);
    border-color: #C9A84C;

    .icon-wrapper {
      background: #0b1a33;
      color: #C9A84C;
      transform: scale(1.1);
    }
  }

  .icon-wrapper {
    width: 70px;
    height: 70px;
    background: #f8fafc;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 20px;
    color: #0b1a33;
    transition: all 0.3s ease;
    
    svg {
      width: 32px;
      height: 32px;
      stroke-width: 1.5px;
    }
  }

  span {
    font-size: 1rem;
    font-weight: 800;
    color: #0b1a33;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
`,h3=C.div`
  background: #0b1a33;
  color: #C9A84C;
  text-align: center;
  padding: 14px 20px;
  font-size: 0.9rem;
  font-weight: 700;
  letter-spacing: 0.5px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;

  svg { width: 18px; height: 18px; flex-shrink: 0; }
`,p3=C.div`
  background: #f8fafc;
  padding: 80px 20px;

  .section-header {
    max-width: 1400px;
    margin: 0 auto 60px;

    .quote-icon { color: #C9A84C; margin-bottom: 15px; }

    h2 {
      font-size: 2.8rem;
      font-weight: 900;
      color: #0b1a33;
      line-height: 1.2;
      margin: 0;
      span { display: block; }
    }
  }

  .carousel-wrapper {
    max-width: 1400px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 50px 1fr 50px;
    align-items: center;
    gap: 20px;

    @media (max-width: 768px) {
      grid-template-columns: 40px 1fr 40px;
      gap: 10px;
    }
  }

  .nav-btn {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    border: 2px solid #C9A84C;
    background: white;
    color: #0b1a33;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    flex-shrink: 0;
    &:hover { background: #0b1a33; color: #C9A84C; border-color: #0b1a33; }
  }

  .cards {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 24px;
    @media (max-width: 1024px) { grid-template-columns: 1fr; }
  }

  .dots {
    display: flex;
    justify-content: center;
    gap: 8px;
    margin-top: 40px;
    span {
      width: 10px; height: 10px;
      border-radius: 50%;
      background: #ddd;
      cursor: pointer;
      transition: all 0.3s;
      &.active { background: #C9A84C; width: 28px; border-radius: 5px; }
    }
  }
`,m3=C.div`
  background: white;
  border-radius: 24px;
  padding: 35px 30px;
  border: 1px solid rgba(0,0,0,0.05);
  box-shadow: 0 10px 30px rgba(0,0,0,0.04);
  transition: all 0.4s ease;
  position: relative;

  &.featured {
    border: 2px solid #C9A84C;
    transform: scale(1.02);
    box-shadow: 0 20px 50px rgba(11,26,51,0.1);
  }

  .quote { color: #C9A84C; margin-bottom: 20px; }

  p {
    font-size: 0.98rem;
    line-height: 1.7;
    color: #555;
    margin-bottom: 30px;
    font-style: italic;
  }

  .author {
    display: flex;
    align-items: center;
    gap: 14px;

    .avatar {
      width: 48px; height: 48px;
      border-radius: 50%;
      background: linear-gradient(135deg, #0b1a33, #C9A84C);
      display: flex; align-items: center; justify-content: center;
      color: white; font-weight: 900; font-size: 1.2rem;
      flex-shrink: 0;
    }

    .info {
      .name { font-weight: 800; color: #0b1a33; font-size: 1rem; }
      .loc { font-size: 0.82rem; color: #C9A84C; font-weight: 700; }
    }
  }
`,g3=C.div`
  background: white;
  padding: 80px 20px;

  .faq-inner {
    max-width: 1100px;
    margin: 0 auto;
  }

  .faq-header {
    text-align: center;
    margin-bottom: 60px;

    h2 {
      font-size: 2.8rem;
      font-weight: 900;
      color: #0b1a33;
      margin-bottom: 10px;
      span {
        display: block;
        width: 60px;
        height: 4px;
        background: #C9A84C;
        margin: 12px auto 0;
        border-radius: 2px;
      }
    }
    p { color: #888; font-size: 1rem; }
  }
`,x3=C.div`
  border: 1px solid #e8ecf0;
  border-radius: 16px;
  margin-bottom: 14px;
  overflow: hidden;
  transition: all 0.3s ease;

  &.open { border-color: #C9A84C; box-shadow: 0 8px 24px rgba(201,168,76,0.1); }

  .faq-q {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 22px 28px;
    cursor: pointer;
    background: white;
    transition: background 0.3s;

    &:hover { background: #fffdf5; }

    .q-left {
      display: flex;
      align-items: center;
      gap: 14px;

      .bar {
        width: 4px;
        height: 36px;
        border-radius: 2px;
        background: ${i=>i.open?"#C9A84C":"#e8ecf0"};
        transition: background 0.3s;
        flex-shrink: 0;
      }

      span {
        font-size: 1rem;
        font-weight: 700;
        color: #0b1a33;
      }
    }

    svg {
      color: #C9A84C;
      transition: transform 0.3s;
      transform: ${i=>i.open?"rotate(180deg)":"rotate(0deg)"};
      flex-shrink: 0;
    }
  }

  .faq-a {
    padding: ${i=>i.open?"0 28px 24px 46px":"0 28px 0 46px"};
    max-height: ${i=>i.open?"300px":"0"};
    overflow: hidden;
    transition: all 0.35s ease;
    font-size: 0.97rem;
    line-height: 1.75;
    color: #555;
  }
`;C.div`
  padding: 80px 20px;
  text-align: center;
  background: white;
  
  h2 {
    font-size: 2rem;
    color: #0b1a33;
    font-weight: 800;
    margin-bottom: 10px;
    text-transform: uppercase;
    position: relative;
    display: inline-block;
    
    &::after {
      display: none;
    }
  }
  
  .subtitle {
    color: #666;
    margin-bottom: 50px;
    font-size: 1.1rem;
  }
  
  .badges {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 40px;
    flex-wrap: wrap;
    max-width: 1400px;
    margin: 0 auto;
    
    .badge-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 10px;
      transition: transform 0.3s ease;
      &:hover { transform: scale(1.1); }
      
      img {
        height: 80px;
        width: auto;
        filter: grayscale(0.2);
        &:hover { filter: grayscale(0); }
      }
      
      .circle-r {
        width: 60px;
        height: 60px;
        border: 2px solid #333;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2rem;
        font-weight: 800;
        color: #333;
      }
    }
  }
`;const y3=C.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 30px;
  max-width: 1400px;
  margin: 50px auto;
  padding: 0 20px;
`,b3=C.div`
  background: white;
  border-radius: 30px;
  padding: 40px;
  border: 1px solid #eee;
  text-align: center;
  transition: all 0.4s ease;
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;

  &:hover {
    transform: translateY(-15px);
    box-shadow: 0 25px 50px rgba(0,0,0,0.1);
    border-color: #C9A84C;
  }

  &.featured {
    border-color: #C9A84C;
    &::before {
      content: 'MOST POPULAR';
      position: absolute;
      top: 20px;
      right: -35px;
      background: #C9A84C;
      color: #0b1a33;
      padding: 5px 40px;
      font-size: 0.7rem;
      font-weight: 800;
      transform: rotate(45deg);
    }
  }

  .tier {
    font-size: 0.8rem;
    font-weight: 800;
    text-transform: uppercase;
    color: #C9A84C;
    margin-bottom: 10px;
    letter-spacing: 2px;
  }

  h3 {
    font-size: 1.5rem;
    color: #0b1a33;
    margin-bottom: 10px;
    font-weight: 900;
  }

  .price {
    font-size: 2.5rem;
    font-weight: 900;
    color: #0b1a33;
    margin-bottom: 20px;
    span { font-size: 0.9rem; color: #999; font-weight: 500; }
  }

  .validity {
    background: #f8f9fa;
    padding: 5px 15px;
    border-radius: 100px;
    font-size: 0.8rem;
    font-weight: 700;
    color: #666;
    margin: 0 auto 30px;
    display: inline-block;
  }

  .features {
    list-style: none;
    padding: 0;
    margin: 0 0 30px;
    flex-grow: 1;
    text-align: left;
    li {
      padding: 10px 0;
      color: #555;
      font-size: 0.95rem;
      border-bottom: 1px solid #f8f9fa;
      display: flex;
      align-items: center;
      gap: 12px;
      svg { color: #C9A84C; flex-shrink: 0; }
      &:last-child { border-bottom: none; }
    }
  }
`,v3=C.div`
  display: flex;
  justify-content: center;
  gap: 15px;
  margin-bottom: 40px;
  flex-wrap: wrap;
`,j3=C.button`
  padding: 12px 30px;
  border-radius: 50px;
  border: 2px solid ${i=>i.active?"#C9A84C":"#eee"};
  background: ${i=>i.active?"white":"#f8f9fa"};
  color: ${i=>i.active?"#C9A84C":"#666"};
  font-weight: 700;
  cursor: pointer;
  transition: all 0.3s ease;
  min-width: 150px;
  
  &:hover {
    border-color: #C9A84C;
    color: #C9A84C;
    background: white;
  }
`;C.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 20px;
  max-width: 1400px;
  margin: 0 auto;
`;C.div`
  background: white;
  padding: 30px 20px;
  border-radius: 20px;
  border: 1px solid #eee;
  text-align: center;
  transition: all 0.3s ease;
  &:hover {
    border-color: #C9A84C;
    background: #0b1a33;
    h4 { color: #C9A84C; }
    .icon { color: white; transform: rotateY(360deg); }
  }
  .icon { font-size: 2.0rem; color: #C9A84C; margin-bottom: 15px; transition: all 0.6s ease; stroke-width: 1.5; }
  h4 { font-size: 0.85rem; font-weight: 800; text-transform: uppercase; color: #0b1a33; }
`;const S3=C.div`
  max-width: 1200px;
  margin: 0 auto;
  text-align: left;
  h2 { font-size: 2.5rem; color: #0b1a33; font-weight: 900; margin-bottom: 30px; text-align: left; }
  p { font-size: 1.1rem; line-height: 1.8; color: #555; margin-bottom: 40px; }
  .stats {
    display: flex;
    justify-content: space-between;
    gap: 30px;
    flex-wrap: wrap;
    text-align: center;
    margin-top: 50px;
    padding-top: 40px;
    border-top: 1px solid #eee;
    .stat-item {
      h3 { font-size: 2.5rem; color: #C9A84C; font-weight: 900; }
      span { font-size: 0.9rem; text-transform: uppercase; font-weight: 700; color: #0b1a33; }
    }
  }
`;C.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin: 40px 0;
  text-align: left;

  @media (max-width: 1200px) {
    grid-template-columns: repeat(2, 1fr);
  }
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;C.div`
  background: white;
  padding: 20px;
  border-radius: 15px;
  border-left: 4px solid #C9A84C;
  box-shadow: 0 5px 15px rgba(0,0,0,0.05);
  h4 {
    color: #C9A84C;
    font-size: 1.1rem;
    font-weight: 800;
    margin-bottom: 5px;
  }
  p {
    font-size: 0.9rem !important;
    line-height: 1.4 !important;
    margin-bottom: 0 !important;
    color: #666 !important;
  }
`;const w3=()=>{const{language:i}=as(),s=ns[i],u=G=>{const K=(G||"").toLowerCase();return K.includes("child")||K.includes("kid")?l.jsx(y2,{size:34,strokeWidth:1.5}):K.includes("pet")||K.includes("dog")?l.jsx(L2,{size:34,strokeWidth:1.5}):K.includes("travel")||K.includes("luggage")?l.jsx(pm,{size:34,strokeWidth:1.5}):K.includes("gadget")||K.includes("phone")||K.includes("laptop")?l.jsx(ts,{size:34,strokeWidth:1.5}):K.includes("corporate")||K.includes("office")?l.jsx(pm,{size:34,strokeWidth:1.5}):K.includes("medical")||K.includes("emergency")?l.jsx(Xl,{size:34,strokeWidth:1.5}):K.includes("vehicle")||K.includes("parking")||K.includes("bike")?l.jsx(Jl,{size:34,strokeWidth:1.5}):K.includes("home")||K.includes("door")?l.jsx(Y2,{size:34,strokeWidth:1.5}):K.includes("qr")?l.jsx(ud,{size:34,strokeWidth:1.5}):K.includes("family")?l.jsx(Rd,{size:34,strokeWidth:1.5}):l.jsx(Xt,{size:34,strokeWidth:1.5})},[c,f]=A.useState(0),[p,h]=A.useState(null),[v,x]=A.useState([]),[g,b]=A.useState([]),[y,k]=A.useState([]),[D,_]=A.useState("LITE"),[q,Y]=A.useState([]),[U,Q]=A.useState(!0),[Z,V]=A.useState(""),te=A.useRef(null),ee=A.useRef(null),$=(G,K)=>{if(G.current){const ze=K==="left"?-300:300;G.current.scrollBy({left:ze,behavior:"smooth"})}},J=gn(),{addToCart:he}=tr(),Oe=(G,K)=>{if(G.preventDefault(),G.stopPropagation(),!localStorage.getItem("admin_token")){na.error("Please login to add items to your cart.",{icon:"🔒",style:{borderRadius:"100px",background:"#0b1a33",color:"#fff"}}),J(`/login?returnUrl=${encodeURIComponent(window.location.pathname)}`);return}he(K),na.success(`${K.name} added to cart!`,{icon:"🛒",style:{borderRadius:"100px",background:"#0b1a33",color:"#fff"}})};return A.useEffect(()=>{V(window.location.hostname==="localhost"?"http://localhost:5001":""),(async()=>{try{const K=await Promise.allSettled([ta.get("/categories"),ta.get("/products?type=SAFETY"),ta.get("/public/settings"),ta.get("/plans")]);if(K[0].status==="fulfilled"){const Me=(K[0].value.data?.categories||[]).filter(be=>be.name!=="Smart Home");x(Me)}if(K[1].status==="fulfilled"&&b(K[1].value.data?.products||[]),K[2].status==="fulfilled")try{const ze=JSON.parse(K[2].value.data?.settings?.homeSecurityFeatures||"[]");ze.length>0&&Y(ze)}catch{}K[3].status==="fulfilled"&&k(K[3].value.data?.plans||[])}catch(K){console.error("Failed to fetch home data:",K)}finally{Q(!1)}})()},[]),l.jsxs(l.Fragment,{children:[l.jsx(n3,{children:l.jsxs(i3,{children:[l.jsxs("div",{children:[l.jsxs(l3,{children:[l.jsx("span",{className:"dim",children:s.hero.taglineDim}),l.jsx("span",{className:"highlight",children:s.hero.taglineHighlight})]}),l.jsx(r3,{children:s.hero.subtext}),l.jsxs("div",{style:{display:"flex",gap:"15px"},children:[l.jsx(wo,{to:"/smart-qr",children:s.hero.getStarted}),l.jsx(wo,{to:"/watch-demo",variant:"outline",children:s.hero.watchDemo})]})]}),l.jsx(o3,{children:l.jsx("img",{src:"https://img.icons8.com/fluency/800/shield.png",alt:"Tarkshya Smart Tag",style:{background:"rgba(255,255,255,0.05)",padding:"40px"}})})]})}),l.jsxs(Qe,{bg:"light",children:[l.jsxs(Co,{children:[l.jsxs("h2",{children:[s.sections.categories.title," ",l.jsx("span",{children:s.sections.categories.highlight})]}),l.jsx("p",{children:s.sections.categories.subtext}),l.jsx("div",{className:"line"})]}),l.jsxs(jm,{children:[l.jsx(Ao,{className:"left",onClick:()=>$(te,"left"),children:l.jsx(Ln,{})}),l.jsxs(s3,{ref:te,children:[v.map(G=>l.jsxs(c3,{to:`/category/${G.id}`,children:[l.jsx("div",{className:"icon-box",children:u(G.name)}),l.jsx("h3",{children:G.name})]},G.id)),v.length===0&&!U&&l.jsx("p",{style:{textAlign:"center",gridColumn:"1/-1",color:"#999",padding:"40px"},children:"No categories found. Manage them in Admin Panel."})]}),l.jsx(Ao,{className:"right",onClick:()=>$(te,"right"),children:l.jsx(hn,{})})]})]}),l.jsxs(Qe,{bg:"white",children:[l.jsxs(Co,{children:[l.jsxs("h2",{children:[s.sections.safetyIds.title," ",l.jsx("span",{children:s.sections.safetyIds.highlight})]}),l.jsx("p",{children:s.sections.safetyIds.subtext}),l.jsx("div",{className:"line"})]}),l.jsx(u3,{children:g.map(G=>{const K=typeof G.photos=="string"?JSON.parse(G.photos||"[]"):G.photos||[],Me=(typeof G.dynamicData=="string"?JSON.parse(G.dynamicData||"[]"):G.dynamicData||[]).slice(0,4);let be=K[0]?K[0].startsWith("http")?K[0]:`${Z}${K[0]}`:"https://img.icons8.com/fluency/400/security-checked.png";return be.includes("images.icons8.com")&&(be=be.replace("images.icons8.com","img.icons8.com").replace("/bubbles/","/fluency/")),l.jsxs(d3,{children:[G.isCounterfeit&&l.jsx("div",{className:"badge",style:{background:"#e74c3c"},children:"RECALLED"}),l.jsx(Ze,{to:`/product/${G.id}`,className:"img-box",children:l.jsx("img",{src:be,alt:G.name})}),l.jsxs("div",{className:"content",children:[l.jsx("h3",{children:G.name}),l.jsxs("div",{className:"features",children:[Me.map((M,X)=>l.jsx("span",{children:M.label.toUpperCase()},X)),Me.length===0&&l.jsxs(l.Fragment,{children:[l.jsx("span",{children:"SMART QR"}),l.jsx("span",{children:"PRIVACY"})]})]}),l.jsxs("div",{className:"price-row",children:[l.jsxs("div",{className:"price",children:["₹",G.mrp||0," ",l.jsxs("span",{children:["₹",Math.round((G.mrp||0)*1.5)]})]}),l.jsx("div",{className:"discount",children:"33% OFF"})]})]}),l.jsxs("div",{className:"footer",children:[l.jsx(wo,{to:`/product/${G.id}`,style:{padding:"10px 15px"},children:"VIEW DETAILS"}),l.jsx(qe,{variant:"secondary",style:{padding:"10px 15px"},onClick:M=>Oe(M,G),children:l.jsx(er,{size:18})})]})]},G.id)})})]}),l.jsxs(Qe,{bg:"light",children:[l.jsxs(Co,{children:[l.jsxs("h2",{children:[s.sections.services.title," ",l.jsx("span",{children:s.sections.services.highlight})]}),l.jsx("p",{children:s.sections.services.subtext}),l.jsx("div",{className:"line"})]}),l.jsxs(jm,{children:[l.jsx(Ao,{className:"left",onClick:()=>$(ee,"left"),children:l.jsx(Ln,{})}),l.jsxs(f3,{ref:ee,children:[l.jsxs(Ni,{to:"/service/instant-call-masking",children:[l.jsx("div",{className:"icon-wrapper",children:l.jsx(Eg,{size:34,strokeWidth:1.5})}),l.jsx("span",{children:"Call Masking"})]}),l.jsxs(Ni,{to:"/service/qr-security",children:[l.jsx("div",{className:"icon-wrapper",children:l.jsx(ud,{size:34,strokeWidth:1.5})}),l.jsx("span",{children:"QR Security"})]}),l.jsxs(Ni,{to:"/service/emergency-helplines",children:[l.jsx("div",{className:"icon-wrapper",children:l.jsx(zg,{size:34,strokeWidth:1.5})}),l.jsx("span",{children:"Helplines"})]}),l.jsxs(Ni,{to:"/service/data-privacy",children:[l.jsx("div",{className:"icon-wrapper",children:l.jsx(Zt,{size:34,strokeWidth:1.5})}),l.jsx("span",{children:"Data Privacy"})]}),l.jsxs(Ni,{to:"/service/verified",children:[l.jsx("div",{className:"icon-wrapper",children:l.jsx(v2,{size:34,strokeWidth:1.5})}),l.jsx("span",{children:"Verified Identity"})]}),l.jsxs(Ni,{to:"/service/instant-alerts",children:[l.jsx("div",{className:"icon-wrapper",children:l.jsx(_d,{size:34,strokeWidth:1.5})}),l.jsx("span",{children:"Instant Alerts"})]})]}),l.jsx(Ao,{className:"right",onClick:()=>$(ee,"right"),children:l.jsx(hn,{})})]})]}),l.jsxs(Qe,{bg:"white",children:[l.jsxs(Co,{children:[l.jsxs("h2",{children:[s.sections.features.title," ",l.jsx("span",{children:s.sections.features.highlight})]}),l.jsx("p",{children:s.sections.features.subtext}),l.jsx("div",{className:"line"})]}),l.jsxs(y3,{children:[l.jsx(v3,{style:{gridColumn:"1/-1",marginBottom:"40px"},children:["LITE","PRO","ELITE"].map(G=>l.jsx(j3,{active:D===G,onClick:()=>_(G),children:G},G))}),y.filter(G=>(G.tier||"").toUpperCase()===D).map(G=>l.jsxs(b3,{className:G.tier?.toUpperCase()==="PRO"?"featured":"",children:[l.jsx("div",{className:"tier",children:G.tier}),l.jsx("h3",{children:G.displayName}),l.jsxs("div",{className:"price",children:["₹",G.price," ",l.jsx("span",{children:"/ year"})]}),l.jsxs("div",{className:"validity",children:[G.validityDays," Days Validity"]}),l.jsx("ul",{className:"features",children:G.features.map((K,ze)=>{let Me=K;const be=K.toLowerCase();return be.includes("scan")&&!be.includes("basic")?Me="Basic QR Scan":be.includes("call")||be.includes("connect")?Me="Direct Owner Connect":be.includes("whatsapp")||be.includes("alert")?Me="Instant WhatsApp Alert":be.includes("masking")||be.includes("privacy")?Me="Privacy Call Masking":be.includes("location")||be.includes("gps")?Me="Live Location Sharing":Me=K.split(" ").map(M=>M.charAt(0).toUpperCase()+M.slice(1)).join(" "),l.jsxs("li",{children:[l.jsx(jg,{size:18}),Me]},ze)})}),l.jsx(wo,{to:"/smart-qr",children:"GET STARTED"})]},G.id)),y.filter(G=>(G.tier||"").toUpperCase()===D).length===0&&l.jsx("p",{style:{gridColumn:"1/-1",textAlign:"center",color:"#999",padding:"40px"},children:"No plans available for this category yet."})]})]}),l.jsxs(p3,{children:[l.jsxs("div",{className:"section-header",children:[l.jsx(gm,{size:42,className:"quote-icon"}),l.jsxs("h2",{children:[l.jsx("span",{children:"What our"}),"Customers Say"]})]}),l.jsxs("div",{className:"carousel-wrapper",children:[l.jsx("button",{className:"nav-btn",onClick:()=>f(G=>(G-1+3)%3),children:l.jsx(Ln,{size:20})}),l.jsx("div",{className:"cards",children:[{name:"Swati Singh",loc:"Bihar",featured:!1,text:'"V-KAWACH के Pet Safety QR की वजह से मेरा खोया हुआ कुत्ता वापस मिला। किसी ने QR scan किया और सीधे मुझसे connect किया — बिल्कुल stress-free!"'},{name:"Rajat Patel",loc:"Gujarat",featured:!0,text:'"V-KAWACH Smart QR Tag ने हमारी गाड़ी की सुरक्षा को बढ़ा दिया है। Emergency में कोई भी QR scan करके instantly हमसे connect कर सकता है।"'},{name:"Surya Prakash",loc:"Jaipur",featured:!1,text:'"भीड़ वाले मार्केट में गाड़ी में आग लग गई — Police ने V-KAWACH QR scan करके तुरंत मुझसे contact किया। इस tag ने बड़ा नुकसान बचाया।"'}].map((G,K)=>l.jsxs(m3,{className:G.featured?"featured":"",children:[l.jsx(gm,{size:28,className:"quote"}),l.jsx("p",{children:G.text}),l.jsxs("div",{className:"author",children:[l.jsx("div",{className:"avatar",children:G.name[0]}),l.jsxs("div",{className:"info",children:[l.jsx("div",{className:"name",children:G.name}),l.jsx("div",{className:"loc",children:G.loc})]})]})]},K))}),l.jsx("button",{className:"nav-btn",onClick:()=>f(G=>(G+1)%3),children:l.jsx(hn,{size:20})})]}),l.jsx("div",{className:"dots",children:[0,1,2].map(G=>l.jsx("span",{className:c===G?"active":"",onClick:()=>f(G)},G))})]}),l.jsx(g3,{children:l.jsxs("div",{className:"faq-inner",children:[l.jsxs("div",{className:"faq-header",children:[l.jsxs("h2",{children:["Frequently Asked Questions",l.jsx("span",{})]}),l.jsx("p",{children:"V-KAWACH के बारे में सामान्य प्रश्नों के उत्तर पाएं"})]}),[{q:"1. V-KAWACH Safety QR क्या है?",a:"V-KAWACH Safety QR एक अगली पीढ़ी की डिजिटल सुरक्षा प्रणाली है जिसमें एक QR Tag आपके वाहन, लैपटॉप, बच्चे या पालतू जानवर पर लगाया जाता है। Emergency में कोई भी इसे scan करके आपसे तुरंत और anonymously connect कर सकता है।"},{q:"2. V-KAWACH QR कैसे काम करता है?",a:"QR scan होने पर एक secure page खुलता है जहाँ scanner अपना नंबर enter करता है। V-KAWACH का call masking system दोनों के नंबर छुपाकर एक safe call connect करता है — आपकी privacy 100% सुरक्षित रहती है।"},{q:"3. क्या बिना internet के QR scan होगा?",a:"QR scan के लिए scanner के फोन पर internet होना जरूरी है। लेकिन Emergency call का option हमेशा available रहता है जो बिना internet के भी काम करता है।"},{q:"4. क्या मेरा personal number safe है?",a:"बिल्कुल! V-KAWACH में आपका नंबर कभी किसी को दिखता नहीं है। हमारी Privacy-First Call Masking Technology दोनों parties के नंबर को पूरी तरह छुपा देती है।"},{q:"5. V-KAWACH QR कहाँ-कहाँ use हो सकता है?",a:"गाड़ी (कार/बाइक), लैपटॉप, बच्चों का बैग, पालतू जानवर का collar, luggage, medical emergency card, corporate ID badge — कहीं भी जहाँ emergency में contact की ज़रूरत हो।"}].map((G,K)=>l.jsxs(x3,{open:p===K,children:[l.jsxs("div",{className:"faq-q",onClick:()=>h(p===K?null:K),children:[l.jsxs("div",{className:"q-left",children:[l.jsx("div",{className:"bar"}),l.jsx("span",{children:G.q})]}),l.jsx(A2,{size:20})]}),l.jsx("div",{className:"faq-a",children:G.a})]},K))]})}),l.jsx(Qe,{bg:"light",children:l.jsxs(S3,{children:[l.jsxs("h2",{children:[s.about.title," ",l.jsx("span",{children:s.about.highlight})]}),l.jsx("div",{dangerouslySetInnerHTML:{__html:s.about.content}}),l.jsxs("div",{className:"stats",children:[l.jsxs("div",{className:"stat-item",children:[l.jsx("h3",{children:"100%"}),l.jsx("span",{children:s.about.stats.scansProtected})]}),l.jsxs("div",{className:"stat-item",children:[l.jsx("h3",{children:"24/7"}),l.jsx("span",{children:s.about.stats.monitoring})]})]})]})}),l.jsxs(h3,{children:[l.jsx(Ng,{})," V-Kawach Safety QR आपकी सुरक्षा के लिए है, इससे किसी भी प्रकार का payment नहीं किया जा सकता है।"]})]})},C3=C.div`
  background-color: ${({theme:i})=>i.colors.navy};
  color: ${({theme:i})=>i.colors.white};
  padding: 120px 0 80px;
  text-align: center;
`,A3=C.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 0 20px;
`,z3=C.h1`
  font-size: 3rem;
  margin-bottom: 20px;
  color: ${({theme:i})=>i.colors.gold};
`,E3=C.p`
  font-size: 1.2rem;
  opacity: 0.9;
  margin-bottom: 40px;
`,T3=C.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 40px;
  margin-top: 60px;
  
  @media (min-width: ${({theme:i})=>i.breakpoints.tablet}) {
    grid-template-columns: repeat(3, 1fr);
  }
`,Uu=C.div`
  text-align: center;
  padding: 30px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 5px 15px rgba(0,0,0,0.05);
  
  .icon {
    width: 60px;
    height: 60px;
    background: ${({theme:i})=>i.colors.navy};
    color: ${({theme:i})=>i.colors.gold};
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
  }
`,N3=C.ul`
  list-style: none;
  max-width: 600px;
  margin: 40px auto;
  text-align: left;
`,Yl=C.li`
  display: flex;
  align-items: center;
  gap: 15px;
  margin-bottom: 15px;
  font-size: 1.1rem;
  
  svg {
    color: ${({theme:i})=>i.colors.gold};
  }
`,k3=()=>l.jsxs(l.Fragment,{children:[l.jsx(C3,{children:l.jsxs(A3,{children:[l.jsx(z3,{children:"Smart QR Identity"}),l.jsx(E3,{children:"Protect what matters with our advanced QR technology. Vehicles, pets, and loved ones — secured with instant connectivity and privacy."}),l.jsx(qe,{as:"a",href:"https://wa.me/918881384777?text=Hi%20Tarkshya%2C%20I%20would%20like%20to%20order%20a%20Smart%20QR%20Identity%20Tag.%20Please%20provide%20details.",target:"_blank",rel:"noopener noreferrer",children:"Get Your Smart ID"})]})}),l.jsxs(Qe,{children:[l.jsx("h2",{style:{textAlign:"center",marginBottom:"40px"},children:"How It Works"}),l.jsxs(T3,{children:[l.jsxs(Uu,{children:[l.jsx("div",{className:"icon",children:l.jsx(ts,{size:32})}),l.jsx("h3",{children:"Scan"}),l.jsx("p",{children:"Anyone who finds your lost item or vehicle scans the QR code using any smartphone camera."})]}),l.jsxs(Uu,{children:[l.jsx("div",{className:"icon",children:l.jsx(Xt,{size:32})}),l.jsx("h3",{children:"Connect"}),l.jsx("p",{children:"They are instantly redirected to a secure page to contact the owner."})]}),l.jsxs(Uu,{children:[l.jsx("div",{className:"icon",children:l.jsx(Eg,{size:32})}),l.jsx("h3",{children:"Call Owner"}),l.jsx("p",{children:"They can call you immediately. Your number stays private via our call masking technology."})]})]})]}),l.jsxs(Qe,{bg:"light",children:[l.jsx("h2",{style:{textAlign:"center"},children:"Key Features"}),l.jsxs(N3,{children:[l.jsxs(Yl,{children:[l.jsx(Xt,{size:20})," Call Masking (Privacy Protection)"]}),l.jsxs(Yl,{children:[l.jsx(Xt,{size:20})," Instant SMS & WhatsApp Alerts"]}),l.jsxs(Yl,{children:[l.jsx(Xt,{size:20})," Emergency Contact Integration"]}),l.jsxs(Yl,{children:[l.jsx(Xt,{size:20})," No App Required for Finder"]}),l.jsxs(Yl,{children:[l.jsx(Xt,{size:20})," Weatherproof & Durable Tags"]})]}),l.jsx("div",{style:{textAlign:"center"},children:l.jsx(qe,{as:"a",href:"https://wa.me/918881384777?text=Hi%20Tarkshya%2C%20I%20would%20like%20to%20order%20a%20Smart%20QR%20Tag.%20Please%20provide%20details.",target:"_blank",rel:"noopener noreferrer",children:"Order Now"})})]})]}),R3=C.div`
  background: white;
  padding: 40px;
  border-radius: 8px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.05);
  max-width: 500px;
  margin: 0 auto;
  border: 1px solid ${({theme:i})=>i.colors.border};
`,_3=C.h3`
  margin-bottom: 20px;
  text-align: center;
  color: ${({theme:i})=>i.colors.navy};
`,Bu=C.div`
  margin-bottom: 20px;
`,Lu=C.label`
  display: block;
  margin-bottom: 8px;
  font-weight: 500;
  color: ${({theme:i})=>i.colors.text};
`,qu=C.input`
  width: 100%;
  padding: 12px;
  border: 1px solid ${({theme:i})=>i.colors.border};
  border-radius: 4px;
  font-family: ${({theme:i})=>i.fonts.body};
  
  &:focus {
    outline: none;
    border-color: ${({theme:i})=>i.colors.gold};
    box-shadow: 0 0 0 2px rgba(201, 168, 76, 0.2);
  }
`,Lg=({serviceName:i})=>{const[s,u]=A.useState({name:"",phone:"",city:""}),c=p=>{p.preventDefault();const h=`Hi, I am interested in ${i}.

My details are:
Name: ${s.name}
Phone: ${s.phone}
City: ${s.city}`,v=`https://wa.me/918881384777?text=${encodeURIComponent(h)}`;window.open(v,"_blank")},f=p=>{u({...s,[p.target.name]:p.target.value})};return l.jsxs(R3,{children:[l.jsxs(_3,{children:["Get a Quote for ",i]}),l.jsxs("form",{onSubmit:c,children:[l.jsxs(Bu,{children:[l.jsx(Lu,{children:"Name"}),l.jsx(qu,{type:"text",name:"name",required:!0,placeholder:"Your Name",value:s.name,onChange:f})]}),l.jsxs(Bu,{children:[l.jsx(Lu,{children:"Phone Number"}),l.jsx(qu,{type:"tel",name:"phone",required:!0,placeholder:"Your Phone Number",value:s.phone,onChange:f})]}),l.jsxs(Bu,{children:[l.jsx(Lu,{children:"City"}),l.jsx(qu,{type:"text",name:"city",required:!0,placeholder:"Your City",value:s.city,onChange:f})]}),l.jsx(qe,{type:"submit",style:{width:"100%"},children:"Request Quote"})]})]})},M3=C.header`
  background: ${({theme:i})=>i.colors.navy};
  color: white;
  padding: 100px 0 60px;
  text-align: center;
`,D3=C.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
  display: grid;
  grid-template-columns: 1fr;
  gap: 60px;
  
  @media (min-width: ${({theme:i})=>i.breakpoints.tablet}) {
    grid-template-columns: 1fr 1fr;
    align-items: center;
  }
`,O3=C.div`
  h2 {
    font-size: 2.5rem;
    margin-bottom: 20px;
    color: ${({theme:i})=>i.colors.navy};
  }
  
  p {
    font-size: 1.1rem;
    margin-bottom: 20px;
    opacity: 0.8;
  }
`,H3=C.span`
  background: ${({theme:i})=>i.colors.gold};
  color: ${({theme:i})=>i.colors.navy};
  padding: 5px 15px;
  border-radius: 20px;
  font-weight: 700;
  font-size: 0.9rem;
  display: inline-block;
  margin-bottom: 20px;
`,U3=()=>l.jsxs(l.Fragment,{children:[l.jsxs(M3,{children:[l.jsx("h1",{children:"Live Cloud Monitoring"}),l.jsx("p",{children:"Secure CCTV Backup & Anti-Theft Protection"})]}),l.jsx(Qe,{children:l.jsxs(D3,{children:[l.jsxs(O3,{children:[l.jsx(H3,{children:"COMING SOON"}),l.jsx("h2",{children:"Secure Your Premises with Cloud Intelligence"}),l.jsx("p",{children:"Traditional CCTV systems are vulnerable to theft and damage. Our cloud monitoring solution ensures your footage is safe, even if the camera is destroyed."}),l.jsxs("p",{children:[l.jsx("strong",{children:"Features:"}),l.jsxs("ul",{style:{paddingLeft:"20px",marginTop:"10px"},children:[l.jsx("li",{children:"Real-time Cloud Backup"}),l.jsx("li",{children:"Motion Detection Alerts"}),l.jsx("li",{children:"Anti-Theft Device Protection"}),l.jsx("li",{children:"Remote Access via Mobile"})]})]})]}),l.jsx(Lg,{serviceName:"Cloud Monitoring"})]})})]}),B3=C.header`
  background: ${({theme:i})=>i.colors.navy};
  color: white;
  padding: 100px 0 60px;
  text-align: center;
`,L3=C.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
  display: grid;
  grid-template-columns: 1fr;
  gap: 60px;
  
  @media (min-width: ${({theme:i})=>i.breakpoints.tablet}) {
    grid-template-columns: 1fr 1fr;
    align-items: center;
  }
`,q3=C.div`
  h2 {
    font-size: 2.5rem;
    margin-bottom: 20px;
    color: ${({theme:i})=>i.colors.navy};
  }
  
  p {
    font-size: 1.1rem;
    margin-bottom: 20px;
    opacity: 0.8;
  }
`,Y3=C.span`
  background: ${({theme:i})=>i.colors.gold};
  color: ${({theme:i})=>i.colors.navy};
  padding: 5px 15px;
  border-radius: 20px;
  font-weight: 700;
  font-size: 0.9rem;
  display: inline-block;
  margin-bottom: 20px;
`,$3=()=>l.jsxs(l.Fragment,{children:[l.jsxs(B3,{children:[l.jsx("h1",{children:"Advanced GPS Tracking"}),l.jsx("p",{children:"Real-time Location & Fleet Management"})]}),l.jsx(Qe,{children:l.jsxs(L3,{children:[l.jsxs(q3,{children:[l.jsx(Y3,{children:"COMING SOON"}),l.jsx("h2",{children:"Precision Tracking for Every Asset"}),l.jsx("p",{children:"Whether it's a fleet of trucks or a personal vehicle, stay connected with real-time location data."}),l.jsxs("p",{children:[l.jsx("strong",{children:"Features:"}),l.jsxs("ul",{style:{paddingLeft:"20px",marginTop:"10px"},children:[l.jsx("li",{children:"Live Location Tracking"}),l.jsx("li",{children:"Geofencing Alerts"}),l.jsx("li",{children:"Speed Monitoring"}),l.jsx("li",{children:"Route Playback"}),l.jsx("li",{children:"Fuel Usage Analytics"})]})]})]}),l.jsx(Lg,{serviceName:"GPS Tracking"})]})})]}),G3=C.div`
  background: ${({theme:i})=>i.colors.navy};
  color: white;
  padding: 120px 0 80px;
  text-align: center;
`,Sm=C.div`
  max-width: 800px;
  margin: 0 auto;
  text-align: center;
`,Q3=C.div`
  display: flex;
  justify-content: space-around;
  margin: 60px 0;
  flex-wrap: wrap;
  gap: 30px;
`,Yu=C.div`
  text-align: center;
  flex: 1;
  min-width: 200px;
  h3 {
    font-size: 2.5rem;
    color: ${({theme:i})=>i.colors.gold};
    margin-bottom: 5px;
  }
  p {
    color: ${({theme:i})=>i.colors.navy};
    font-weight: 700;
  }
`,V3=C.div`
  background: white;
  padding: 40px;
  border-radius: 15px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.1);
  margin-top: 60px;
  text-align: left;
  border-top: 5px solid ${({theme:i})=>i.colors.gold};

  h3 {
    margin-bottom: 25px;
    color: ${({theme:i})=>i.colors.navy};
    text-align: center;
  }
`,zo=C.div`
  margin-bottom: 20px;
`,Eo=C.label`
  display: block;
  margin-bottom: 8px;
  font-weight: 500;
`,$u=C.input`
  width: 100%;
  padding: 12px;
  border: 1px solid #eee;
  border-radius: 8px;
  background: #fdfdfd;
  &:focus {
    outline: none;
    border-color: ${({theme:i})=>i.colors.gold};
  }
`,X3=C.textarea`
  width: 100%;
  padding: 12px;
  border: 1px solid #eee;
  border-radius: 8px;
  background: #fdfdfd;
  min-height: 120px;
  &:focus {
    outline: none;
    border-color: ${({theme:i})=>i.colors.gold};
  }
`,K3=()=>{const[i,s]=A.useState({name:"",email:"",phone:"",message:"I want to join Mission Rakshak"}),[u,c]=A.useState(!1),[f,p]=A.useState(null),h=x=>{s({...i,[x.target.name]:x.target.value})},v=x=>{x.preventDefault(),c(!0);const g=`Hi, I want to join Mission Rakshak!

Name: ${i.name}
Email: ${i.email}
Phone: ${i.phone}
Message: ${i.message}`,b=`https://wa.me/918881384777?text=${encodeURIComponent(g)}`;window.open(b,"_blank"),c(!1),p({type:"success",message:"Redirecting to WhatsApp..."})};return l.jsxs(l.Fragment,{children:[l.jsx(G3,{children:l.jsxs(Sm,{children:[l.jsx("h1",{style:{fontSize:"3rem",color:"#C9A84C"},children:"Mission Rakshak"}),l.jsx("p",{style:{fontSize:"1.2rem",marginTop:"20px",opacity:.9},children:"Our commitment to safer roads and connected communities."})]})}),l.jsx(Qe,{children:l.jsxs(Sm,{children:[l.jsx("h2",{children:"The Story"}),l.jsx("p",{style:{fontSize:"1.1rem",marginTop:"20px",lineHeight:"1.8"},children:"Mission Rakshak was born from a simple realization: in an emergency, every second counts. Too often, accident victims or lost individuals cannot be helped simply because there is no way to contact their family."}),l.jsx("p",{style:{fontSize:"1.1rem",marginTop:"20px",lineHeight:"1.8"},children:"Through Mission Rakshak, we distribute subsidized Smart QR stickers to public transport, elderly citizens, and school children, creating a safety net that spans across the city."}),l.jsxs(Q3,{children:[l.jsxs(Yu,{children:[l.jsx(L5,{size:48,color:"#C9A84C",style:{margin:"0 auto 10px"}}),l.jsx("h3",{style:{fontSize:"1.5rem"},children:"Vision"}),l.jsx("p",{children:"Impact 10,000+ Lives"})]}),l.jsxs(Yu,{children:[l.jsx(Rd,{size:48,color:"#C9A84C",style:{margin:"0 auto 10px"}}),l.jsx("h3",{style:{fontSize:"1.2rem"},children:"Looking for"}),l.jsx("p",{children:"NGO Partners"})]}),l.jsxs(Yu,{children:[l.jsx(X2,{size:48,color:"#C9A84C",style:{margin:"0 auto 10px"}}),l.jsx("h3",{style:{fontSize:"1.2rem"},children:"Initiative"}),l.jsx("p",{children:"Our Social Initiative"})]})]}),l.jsxs(V3,{id:"join-form",children:[l.jsx("h3",{children:"Become a Rakshak"}),l.jsxs("form",{onSubmit:v,children:[l.jsxs(zo,{children:[l.jsx(Eo,{children:"Full Name"}),l.jsx($u,{type:"text",name:"name",required:!0,value:i.name,onChange:h,placeholder:"Enter your name"})]}),l.jsxs("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"20px"},children:[l.jsxs(zo,{children:[l.jsx(Eo,{children:"Email Address"}),l.jsx($u,{type:"email",name:"email",required:!0,value:i.email,onChange:h,placeholder:"email@example.com"})]}),l.jsxs(zo,{children:[l.jsx(Eo,{children:"Phone Number"}),l.jsx($u,{type:"tel",name:"phone",required:!0,value:i.phone,onChange:h,placeholder:"+91 00000 00000"})]})]}),l.jsxs(zo,{children:[l.jsx(Eo,{children:"Message"}),l.jsx(X3,{name:"message",value:i.message,onChange:h,placeholder:"How would you like to contribute?"})]}),l.jsxs(qe,{type:"submit",disabled:u,style:{width:"100%",padding:"15px"},children:[u?"Sending...":"Join the Mission"," ",l.jsx(E5,{size:18,style:{marginLeft:"10px"}})]}),f&&l.jsx("p",{style:{marginTop:"20px",padding:"10px",borderRadius:"5px",textAlign:"center",background:f.type==="success"?"#e6f7e6":"#fff0f0",color:f.type==="success"?"#2e7d32":"#d32f2f"},children:f.message})]})]})]})})]})},wm=St`
  0% { transform: translateY(0px); }
  50% { transform: translateY(-20px); }
  100% { transform: translateY(0px); }
`,Z3=C.div`
  min-height: 100vh;
  display: flex;
  background: #0b1a33;
  @media (max-width: 960px) {
    flex-direction: column;
  }
`,W3=C.div`
  flex: 1.2;
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 140px 10% 80px;
  background: linear-gradient(135deg, #0b1a33 0%, #112240 100%);
  border-right: 1px solid rgba(255,255,255,0.05);

  &::before, &::after {
    content: '';
    position: absolute;
    width: 600px;
    height: 600px;
    border-radius: 50%;
    filter: blur(120px);
    z-index: 0;
    opacity: 0.3;
  }
  &::before {
    background: radial-gradient(circle, rgba(201, 168, 76, 0.5) 0%, rgba(0,0,0,0) 70%);
    top: -200px;
    left: -200px;
    animation: ${wm} 10s ease-in-out infinite;
  }
  &::after {
    background: radial-gradient(circle, rgba(26, 58, 109, 0.8) 0%, rgba(0,0,0,0) 70%);
    bottom: -200px;
    right: -200px;
    animation: ${wm} 12s ease-in-out infinite reverse;
  }

  > * { position: relative; z-index: 1; }

  h1 {
    font-size: 3.8rem;
    font-weight: 900;
    color: white;
    line-height: 1.1;
    margin-bottom: 25px;
    letter-spacing: -1.5px;
    span { color: #C9A84C; }
  }

  p.subtitle {
    font-size: 1.2rem;
    color: rgba(255,255,255,0.7);
    margin-bottom: 60px;
    max-width: 90%;
    line-height: 1.6;
  }
`,J3=C.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  
  @media (max-width: 1200px) {
    grid-template-columns: 1fr;
  }

  .feature-item {
    display: flex;
    align-items: center;
    gap: 15px;
    background: rgba(255,255,255,0.02);
    padding: 20px;
    border-radius: 20px;
    border: 1px solid rgba(255,255,255,0.05);
    backdrop-filter: blur(10px);
    transition: all 0.3s ease;

    &:hover {
      background: rgba(255,255,255,0.05);
      transform: translateY(-5px);
      border-color: rgba(201, 168, 76, 0.3);
    }

    .icon {
      background: rgba(201, 168, 76, 0.1);
      color: #C9A84C;
      padding: 12px;
      border-radius: 14px;
    }

    .text {
      h4 { color: white; font-size: 1.05rem; font-weight: 700; margin-bottom: 4px; }
      p { color: rgba(255,255,255,0.5); font-size: 0.85rem; line-height: 1.4; }
    }
  }
`,F3=C.div`
  flex: 0.8;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 140px 40px 80px;
  background: white;
  position: relative;
`,I3=C.div`
  width: 100%;
  max-width: 480px;
  background: transparent;
  padding: 40px;

  h2 {
    font-size: 2.2rem;
    color: #0b1a33;
    margin-bottom: 10px;
    font-weight: 900;
    letter-spacing: -0.5px;
  }
  
  p.desc {
    color: #666;
    font-size: 1rem;
    margin-bottom: 50px;
  }
`,Cm=C.div`
  margin-bottom: 30px;
  
  label {
    display: block;
    font-size: 0.8rem;
    font-weight: 800;
    color: #444;
    margin-bottom: 12px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }
  
  .input-wrapper {
    position: relative;
    
    input {
      width: 100%;
      padding: 18px 15px 18px 55px;
      border-radius: 16px;
      border: 2px solid #f0f2f5;
      background: #f9fafb;
      color: #0b1a33;
      font-size: 1rem;
      font-weight: 600;
      transition: all 0.3s ease;
      
      &:focus {
        border-color: ${({theme:i})=>i.colors.gold};
        background: white;
        box-shadow: 0 0 20px rgba(201, 168, 76, 0.1);
        outline: none;
      }

      &::placeholder {
        color: #bbb;
        font-weight: 400;
      }
    }
    
    svg {
      position: absolute;
      left: 20px;
      top: 50%;
      transform: translateY(-50%);
      color: #999;
      transition: all 0.3s ease;
    }

    input:focus + svg, input:focus ~ svg {
      color: ${({theme:i})=>i.colors.gold};
    }
  }
`,P3=()=>{const i=gn(),[s,u]=A.useState({email:"",password:""}),[c,f]=A.useState(!1),[p,h]=A.useState(""),v=async x=>{x.preventDefault(),f(!0),h("");try{const g=await ta.post("/auth/login",s),{token:b,role:y,user:k,admin:D}=g.data;localStorage.setItem("admin_token",b),localStorage.setItem("user_role",y),localStorage.setItem("user_profile",JSON.stringify(y==="admin"?D:k)),na.success("Login successful!"),y==="admin"?window.location.href="/admin/dashboard":i("/dashboard")}catch(g){h(g.response?.data?.error||"Login failed. Please check your credentials.")}finally{f(!1)}};return l.jsxs(Z3,{children:[l.jsxs(W3,{children:[l.jsxs("h1",{children:["Secure Your ",l.jsx("span",{children:"Ecosystem"})]}),l.jsx("p",{className:"subtitle",children:"Join India's most advanced vehicle and personal security network. One platform to monitor, track, and protect everything that matters."}),l.jsxs(J3,{children:[l.jsxs("div",{className:"feature-item",children:[l.jsx("div",{className:"icon",children:l.jsx(Xt,{size:24})}),l.jsxs("div",{className:"text",children:[l.jsx("h4",{children:"Bank-Grade Security"}),l.jsx("p",{children:"256-bit encryption for all your personal data"})]})]}),l.jsxs("div",{className:"feature-item",children:[l.jsx("div",{className:"icon",children:l.jsx(Jl,{size:24})}),l.jsxs("div",{className:"text",children:[l.jsx("h4",{children:"Fleet Protection"}),l.jsx("p",{children:"Real-time vehicle status and driver safety"})]})]}),l.jsxs("div",{className:"feature-item",children:[l.jsx("div",{className:"icon",children:l.jsx(es,{size:24})}),l.jsxs("div",{className:"text",children:[l.jsx("h4",{children:"Instant Alerts"}),l.jsx("p",{children:"Emergency notifications via SMS and calls"})]})]}),l.jsxs("div",{className:"feature-item",children:[l.jsx("div",{className:"icon",children:l.jsx(Sg,{size:24})}),l.jsxs("div",{className:"text",children:[l.jsx("h4",{children:"Cloud Backup"}),l.jsx("p",{children:"Never lose your critical security records"})]})]})]})]}),l.jsx(F3,{children:l.jsxs(I3,{children:[l.jsx("h2",{children:"Welcome Back"}),l.jsx("p",{className:"desc",children:"Enter your credentials to access your dashboard."}),p&&l.jsx("div",{style:{background:"rgba(239, 68, 68, 0.1)",color:"#ef4444",padding:"15px",borderRadius:"16px",marginBottom:"25px",fontSize:"0.85rem",fontWeight:600,border:"1px solid rgba(239, 68, 68, 0.2)",textAlign:"center"},children:p}),l.jsxs("form",{onSubmit:v,children:[l.jsxs(Cm,{children:[l.jsx("label",{children:"Email Address"}),l.jsxs("div",{className:"input-wrapper",children:[l.jsx("input",{type:"email",placeholder:"name@company.com",value:s.email,onChange:x=>u({...s,email:x.target.value}),autoComplete:"email",required:!0}),l.jsx(kd,{size:22})]})]}),l.jsxs(Cm,{children:[l.jsx("label",{children:"Password"}),l.jsxs("div",{className:"input-wrapper",children:[l.jsx("input",{type:"password",placeholder:"••••••••",value:s.password,onChange:x=>u({...s,password:x.target.value}),autoComplete:"current-password",required:!0}),l.jsx(qi,{size:22})]})]}),l.jsx(qe,{type:"submit",disabled:c,style:{width:"100%",padding:"20px",marginTop:"10px",background:"#C9A84C",color:"#0b1a33",borderRadius:"16px",fontSize:"1.1rem",fontWeight:900,opacity:c?.7:1,boxShadow:"0 10px 30px rgba(201, 168, 76, 0.2)"},children:c?"AUTHENTICATING...":l.jsxs("span",{style:{display:"flex",alignItems:"center",justifyContent:"center",gap:"10px"},children:["ACCESS PORTAL ",l.jsx(n5,{size:22})]})})]}),l.jsxs("div",{style:{textAlign:"center",marginTop:"40px",fontSize:"0.95rem",color:"#666"},children:["Don't have an account? ",l.jsx(Ze,{to:"/signup",style:{color:"#0b1a33",fontWeight:800,textDecoration:"none"},children:"Register Now"})]})]})})]})},Am=St`
  0% { transform: translateY(0px); }
  50% { transform: translateY(-20px); }
  100% { transform: translateY(0px); }
`,eS=C.div`
  min-height: 100vh;
  display: flex;
  background: #0b1a33;
  @media (max-width: 960px) {
    flex-direction: column;
  }
`,tS=C.div`
  flex: 1.2;
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 140px 10% 80px;
  background: linear-gradient(135deg, #0b1a33 0%, #112240 100%);
  border-right: 1px solid rgba(255,255,255,0.05);

  &::before, &::after {
    content: '';
    position: absolute;
    width: 600px;
    height: 600px;
    border-radius: 50%;
    filter: blur(120px);
    z-index: 0;
    opacity: 0.3;
  }
  &::before {
    background: radial-gradient(circle, rgba(201, 168, 76, 0.5) 0%, rgba(0,0,0,0) 70%);
    top: -200px;
    left: -200px;
    animation: ${Am} 10s ease-in-out infinite;
  }
  &::after {
    background: radial-gradient(circle, rgba(26, 58, 109, 0.8) 0%, rgba(0,0,0,0) 70%);
    bottom: -200px;
    right: -200px;
    animation: ${Am} 12s ease-in-out infinite reverse;
  }

  > * { position: relative; z-index: 1; }

  h1 {
    font-size: 3.8rem;
    font-weight: 900;
    color: white;
    line-height: 1.1;
    margin-bottom: 25px;
    letter-spacing: -1.5px;
    span { color: #C9A84C; }
  }

  p.subtitle {
    font-size: 1.2rem;
    color: rgba(255,255,255,0.7);
    margin-bottom: 60px;
    max-width: 90%;
    line-height: 1.6;
  }
`,aS=C.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  
  @media (max-width: 1200px) {
    grid-template-columns: 1fr;
  }

  .feature-item {
    display: flex;
    align-items: center;
    gap: 15px;
    background: rgba(255,255,255,0.02);
    padding: 20px;
    border-radius: 20px;
    border: 1px solid rgba(255,255,255,0.05);
    backdrop-filter: blur(10px);
    transition: all 0.3s ease;

    &:hover {
      background: rgba(255,255,255,0.05);
      transform: translateY(-5px);
      border-color: rgba(201, 168, 76, 0.3);
    }

    .icon {
      background: rgba(201, 168, 76, 0.1);
      color: #C9A84C;
      padding: 12px;
      border-radius: 14px;
    }

    .text {
      h4 { color: white; font-size: 1.05rem; font-weight: 700; margin-bottom: 4px; }
      p { color: rgba(255,255,255,0.5); font-size: 0.85rem; line-height: 1.4; }
    }
  }
`,nS=C.div`
  flex: 0.8;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 140px 40px 80px;
  background: white;
  position: relative;
`,iS=C.div`
  width: 100%;
  max-width: 480px;
  background: transparent;
  padding: 40px;

  h2 {
    font-size: 2.2rem;
    color: #0b1a33;
    margin-bottom: 10px;
    font-weight: 900;
    letter-spacing: -0.5px;
  }
  
  p.desc {
    color: #666;
    font-size: 1rem;
    margin-bottom: 40px;
  }
`,To=C.div`
  margin-bottom: 25px;
  
  label {
    display: block;
    font-size: 0.8rem;
    font-weight: 800;
    color: #444;
    margin-bottom: 10px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }
  
  .input-wrapper {
    position: relative;
    
    input {
      width: 100%;
      padding: 18px 15px 18px 55px;
      border-radius: 16px;
      border: 2px solid #f0f2f5;
      background: #f9fafb;
      color: #0b1a33;
      font-size: 1rem;
      font-weight: 600;
      transition: all 0.3s ease;
      
      &:focus {
        border-color: ${({theme:i})=>i.colors.gold};
        background: white;
        box-shadow: 0 0 20px rgba(201, 168, 76, 0.1);
        outline: none;
      }

      &::placeholder {
        color: #bbb;
        font-weight: 400;
      }
    }
    
    svg {
      position: absolute;
      left: 20px;
      top: 50%;
      transform: translateY(-50%);
      color: #999;
      transition: all 0.3s ease;
    }

    input:focus + svg, input:focus ~ svg {
      color: ${({theme:i})=>i.colors.gold};
    }
  }
`,lS=()=>{const i=gn(),[s,u]=A.useState({name:"",email:"",password:"",confirmPassword:""}),[c,f]=A.useState(!1),[p,h]=A.useState(""),v=async x=>{if(x.preventDefault(),h(""),s.password!==s.confirmPassword){h("Passwords do not match!");return}f(!0);try{await ta.post("/auth/signup",{name:s.name,email:s.email,password:s.password}),na.success("Account created! Please login."),i("/login")}catch(g){h(g.response?.data?.error||"Signup failed. Please try again.")}finally{f(!1)}};return l.jsxs(eS,{children:[l.jsxs(tS,{children:[l.jsxs("h1",{children:["Secure Your ",l.jsx("span",{children:"Ecosystem"})]}),l.jsx("p",{className:"subtitle",children:"Join India's most advanced vehicle and personal security network. One platform to monitor, track, and protect everything that matters."}),l.jsxs(aS,{children:[l.jsxs("div",{className:"feature-item",children:[l.jsx("div",{className:"icon",children:l.jsx(Xt,{size:24})}),l.jsxs("div",{className:"text",children:[l.jsx("h4",{children:"Bank-Grade Security"}),l.jsx("p",{children:"256-bit encryption for all your personal data"})]})]}),l.jsxs("div",{className:"feature-item",children:[l.jsx("div",{className:"icon",children:l.jsx(Jl,{size:24})}),l.jsxs("div",{className:"text",children:[l.jsx("h4",{children:"Fleet Protection"}),l.jsx("p",{children:"Real-time vehicle status and driver safety"})]})]}),l.jsxs("div",{className:"feature-item",children:[l.jsx("div",{className:"icon",children:l.jsx(es,{size:24})}),l.jsxs("div",{className:"text",children:[l.jsx("h4",{children:"Instant Alerts"}),l.jsx("p",{children:"Emergency notifications via SMS and calls"})]})]}),l.jsxs("div",{className:"feature-item",children:[l.jsx("div",{className:"icon",children:l.jsx(Sg,{size:24})}),l.jsxs("div",{className:"text",children:[l.jsx("h4",{children:"Cloud Backup"}),l.jsx("p",{children:"Never lose your critical security records"})]})]})]})]}),l.jsx(nS,{children:l.jsxs(iS,{children:[l.jsx("h2",{children:"Create Account"}),l.jsx("p",{className:"desc",children:"Join the ecosystem to manage your smart assets."}),p&&l.jsx("div",{style:{background:"rgba(239, 68, 68, 0.1)",color:"#ef4444",padding:"15px",borderRadius:"16px",marginBottom:"25px",fontSize:"0.85rem",fontWeight:600,border:"1px solid rgba(239, 68, 68, 0.2)",textAlign:"center"},children:p}),l.jsxs("form",{onSubmit:v,children:[l.jsxs(To,{children:[l.jsx("label",{children:"Full Name"}),l.jsxs("div",{className:"input-wrapper",children:[l.jsx("input",{type:"text",placeholder:"Enter your full name",value:s.name,onChange:x=>u({...s,name:x.target.value}),required:!0}),l.jsx(qn,{size:22})]})]}),l.jsxs(To,{children:[l.jsx("label",{children:"Email Address"}),l.jsxs("div",{className:"input-wrapper",children:[l.jsx("input",{type:"email",placeholder:"name@company.com",value:s.email,onChange:x=>u({...s,email:x.target.value}),required:!0}),l.jsx(kd,{size:22})]})]}),l.jsxs(To,{children:[l.jsx("label",{children:"Password"}),l.jsxs("div",{className:"input-wrapper",children:[l.jsx("input",{type:"password",placeholder:"Create a password",value:s.password,onChange:x=>u({...s,password:x.target.value}),required:!0}),l.jsx(qi,{size:22})]})]}),l.jsxs(To,{children:[l.jsx("label",{children:"Confirm Password"}),l.jsxs("div",{className:"input-wrapper",children:[l.jsx("input",{type:"password",placeholder:"Confirm your password",value:s.confirmPassword,onChange:x=>u({...s,confirmPassword:x.target.value}),required:!0}),l.jsx(qi,{size:22})]})]}),l.jsx(qe,{type:"submit",disabled:c,style:{width:"100%",padding:"20px",marginTop:"10px",background:"#C9A84C",color:"#0b1a33",borderRadius:"16px",fontSize:"1.1rem",fontWeight:900,opacity:c?.7:1,boxShadow:"0 10px 30px rgba(201, 168, 76, 0.2)"},children:c?"CREATING ACCOUNT...":l.jsxs("span",{style:{display:"flex",alignItems:"center",justifyContent:"center",gap:"10px"},children:["REGISTER ",l.jsx(Z5,{size:22})]})})]}),l.jsxs("div",{style:{textAlign:"center",marginTop:"35px",fontSize:"0.95rem",color:"#666"},children:["Already have an account? ",l.jsx(Ze,{to:"/login",style:{color:"#0b1a33",fontWeight:800,textDecoration:"none"},children:"Login Here"})]})]})})]})},rS=C.div`
  display: flex;
  min-height: 100vh;
  background-color: #f8f9fa;
  padding-top: 85px;
`,oS=C.aside`
  width: 260px;
  background-color: ${({theme:i})=>i.colors.navy};
  color: white;
  display: flex;
  flex-direction: column;
  padding: 30px 0;
  position: fixed;
  top: 85px;
  height: calc(100vh - 85px);
  z-index: 99;
`;C.div`
  padding: 0 30px 40px;
  display: flex;
  align-items: center;
  gap: 12px;
  font-family: ${({theme:i})=>i.fonts.display};
  font-size: 1.25rem;
  font-weight: 700;
  
  img {
    height: 32px;
    border-radius: 4px;
  }
`;const sS=C.ul`
  list-style: none;
  padding: 0;
  flex: 1;
`,$l=C.li`
  margin-bottom: 5px;
`,ki=C(Ze)`
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 30px;
  color: white;
  text-decoration: none;
  opacity: 0.7;
  transition: all 0.3s ease;
  border-left: 4px solid transparent;

  &:hover, &.active {
    opacity: 1;
    background: rgba(255, 255, 255, 0.1);
    border-left-color: ${({theme:i})=>i.colors.gold};
    color: ${({theme:i})=>i.colors.gold};
  }

  svg {
    width: 20px;
  }
`,cS=C.main`
  flex: 1;
  margin-left: 260px;
  padding: 30px;
`,uS=C.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 40px;
  background: white;
  padding: 20px 30px;
  border-radius: 12px;
  box-shadow: 0 4px 15px rgba(0,0,0,0.05);
`,dS=C.div`
  position: relative;
  width: 300px;

  input {
    width: 100%;
    padding: 10px 15px 10px 40px;
    border-radius: 8px;
    border: 1px solid #eee;
    background: #fdfdfd;
    outline: none;
    
    &:focus {
      border-color: ${({theme:i})=>i.colors.gold};
    }
  }

  svg {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: #999;
  }
`,fS=C.div`
  display: flex;
  align-items: center;
  gap: 20px;
`,hS=C.button`
  background: none;
  border: none;
  cursor: pointer;
  color: #666;
  position: relative;

  .badge {
    position: absolute;
    top: -5px;
    right: -5px;
    background: red;
    color: white;
    font-size: 10px;
    padding: 2px 5px;
    border-radius: 10px;
  }
`,pS=C.div`
  background: linear-gradient(135deg, ${({theme:i})=>i.colors.navy} 0%, #1a3a6d 100%);
  color: white;
  padding: 40px;
  border-radius: 20px;
  margin-bottom: 40px;
  position: relative;
  overflow: hidden;

  h1 {
    font-size: 2rem;
    margin-bottom: 15px;
  }

  p {
    opacity: 0.8;
    max-width: 500px;
  }

  &::after {
    content: '';
    position: absolute;
    right: -50px;
    top: -50px;
    width: 200px;
    height: 200px;
    background: rgba(255,255,255,0.05);
    border-radius: 50%;
  }
`,mS=C.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 25px;
  margin-bottom: 40px;
`,gS=C.div`
  background: white;
  padding: 25px;
  border-radius: 15px;
  box-shadow: 0 4px 15px rgba(0,0,0,0.05);
  display: flex;
  align-items: center;
  gap: 20px;

  .icon-box {
    width: 50px;
    height: 50px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #fff4e5;
    color: ${({theme:i})=>i.colors.gold};
  }

  .info {
    h4 {
      color: #777;
      font-size: 0.9rem;
      margin-bottom: 5px;
    }
    span {
      font-size: 1.5rem;
      font-weight: 700;
      color: ${({theme:i})=>i.colors.navy};
    }
  }
`,xS=C.div`
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 30px;
`,zm=C.div`
  background: white;
  padding: 25px;
  border-radius: 15px;
  box-shadow: 0 4px 15px rgba(0,0,0,0.05);

  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
    
    h3 {
      font-size: 1.25rem;
      color: ${({theme:i})=>i.colors.navy};
    }
    
    button {
      color: ${({theme:i})=>i.colors.gold};
      background: none;
      border: none;
      font-weight: 600;
      cursor: pointer;
    }
  }
`,yS=C.table`
  width: 100%;
  border-collapse: collapse;

  th {
    text-align: left;
    padding: 15px;
    color: #999;
    font-size: 0.85rem;
    font-weight: 600;
    border-bottom: 1px solid #f0f0f0;
  }

  td {
    padding: 15px;
    border-bottom: 1px solid #f8f8f8;
    color: #444;
  }

  tr:last-child td {
    border-bottom: none;
  }
`,bS=C.span`
  padding: 5px 12px;
  border-radius: 20px;
  font-size: 0.75rem;
  font-weight: 600;
  background: ${i=>i.type==="active"?"#e6f7e6":"#fff0f0"};
  color: ${i=>i.type==="active"?"#2e7d32":"#d32f2f"};
`,vS=()=>{const i=gn(),s=[{label:"Active QRs",value:"12",icon:l.jsx(Mi,{})},{label:"Total Scans",value:"1,284",icon:l.jsx(od,{})},{label:"Call Alerts",value:"45",icon:l.jsx(zg,{})},{label:"Profile Views",value:"3,456",icon:l.jsx(qn,{})}],u=[{id:"QR-8291",name:"Car Sticker - Swift",status:"active",date:"Feb 20, 2024"},{id:"QR-8292",name:"Pet Tag - Bruno",status:"active",date:"Feb 18, 2024"},{id:"QR-8293",name:"Keyring - Office",status:"inactive",date:"Feb 15, 2024"}],c=()=>{i("/login")};return l.jsxs(l.Fragment,{children:[l.jsx(Md,{}),l.jsxs(rS,{children:[l.jsxs(oS,{children:[l.jsxs(sS,{children:[l.jsx($l,{children:l.jsxs(ki,{to:"/admin/dashboard",className:"active",children:[l.jsx(I2,{}),"Master Panel"]})}),l.jsx($l,{children:l.jsxs(ki,{to:"#",children:[l.jsx(Mi,{}),"Bulk Manage"]})}),l.jsx($l,{children:l.jsxs(ki,{to:"#",children:[l.jsx(History,{}),"System Health"]})}),l.jsx($l,{children:l.jsxs(ki,{to:"#",children:[l.jsx(qn,{}),"User Database"]})}),l.jsx($l,{children:l.jsxs(ki,{to:"#",children:[l.jsx(Tg,{}),"System Settings"]})})]}),l.jsx("div",{style:{padding:"0 30px"},children:l.jsxs(ki,{to:"/login",onClick:c,style:{border:"none",background:"rgba(255,255,255,0.05)",borderRadius:"8px"},children:[l.jsx(Cg,{}),"Logout"]})})]}),l.jsxs(cS,{children:[l.jsxs(uS,{children:[l.jsxs(dS,{children:[l.jsx(A5,{size:18}),l.jsx("input",{type:"text",placeholder:"Search Master Database..."})]}),l.jsxs(fS,{children:[l.jsxs(hS,{children:[l.jsx(es,{size:20}),l.jsx("div",{className:"badge",children:"3"})]}),l.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"10px"},children:[l.jsxs("div",{style:{textAlign:"right"},children:[l.jsx("div",{style:{fontWeight:700,fontSize:"0.9rem"},children:"Akash Yadav"}),l.jsx("div",{style:{fontSize:"0.75rem",color:"#888"},children:"Super Admin"})]}),l.jsx("div",{style:{width:"40px",height:"40px",borderRadius:"50%",background:"#eee",display:"flex",alignItems:"center",justifyContent:"center"},children:l.jsx(qn,{size:20,color:"#666"})})]})]})]}),l.jsxs(pS,{children:[l.jsx("h1",{children:"Super Admin Control"}),l.jsx("p",{children:"Managing 1,284 scan events across the Tarkshya ecosystem. 3 new critical alerts pending review."})]}),l.jsx(mS,{children:s.map((f,p)=>l.jsxs(gS,{children:[l.jsx("div",{className:"icon-box",children:f.icon}),l.jsxs("div",{className:"info",children:[l.jsx("h4",{children:f.label}),l.jsx("span",{children:f.value})]})]},p))}),l.jsxs(xS,{children:[l.jsxs(zm,{children:[l.jsxs("div",{className:"header",children:[l.jsx("h3",{children:"Master QR Inventory"}),l.jsxs("button",{children:[l.jsx(_2,{size:18,style:{verticalAlign:"middle",marginRight:"5px"}})," Bulk Generate"]})]}),l.jsxs(yS,{children:[l.jsx("thead",{children:l.jsxs("tr",{children:[l.jsx("th",{children:"ID"}),l.jsx("th",{children:"Asset Name"}),l.jsx("th",{children:"Status"}),l.jsx("th",{children:"Created Date"}),l.jsx("th",{children:"Action"})]})}),l.jsx("tbody",{children:u.map(f=>l.jsxs("tr",{children:[l.jsx("td",{children:f.id}),l.jsx("td",{style:{fontWeight:600},children:f.name}),l.jsx("td",{children:l.jsx(bS,{type:f.status,children:f.status})}),l.jsx("td",{children:f.date}),l.jsx("td",{children:l.jsx("button",{style:{background:"none",border:"none",color:"#666",cursor:"pointer"},children:"Edit/Revoke"})})]},f.id))})]})]}),l.jsxs(zm,{children:[l.jsx("div",{className:"header",children:l.jsx("h3",{children:"Live System Feed"})}),l.jsx("div",{style:{display:"flex",flexDirection:"column",gap:"20px"},children:[1,2,3,4].map(f=>l.jsxs("div",{style:{display:"flex",gap:"15px",alignItems:"flex-start"},children:[l.jsx("div",{style:{width:"35px",height:"35px",borderRadius:"8px",background:"#f0f4f8",display:"flex",alignItems:"center",justifyContent:"center",color:"#0b1a33"},children:l.jsx(od,{size:16})}),l.jsxs("div",{children:[l.jsx("div",{style:{fontSize:"0.85rem",fontWeight:600},children:"Celerio Car QR Scanned"}),l.jsx("div",{style:{fontSize:"0.75rem",color:"#999"},children:"Chandausi, UP • 2 mins ago"})]})]},f))})]})]})]})]})]})},jS=C.div`
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  padding: 20px;
`,SS=C.div`
  background: white;
  padding: 35px;
  border-radius: 20px;
  width: 100%;
  max-width: 600px;
  max-height: 90vh;
  overflow-y: auto;
  position: relative;
  box-shadow: 0 10px 40px rgba(0,0,0,0.2);

  h2 {
    color: #0b1a33;
    margin-bottom: 20px;
    font-weight: 800;
  }
`,wS=C.button`
  position: absolute;
  top: 20px; right: 20px;
  background: #f5f5f5; border: none;
  width: 35px; height: 35px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: #666;
  transition: all 0.2s;
  &:hover { background: #eee; color: #333; }
`,Em=C.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  margin-bottom: 30px;
  
  .detail-group {
    label {
      font-size: 0.8rem;
      color: #888;
      font-weight: 600;
      display: block;
      margin-bottom: 4px;
      text-transform: uppercase;
    }
    div {
      font-weight: 600;
      color: #333;
    }
  }
`,CS=C.div`
  border: 1px solid #eee;
  border-radius: 12px;
  overflow: hidden;
  
  .item {
    display: flex;
    justify-content: space-between;
    padding: 15px;
    border-bottom: 1px solid #eee;
    background: #fafafa;
    &:last-child { border-bottom: none; }
    
    .name { font-weight: 600; color: #0b1a33; }
    .price { font-weight: 700; color: #C9A84C; }
  }
`,AS=C.div`
  display: flex;
  min-height: 100vh;
  background-color: #f8f9fa;
  padding-top: 85px;
`,zS=C.aside`
  width: 260px;
  background: linear-gradient(180deg, #0b1a33 0%, #081226 100%);
  color: white;
  display: flex;
  flex-direction: column;
  padding: 30px 0;
  position: fixed;
  top: 85px;
  height: calc(100vh - 85px);
  z-index: 99;
  border-right: 1px solid rgba(255,255,255,0.05);
`;C.div`
  padding: 0 30px 40px;
  display: flex;
  flex-direction: column;
  
  .brand {
    font-size: 1.25rem;
    font-weight: 900;
    display: flex;
    align-items: center;
    gap: 10px;
  }
  
  .tagline {
    font-size: 0.6rem;
    opacity: 0.6;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    margin-top: 4px;
  }
`;const ES=C.ul`
  list-style: none;
  padding: 0;
  flex: 1;
`,Gu=C.li`
  margin-bottom: 5px;
`,Qu=C.button`
  display: flex;
  align-items: center;
  gap: 15px;
  padding: 16px 30px;
  color: white;
  width: 100%;
  text-align: left;
  background: transparent;
  border: none;
  opacity: 0.6;
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  border-left: 4px solid transparent;
  cursor: pointer;
  font-size: 0.95rem;
  font-weight: 600;
  letter-spacing: 0.02em;

  &:hover, &.active {
    opacity: 1;
    background: linear-gradient(90deg, rgba(201,168,76,0.1) 0%, transparent 100%);
    border-left-color: #C9A84C;
    color: #C9A84C;
    padding-left: 35px;
  }

  svg {
    width: 20px;
    transition: transform 0.3s ease;
  }
  
  &:hover svg {
    transform: scale(1.1);
  }
`,TS=St`
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
`,NS=C.main`
  flex: 1;
  margin-left: 260px;
  padding: 40px;
  animation: ${TS} 0.8s ease-out;
`,kS=C.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 35px;
  background: white;
  padding: 20px 35px;
  border-radius: 24px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.03);
  border: 1px solid rgba(0,0,0,0.02);
`,Vu=C.div`
  background: linear-gradient(135deg, #0b1a33 0%, #1a3a6d 100%);
  color: white;
  padding: 45px;
  border-radius: 32px;
  margin-bottom: 40px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: relative;
  overflow: hidden;
  box-shadow: 0 25px 50px -12px rgba(11, 26, 51, 0.4);

  .text {
    position: relative;
    z-index: 2;
    h1 {
      font-size: 2.2rem;
      font-weight: 900;
      margin-bottom: 12px;
      font-family: ${({theme:i})=>i.fonts.display};
      background: linear-gradient(to right, #fff, #C9A84C);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    p {
      font-size: 1.1rem;
      opacity: 0.8;
      font-weight: 500;
    }
  }

  .accent-circle {
    position: absolute;
    right: -50px;
    top: -50px;
    width: 250px;
    height: 250px;
    background: radial-gradient(circle, rgba(201,168,76,0.15) 0%, transparent 70%);
    border-radius: 50%;
  }
`,RS=C.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 25px;
  margin-bottom: 40px;
`,Xu=C.div`
  background: white;
  padding: 25px;
  border-radius: 24px;
  display: flex;
  align-items: center;
  gap: 20px;
  box-shadow: 0 10px 25px rgba(0,0,0,0.02);
  border: 1px solid #f0f0f0;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 35px rgba(0,0,0,0.05);
  }

  .icon-box {
    width: 50px;
    height: 50px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f8f9fa;
    color: #C9A84C;
  }

  .details {
    .label { font-size: 0.85rem; color: #888; font-weight: 600; margin-bottom: 2px; }
    .value { font-size: 1.4rem; font-weight: 800; color: #0b1a33; }
  }
`,Ku=C.div`
  background: white;
  padding: 40px;
  border-radius: 28px;
  box-shadow: 0 15px 40px rgba(0,0,0,0.02);
  margin-bottom: 35px;
  border: 1px solid rgba(0,0,0,0.03);

  h3 {
    font-size: 1.5rem;
    margin-bottom: 35px;
    color: #0b1a33;
    display: flex;
    align-items: center;
    gap: 15px;
    font-weight: 900;
    font-family: ${({theme:i})=>i.fonts.display};
    
    &::after {
      content: '';
      flex: 1;
      height: 1px;
      background: linear-gradient(to right, #eee, transparent);
    }
  }
`,No=C.div`
  margin-bottom: 20px;
  label {
    display: block;
    margin-bottom: 8px;
    font-size: 0.9rem;
    font-weight: 600;
    color: #555;
  }
  input {
    width: 100%;
    padding: 12px 15px;
    border-radius: 10px;
    border: 1px solid #ddd;
    font-family: inherit;
    font-size: 1rem;
    &:focus {
      border-color: #C9A84C;
      outline: none;
      box-shadow: 0 0 0 3px rgba(201,168,76,0.1);
    }
  }
`,_S=C.table`
  width: 100%;
  border-collapse: separate;
  border-spacing: 0 10px;
  
  th, td {
    padding: 20px;
    text-align: left;
  }
  
  th {
    font-weight: 800;
    color: #999;
    text-transform: uppercase;
    font-size: 0.75rem;
    letter-spacing: 0.1em;
    border: none;
  }
  
  tbody tr {
    background: transparent;
    transition: all 0.3s ease;
    border-radius: 16px;
    
    &:hover {
      background: #f8f9fa;
      transform: scale(1.01);
      box-shadow: 0 10px 20px rgba(0,0,0,0.02);
    }
    
    td {
      border-top: 1px solid transparent;
      border-bottom: 1px solid #f0f0f0;
      color: #0b1a33;
      font-weight: 600;
      
      &:first-child { border-radius: 16px 0 0 16px; }
      &:last-child { border-radius: 0 16px 16px 0; }
    }
  }
`,ko=C.span`
  padding: 6px 14px;
  border-radius: 12px;
  font-size: 0.7rem;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: ${i=>i.status==="PAID"||i.status==="DELIVERED"?"#e6f7e6":"#fff3e0"};
  color: ${i=>i.status==="PAID"||i.status==="DELIVERED"?"#2e7d32":"#ef6c00"};
  
  &::before {
    content: '';
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: currentColor;
  }
`,MS=C.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 20px;
`,DS=C.div`
  border: 1px solid #eee;
  border-radius: 16px;
  padding: 20px;
  text-align: center;
  background: #fafafa;
  
  .qr-placeholder {
    width: 150px;
    height: 150px;
    background: white;
    margin: 0 auto 20px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
  }

  h4 {
    margin-bottom: 5px;
    color: #0b1a33;
  }

  p {
    font-size: 0.8rem;
    color: #888;
    margin-bottom: 15px;
  }
`,OS=()=>{const i=gn(),s=e2(),[u,c]=A.useState(!0),[f,p]=A.useState(null),[h,v]=A.useState("orders"),[x,g]=A.useState(null),[b,y]=A.useState({name:"",phone:"",currentPassword:"",newPassword:""}),k=async()=>{try{const U=await ta.get("/user/dashboard");p(U.data),y(Q=>({...Q,name:U.data.user?.name||"",phone:U.data.user?.phone||""}))}catch(U){console.error(U),na.error("Failed to load dashboard data"),U.response?.status===401&&i("/login")}finally{c(!1)}};A.useEffect(()=>{if(!localStorage.getItem("admin_token")){i("/login");return}k()},[i]);const D=async U=>{U.preventDefault();try{await ta.post("/user/settings",b),na.success("Profile updated successfully!"),y(Q=>({...Q,currentPassword:"",newPassword:""})),k()}catch(Q){na.error(Q.response?.data?.error||"Failed to update profile")}};if(u)return l.jsx("div",{style:{display:"flex",height:"100vh",alignItems:"center",justifyContent:"center",background:"#0b1a33",color:"white"},children:"SECURE LOADING..."});const{user:_,tags:q,orders:Y}=f||{};return l.jsxs(l.Fragment,{children:[l.jsx(Md,{}),l.jsxs(AS,{children:[l.jsxs(zS,{children:[l.jsxs(ES,{children:[l.jsx(Gu,{children:l.jsxs(Qu,{className:h==="orders"?"active":"",onClick:()=>v("orders"),children:[l.jsx(Yo,{}),"My Orders"]})}),l.jsx(Gu,{children:l.jsxs(Qu,{className:h==="qrcodes"?"active":"",onClick:()=>v("qrcodes"),children:[l.jsx(Mi,{}),"My QR Tags"]})}),l.jsx(Gu,{children:l.jsxs(Qu,{className:h==="profile"?"active":"",onClick:()=>v("profile"),children:[l.jsx(qn,{}),"Profile Settings"]})})]}),l.jsx("div",{style:{padding:"0 30px"},children:l.jsxs("button",{onClick:()=>{localStorage.removeItem("admin_token"),localStorage.removeItem("user_role"),localStorage.removeItem("user_profile"),i("/login")},style:{width:"100%",display:"flex",alignItems:"center",gap:"12px",padding:"12px 30px",color:"white",textDecoration:"none",opacity:.7,transition:"all 0.3s ease",border:"none",background:"rgba(255,255,255,0.05)",borderRadius:"8px",cursor:"pointer",textAlign:"left",fontSize:"1rem"},children:[l.jsx(Cg,{size:20}),"Logout"]})})]}),l.jsxs(NS,{children:[l.jsxs(kS,{children:[l.jsxs("div",{style:{display:"flex",flexDirection:"column"},children:[l.jsxs("div",{style:{fontSize:"0.75rem",color:"#888",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:"4px"},children:["Platform / Customer / ",h]}),l.jsx("div",{style:{fontWeight:900,color:"#0b1a33",fontSize:"1.4rem",fontFamily:s?.fonts?.display||"serif"},children:h==="orders"?"Orders Ledger":h==="qrcodes"?"Digital Assets":"Account Security"})]}),l.jsx("div",{style:{display:"flex",alignItems:"center",gap:"20px"},children:l.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"15px",padding:"8px 20px",background:"#f8f9fa",borderRadius:"100px",border:"1px solid #f0f0f0"},children:[l.jsxs("div",{style:{textAlign:"right"},children:[l.jsx("div",{style:{fontWeight:800,fontSize:"0.85rem",color:"#0b1a33"},children:_?.name}),l.jsx("div",{style:{fontSize:"0.7rem",color:"#888",fontWeight:600},children:_?.email})]}),l.jsx("div",{style:{width:"36px",height:"36px",borderRadius:"50%",background:"white",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 4px 10px rgba(0,0,0,0.05)"},children:l.jsx(qn,{size:18,color:"#C9A84C"})})]})})]}),h==="orders"&&l.jsxs(l.Fragment,{children:[l.jsxs(Vu,{children:[l.jsxs("div",{className:"text",children:[l.jsxs("h1",{children:["Welcome Back, ",_?.name?.split(" ")[0]||"User","!"]}),l.jsxs("p",{children:["You have ",Y?.length||0," active orders in your secure history."]})]}),l.jsx("div",{className:"accent-circle"}),l.jsx(sd,{size:80,color:"#C9A84C",opacity:.3})]}),l.jsxs(RS,{children:[l.jsxs(Xu,{children:[l.jsx("div",{className:"icon-box",children:l.jsx(Yo,{size:24})}),l.jsxs("div",{className:"details",children:[l.jsx("div",{className:"label",children:"Total Orders"}),l.jsx("div",{className:"value",children:Y?.length||0})]})]}),l.jsxs(Xu,{children:[l.jsx("div",{className:"icon-box",children:l.jsx(Xt,{size:24})}),l.jsxs("div",{className:"details",children:[l.jsx("div",{className:"label",children:"Secure Tags"}),l.jsx("div",{className:"value",children:q?.length||0})]})]}),l.jsxs(Xu,{children:[l.jsx("div",{className:"icon-box",children:l.jsx(sd,{size:24})}),l.jsxs("div",{className:"details",children:[l.jsx("div",{className:"label",children:"Pending Delivery"}),l.jsx("div",{className:"value",children:Y?.filter(U=>U.status==="PENDING")?.length||0})]})]})]}),l.jsxs(Ku,{children:[l.jsxs("h3",{children:[l.jsx(Yo,{size:24,color:"#C9A84C"})," Manifest History"]}),!Y||Y.length===0?l.jsx("p",{style:{color:"#999",textAlign:"center",padding:"40px"},children:"You haven't placed any orders yet."}):l.jsx("div",{style:{overflowX:"auto"},children:l.jsxs(_S,{children:[l.jsx("thead",{children:l.jsxs("tr",{children:[l.jsx("th",{children:"Order ID"}),l.jsx("th",{children:"Date"}),l.jsx("th",{children:"Items"}),l.jsx("th",{children:"Total Amount"}),l.jsx("th",{children:"Payment Status"}),l.jsx("th",{children:"Order Status"})]})}),l.jsx("tbody",{children:Y.map(U=>l.jsxs("tr",{onClick:()=>g(U),children:[l.jsx("td",{style:{fontWeight:900,color:"#0b1a33",fontSize:"0.9rem"},children:U.orderNumber}),l.jsx("td",{style:{fontSize:"0.85rem",color:"#666"},children:new Date(U.createdAt).toLocaleDateString(void 0,{day:"2-digit",month:"short",year:"numeric"})}),l.jsx("td",{style:{maxWidth:"250px"},children:l.jsx("div",{style:{whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis",fontSize:"0.9rem"},children:U.items.map(Q=>Q.productName).join(", ")})}),l.jsxs("td",{style:{fontWeight:800},children:["₹",U.totalAmount]}),l.jsx("td",{children:l.jsx(ko,{status:U.paymentStatus,children:U.paymentStatus})}),l.jsx("td",{children:l.jsx(ko,{status:U.status==="DELIVERED"?"PAID":"UNPAID",children:U.status})})]},U.id))})]})})]})]}),h==="qrcodes"&&l.jsxs(l.Fragment,{children:[l.jsxs(Vu,{children:[l.jsxs("div",{className:"text",children:[l.jsx("h1",{children:"Secure QR Ecosystem"}),l.jsx("p",{children:"Manage and download your digital identity smart tags."})]}),l.jsx("div",{className:"accent-circle"}),l.jsx(Mi,{size:80,color:"#C9A84C",opacity:.3})]}),l.jsxs(Ku,{children:[l.jsxs("h3",{children:[l.jsx(Mi,{size:24,color:"#C9A84C"})," Digital Inventory"]}),!q||q.length===0?l.jsx("p",{style:{color:"#999",textAlign:"center",padding:"40px"},children:"No QR Tags available. Purchase a tag to see it here."}):l.jsx(MS,{children:q.map(U=>l.jsxs(DS,{children:[l.jsx("div",{className:"qr-placeholder",children:l.jsx(Mi,{size:80,color:"#0b1a33"})}),l.jsx("h4",{children:U.customAssetType||U.assetType}),l.jsxs("p",{children:["Code: ",U.tagCode]}),l.jsxs("div",{style:{display:"flex",gap:"10px",justifyContent:"center"},children:[l.jsxs(qe,{variant:"outline",style:{padding:"8px 15px",fontSize:"0.8rem"},onClick:()=>window.open(`/scan/${U.id}`,"_blank"),children:[l.jsx(od,{size:14})," Preview"]}),l.jsxs(qe,{variant:"primary",style:{padding:"8px 15px",fontSize:"0.8rem",background:"#0b1a33"},children:[l.jsx(wg,{size:14})," Download"]})]})]},U.id))})]})]}),h==="profile"&&l.jsxs(l.Fragment,{children:[l.jsxs(Vu,{children:[l.jsxs("div",{className:"text",children:[l.jsx("h1",{children:"Profile Settings"}),l.jsx("p",{children:"Manage your account details and security."})]}),l.jsx(Tg,{size:50,opacity:.2})]}),l.jsxs(Ku,{style:{maxWidth:"600px"},children:[l.jsxs("h3",{children:[l.jsx(qn,{size:20,color:"#C9A84C"})," Personal Information"]}),l.jsxs("form",{onSubmit:D,children:[l.jsxs(No,{children:[l.jsx("label",{children:"Full Name"}),l.jsx("input",{type:"text",value:b.name,onChange:U=>y({...b,name:U.target.value}),required:!0})]}),l.jsxs(No,{children:[l.jsx("label",{children:"Phone Number"}),l.jsx("input",{type:"tel",value:b.phone,onChange:U=>y({...b,phone:U.target.value}),required:!0})]}),l.jsxs("h3",{style:{marginTop:"40px"},children:[l.jsx(qi,{size:20,color:"#C9A84C"})," Update Password"]}),l.jsx("p",{style:{fontSize:"0.85rem",color:"#888",marginBottom:"20px"},children:"Leave blank if you don't want to change your password."}),l.jsxs(No,{children:[l.jsx("label",{children:"Current Password"}),l.jsx("input",{type:"password",placeholder:"Enter current password",value:b.currentPassword,onChange:U=>y({...b,currentPassword:U.target.value})})]}),l.jsxs(No,{children:[l.jsx("label",{children:"New Password"}),l.jsx("input",{type:"password",placeholder:"Enter new password",value:b.newPassword,onChange:U=>y({...b,newPassword:U.target.value})})]}),l.jsx(qe,{type:"submit",variant:"primary",style:{width:"100%",marginTop:"20px",padding:"15px"},children:"Save Changes"})]})]})]})]}),x&&l.jsx(jS,{onClick:()=>g(null),children:l.jsxs(SS,{onClick:U=>U.stopPropagation(),children:[l.jsx(wS,{onClick:()=>g(null),children:l.jsx(kg,{size:20})}),l.jsx("h2",{children:"Order Details"}),l.jsxs(Em,{children:[l.jsxs("div",{className:"detail-group",children:[l.jsx("label",{children:"Order Number"}),l.jsx("div",{children:x.orderNumber})]}),l.jsxs("div",{className:"detail-group",children:[l.jsx("label",{children:"Order Date"}),l.jsxs("div",{children:[new Date(x.createdAt).toLocaleDateString()," at ",new Date(x.createdAt).toLocaleTimeString()]})]}),l.jsxs("div",{className:"detail-group",children:[l.jsx("label",{children:"Payment Status"}),l.jsx("div",{children:l.jsx(ko,{status:x.paymentStatus,children:x.paymentStatus})})]}),l.jsxs("div",{className:"detail-group",children:[l.jsx("label",{children:"Order Status"}),l.jsx("div",{children:l.jsx(ko,{status:x.status==="DELIVERED"?"PAID":"UNPAID",children:x.status})})]})]}),l.jsx("h3",{style:{fontSize:"1.1rem",marginBottom:"15px",color:"#0b1a33"},children:"Shipping Information"}),l.jsxs(Em,{children:[l.jsxs("div",{className:"detail-group",children:[l.jsx("label",{children:"Customer Name"}),l.jsx("div",{children:x.customerName})]}),l.jsxs("div",{className:"detail-group",children:[l.jsx("label",{children:"Phone"}),l.jsx("div",{children:x.customerPhone})]}),l.jsxs("div",{className:"detail-group",style:{gridColumn:"1 / -1"},children:[l.jsx("label",{children:"Address"}),l.jsx("div",{children:x.shippingAddress})]})]}),l.jsx("h3",{style:{fontSize:"1.1rem",marginBottom:"15px",color:"#0b1a33"},children:"Order Items"}),l.jsxs(CS,{children:[x.items.map((U,Q)=>l.jsxs("div",{className:"item",children:[l.jsxs("div",{className:"name",children:[U.quantity,"x ",U.productName]}),l.jsxs("div",{className:"price",children:["₹",U.totalPrice]})]},Q)),l.jsxs("div",{className:"item",style:{background:"#0b1a33",color:"white"},children:[l.jsx("div",{className:"name",style:{color:"white"},children:"Total Amount"}),l.jsxs("div",{className:"price",style:{color:"#C9A84C"},children:["₹",x.totalAmount]})]})]})]})})]})]})},HS=St`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`,US=C.div`
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  animation: ${HS} 0.6s ease-out;
`,BS=C.div`
  text-align: center;
  margin-bottom: 40px;
  
  img {
    height: 60px;
    margin-bottom: 20px;
  }
  
  h1 {
    font-size: 1.5rem;
    color: ${({theme:i})=>i.colors.navy};
    margin-bottom: 10px;
  }
  
  p {
    color: #666;
  }
`,LS=C.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 20px;
  margin-bottom: 40px;
`,Zu=C.div`
  background: white;
  padding: 25px;
  border-radius: 16px;
  border: 2px solid ${i=>i.active?i.theme.colors.gold:"#eee"};
  box-shadow: 0 4px 15px rgba(0,0,0,0.05);
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: 20px;

  &:hover {
    transform: translateY(-5px);
    border-color: ${({theme:i})=>i.colors.gold};
  }

  .icon-box {
    width: 60px;
    height: 60px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: ${i=>i.type==="emergency"?"#fff0f0":"#eef6ff"};
    color: ${i=>i.type==="emergency"?"#d32f2f":"#1976d2"};
  }

  .content {
    h3 {
      font-size: 1.1rem;
      margin-bottom: 5px;
      color: ${({theme:i})=>i.colors.navy};
    }
    p {
      font-size: 0.9rem;
      color: #777;
    }
  }
`,qS=C.div`
  background: ${({theme:i})=>i.colors.navy};
  color: white;
  padding: 30px;
  border-radius: 20px;
  text-align: center;
  
  h2 {
    font-size: 1.25rem;
    margin-bottom: 15px;
  }
  
  p {
    font-size: 0.9rem;
    opacity: 0.8;
    margin-bottom: 25px;
  }
`,YS=C.div`
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: rgba(255,255,255,0.1);
  padding: 8px 16px;
  border-radius: 20px;
  font-size: 0.8rem;
  margin-top: 20px;
  color: ${({theme:i})=>i.colors.gold};
`,$S={en:{title:"Secured Vehicle Profile",privacyMsg:"The owner has enabled Privacy Mode. Your identity and the owner's identity are protected.",standardMsg:"You have scanned a secure Tarkshya QR code. Please help by selecting an action below.",emergency:"Emergency / Accident",emergencyDesc:"Vehicle met with an accident or the driver needs urgent medical help.",parking:"Wrong / Obstructive Parking",parkingDesc:"This vehicle is parked incorrectly or blocking your way.",info:"General Inquiry",infoDesc:"Want to contact the owner for other reasons.",alertSent:"The owner and their emergency contacts will be alerted immediately via WhatsApp and Parallel SMS with your location.",shareLocation:"Share Location & Alert Owner",virtualCall:"Initiate Virtual Call",requestMove:"Send Location & Request Move",callPrivate:"Call Owner Privately",goBack:"Go Back",privacyTag:"Your identity remains 100% private"},hi:{title:"सुरक्षित वाहन प्रोफाइल",privacyMsg:"मालिक ने प्राइवेसी मोड सक्षम किया है। आपकी और मालिक की पहचान सुरक्षित है।",standardMsg:"आपने एक सुरक्षित Tarkshya QR कोड स्कैन किया है। कृपया नीचे दिए गए विकल्पों में से चयन करके सहायता करें।",emergency:"आपातकालीन / दुर्घटना",emergencyDesc:"वाहन दुर्घटनाग्रस्त हो गया है या ड्राइवर को तत्काल चिकित्सा सहायता की आवश्यकता है।",parking:"गलत / अवरोधक पार्किंग",parkingDesc:"यह वाहन गलत तरीके से पार्क किया गया है या आपका रास्ता रोक रहा है।",info:"सामान्य पूछताछ",infoDesc:"अन्य कारणों से मालिक से संपर्क करना चाहते हैं।",alertSent:"मालिक और उनके आपातकालीन संपर्कों को WhatsApp और पैरेलल SMS के माध्यम से आपके स्थान के साथ तुरंत सूचित किया जाएगा।",shareLocation:"लोकेशन साझा करें और अलर्ट भेजें",virtualCall:"वर्चुअल कॉल शुरू करें",requestMove:"लोकेशन भेजें और हटने का अनुरोध करें",callPrivate:"मालिक को प्राइवेट कॉल करें",goBack:"पीछे हटें",privacyTag:"आपकी पहचान 100% निजी रहती है"}},GS=()=>{const[i,s]=A.useState(null),[u,c]=A.useState(!0),[f,p]=A.useState("en"),h=$S[f],v="918881384777",x=g=>{if(!navigator.geolocation){alert("Geolocation is not supported by your browser.");return}navigator.geolocation.getCurrentPosition(b=>{const{latitude:y,longitude:k}=b.coords,D=`https://www.google.com/maps?q=${y},${k}`,_=g==="emergency"?`🚨 EMERGENCY ALERT! Someone scanned your Tarkshya QR and reported an accident.
Location: ${D}
(Parallel SMS also sent)`:`🚗 PARKING ALERT! Please move your vehicle. Someone is waiting.
Location: ${D}
(Parallel SMS also sent)`;window.open(`https://wa.me/${v}?text=${encodeURIComponent(_)}`,"_blank")},()=>{alert("Please enable location access to notify the owner with your position.");const b=g==="emergency"?"🚨 EMERGENCY ALERT! Someone scanned your Tarkshya QR and reported an accident.":"🚗 PARKING ALERT! Please move your vehicle. Someone is waiting.";window.open(`https://wa.me/${v}?text=${encodeURIComponent(b)}`,"_blank")})};return l.jsxs(Qe,{bg:"light",style:{minHeight:"100vh"},children:[l.jsx("div",{style:{textAlign:"right",padding:"10px 20px"},children:l.jsx("button",{onClick:()=>p(f==="en"?"hi":"en"),style:{background:"white",border:"1px solid #ddd",padding:"5px 12px",borderRadius:"20px",cursor:"pointer",fontWeight:600},children:f==="en"?"हिन्दी":"English"})}),l.jsxs(US,{children:[l.jsxs(BS,{children:[l.jsx("img",{src:"/new_logo.png",alt:"Tarkshya"}),l.jsx("h1",{children:u?h.title:"Vikas Kumar - Vehicle Profile"}),l.jsx("p",{children:u?h.privacyMsg:h.standardMsg})]}),i?l.jsxs(qS,{children:[i==="emergency"&&l.jsxs(l.Fragment,{children:[l.jsx(dd,{color:"#ff4444",size:48,style:{marginBottom:"20px"}}),l.jsx("h2",{children:h.emergency}),l.jsx("p",{children:h.alertSent}),l.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"15px"},children:[l.jsxs(qe,{variant:"danger",style:{width:"100%",background:"#d32f2f"},onClick:()=>x("emergency"),children:[l.jsx(Ag,{size:18,style:{marginRight:"10px"}})," ",h.shareLocation]}),l.jsxs(qe,{variant:"outline",style:{width:"100%",color:"white",borderColor:"white"},children:[l.jsx(cd,{size:18,style:{marginRight:"10px"}})," ",h.virtualCall]})]})]}),i==="parking"&&l.jsxs(l.Fragment,{children:[l.jsx(Jl,{size:48,style:{marginBottom:"20px",color:"#C9A84C"}}),l.jsx("h2",{children:h.parking}),l.jsx("p",{children:h.alertSent}),l.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"15px"},children:[l.jsxs(qe,{style:{width:"100%"},onClick:()=>x("parking"),children:[l.jsx(u5,{size:18,style:{marginRight:"10px"}})," ",h.requestMove]}),l.jsxs(qe,{variant:"outline",style:{width:"100%",color:"white",borderColor:"white"},children:[l.jsx(cd,{size:18,style:{marginRight:"10px"}})," ",h.callPrivate]})]})]}),l.jsx(qe,{variant:"link",style:{marginTop:"30px",color:"rgba(255,255,255,0.6)"},onClick:()=>s(null),children:h.goBack}),l.jsxs(YS,{children:[l.jsx(Zt,{size:14})," ",h.privacyTag]})]}):l.jsxs(LS,{children:[l.jsxs(Zu,{type:"emergency",onClick:()=>s("emergency"),children:[l.jsx("div",{className:"icon-box",children:l.jsx(dd,{size:32})}),l.jsxs("div",{className:"content",children:[l.jsx("h3",{children:h.emergency}),l.jsx("p",{children:h.emergencyDesc})]})]}),l.jsxs(Zu,{type:"parking",onClick:()=>s("parking"),children:[l.jsx("div",{className:"icon-box",children:l.jsx(Jl,{size:32})}),l.jsxs("div",{className:"content",children:[l.jsx("h3",{children:h.parking}),l.jsx("p",{children:h.parkingDesc})]})]}),l.jsxs(Zu,{type:"info",onClick:()=>s("info"),children:[l.jsx("div",{className:"icon-box",children:l.jsx(Z2,{size:32})}),l.jsxs("div",{className:"content",children:[l.jsx("h3",{children:h.info}),l.jsx("p",{children:h.infoDesc})]})]})]}),l.jsx("div",{style:{textAlign:"center",marginTop:"40px"},children:l.jsxs("p",{style:{fontSize:"0.8rem",color:"#999"},children:["Powered by ",l.jsx("strong",{children:"Tarkshya Security Systems"}),l.jsx("br",{}),"Protecting assets, saving lives."]})})]})]})},qg=St`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`,Yg=St`
  0% { transform: translateY(0) rotate(0); }
  50% { transform: translateY(-10px) rotate(2deg); }
  100% { transform: translateY(0) rotate(0); }
`,QS=St`
  0% { box-shadow: 0 0 0 0 rgba(201, 168, 76, 0.4); }
  70% { box-shadow: 0 0 0 20px rgba(201, 168, 76, 0); }
  100% { box-shadow: 0 0 0 0 rgba(201, 168, 76, 0); }
`,VS=C.div`
  background: linear-gradient(135deg, #0b1a33 0%, #1a2a44 100%);
  padding: 160px 0 100px;
  color: white;
  text-align: center;
  position: relative;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    top: -50%; left: -50%; width: 200%; height: 200%;
    background: radial-gradient(circle at 50% 50%, rgba(201, 168, 76, 0.05) 0%, transparent 50%);
    animation: ${Yg} 20s linear infinite;
    pointer-events: none;
  }
`,XS=C.div`
  width: 120px;
  height: 120px;
  background: linear-gradient(135deg, rgba(201,168,76,0.2), rgba(201,168,76,0.05));
  backdrop-filter: blur(20px);
  border-radius: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 40px;
  color: #C9A84C;
  border: 1px solid rgba(201, 168, 76, 0.4);
  position: relative;
  animation: ${Yg} 6s ease-in-out infinite, ${QS} 3s infinite;
  transform: rotate(45deg);

  > * {
    transform: rotate(-45deg);
  }
`,KS=C.h1`
  font-size: 4.5rem;
  font-weight: 900;
  letter-spacing: -2px;
  margin-bottom: 20px;
  line-height: 1.1;
  background: linear-gradient(to right, #ffffff, #e0e0e0);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: ${qg} 0.8s ease-out;

  span {
    background: linear-gradient(to right, #C9A84C, #F2D06B);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }

  @media (max-width: 768px) { font-size: 3rem; }
`,ZS=C.p`
  max-width: 700px;
  margin: 20px auto 0;
  color: rgba(255,255,255,0.8);
  font-size: 1.25rem;
  line-height: 1.7;
  font-weight: 400;
  animation: ${qg} 1s ease-out 0.2s both;
`,WS=C.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 80px;
  align-items: flex-start;
  @media (min-width: 1024px) {
    grid-template-columns: 1.1fr 0.9fr;
  }
`,Ro=C.div`
  display: flex;
  overflow-x: auto;
  gap: 30px;
  padding: 20px 0 40px;
  scrollbar-width: none;
  &::-webkit-scrollbar { display: none; }
  scroll-behavior: smooth;
  
  & > * {
    flex: 0 0 350px;
  }

  @media (max-width: 768px) {
    & > * {
      flex: 0 0 280px;
    }
  }
`,_o=C.div`
  position: relative;
  padding: 0 10px;
  
  .nav-btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    width: 35px;
    height: 35px;
    background: white;
    border: 1px solid #ddd;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    z-index: 10;
    box-shadow: 0 2px 8px rgba(0,0,0,0.15);
    color: #333;
    transition: all 0.3s ease;

    &:hover {
      background: #f8f8f8;
      transform: translateY(-50%) scale(1.1);
    }

    &.prev { left: -15px; }
    &.next { right: -15px; }

    @media (max-width: 1024px) {
       display: none;
    }
  }
`,Wu=C.div`
  background: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 4px 15px rgba(0,0,0,0.06);
  transition: all 0.3s ease;
  height: 100%;
  display: flex;
  flex-direction: column;
  border: 1px solid #f0f0f0;

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
  }

  .img-wrapper {
    height: 200px;
    background: #f8f9fa;
    img { width: 100%; height: 100%; object-fit: cover; }
  }

  .content {
    padding: 20px;
    text-align: left;
    h4 { font-size: 1.1rem; font-weight: 800; color: #000; margin-bottom: 10px; text-transform: uppercase; }
    p { font-size: 0.9rem; color: #666; line-height: 1.5; margin: 0; }
  }
`,JS=C.div`
  background: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 4px 15px rgba(0,0,0,0.06);
  transition: all 0.3s ease;
  border: 1px solid #f0f0f0;
  display: flex;
  flex-direction: column;
  position: relative;
  padding: 20px;

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
  }
`,FS=C.div`
  position: relative;
  height: 200px;
  background: #f8f9fa;
  margin-bottom: 15px;
  display: flex;
  align-items: center;
  justify-content: center;

  img {
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
  }
`,IS=C.div`
  background: #B51B2E;
  color: white;
  font-weight: 700;
  font-size: 0.7rem;
  padding: 4px 8px;
  position: absolute;
  top: 10px;
  left: 10px;
  text-transform: uppercase;
  z-index: 2;
`,PS=C.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
  padding: 10px 0;
`,e4=C.span`
  background: #004085;
  color: white;
  padding: 6px 10px;
  border-radius: 4px;
  font-size: 0.7rem;
  font-weight: 700;
  text-transform: uppercase;
  text-align: center;
  display: flex;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`,t4=C.div`
  h4 {
    margin: 10px 0;
    font-size: 1.1rem;
    font-weight: 800;
    color: #000;
    text-transform: uppercase;
  }
`,a4=C.div`
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 5px;
  .current { font-size: 1.5rem; font-weight: 900; color: #B51B2E; }
  .old { font-size: 0.9rem; color: #999; text-decoration: line-through; }
`,n4=C.div`
  color: #27ae60;
  font-weight: 700;
  font-size: 0.8rem;
  text-transform: uppercase;
  margin-bottom: 15px;
`,i4=C.div`
  display: flex;
  gap: 10px;
  margin-top: auto;
  
  .view-btn {
    flex: 1;
    background: #B51B2E;
    color: white;
    text-align: center;
    padding: 12px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: 800;
    text-transform: uppercase;
    font-size: 0.85rem;
    transition: all 0.3s;
    &:hover { background: #941525; }
  }
  
  .cart-btn {
    width: 48px;
    height: 48px;
    background: #B51B2E;
    color: white;
    border: none;
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s;
    &:hover { background: #941525; }
  }
`,Mo=C.div`
  text-align: left;
  margin-bottom: 40px;
  max-width: 1400px;
  margin-left: auto;
  margin-right: auto;

  h2 {
    font-size: 2rem;
    font-weight: 900;
    color: #000;
    margin-bottom: 15px;
    letter-spacing: -0.5px;
    display: flex;
    align-items: center;
    gap: 15px;
    text-transform: uppercase;
    
    &::before {
      content: '';
      width: 5px;
      height: 32px;
      background: #B51B2E;
      border-radius: 1px;
    }
  }
  
  p {
    max-width: 900px;
    color: #444;
    font-size: 1rem;
    line-height: 1.6;
    margin: 0;
  }
`,l4=C.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 40px;
  align-items: center;
  max-width: 1400px;
  margin: 0 auto;
  padding: 40px 0;

  @media (min-width: 1024px) {
    grid-template-columns: 1.2fr 0.8fr;
  }

  .video-box {
    position: relative;
    border-radius: 12px;
    overflow: hidden;
    aspect-ratio: 16/9;
    background: #000;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    
    img { width: 100%; height: 100%; object-fit: cover; opacity: 0.8; }
    
    .play-btn {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 80px;
      height: 80px;
      background: #B51B2E;
      color: white;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      box-shadow: 0 0 20px rgba(181, 27, 46, 0.4);
    }
  }

  .content-box {
    h3 { font-size: 2.2rem; font-weight: 900; color: #B51B2E; margin-bottom: 20px; text-transform: uppercase; }
    p { font-size: 1.1rem; line-height: 1.8; color: #333; margin-bottom: 30px; }
  }
`,r4=C.div`
  display: flex;
  overflow-x: auto;
  gap: 25px;
  padding: 10px 0 40px;
  scrollbar-width: none;
  &::-webkit-scrollbar { display: none; }
  scroll-behavior: smooth;
  
  & > * {
    flex: 0 0 320px;
  }

  @media (max-width: 768px) {
    & > * {
      flex: 0 0 280px;
    }
  }
`,o4=C.div`
  background: linear-gradient(135deg, #0b1a33, #1a2a44);
  color: white;
  padding: 40px;
  border-radius: 32px;
  margin-top: 50px;
  position: relative;
  overflow: hidden;
  box-shadow: 0 30px 60px rgba(11, 26, 51, 0.2);

  h3 { 
    font-size: 1.5rem; 
    font-weight: 900; 
    margin-bottom: 20px; 
    display: flex; 
    align-items: center; 
    gap: 12px;
    color: #C9A84C;
  }
  
  p { opacity: 0.8; line-height: 1.7; font-size: 1.05rem; }

  &::after {
    content: '';
    position: absolute;
    bottom: -20px; right: -20px;
    width: 200px; height: 200px;
    background: radial-gradient(circle, rgba(201, 168, 76, 0.15) 0%, transparent 70%);
  }
`,s4=C.div`
  position: sticky;
  top: 120px;
  .image-container {
    position: relative;
    padding: 20px;
    background: white;
    border-radius: 40px;
    box-shadow: 0 40px 80px rgba(0,0,0,0.08);
    
    img { 
      width: 100%; 
      border-radius: 25px; 
      display: block; 
      transition: transform 0.5s ease;
    }
  }

  .stats {
    display: flex;
    justify-content: space-around;
    margin-top: 30px;
    background: white;
    padding: 30px;
    border-radius: 24px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.05);
    text-align: center;
    border: 1px solid rgba(0,0,0,0.02);
    
    .stat-item {
      .value { font-size: 1.8rem; font-weight: 900; color: #0b1a33; margin-bottom: 5px; }
      .label { font-size: 0.75rem; font-weight: 800; color: #999; text-transform: uppercase; letter-spacing: 1px; }
    }
  }
`,c4=i=>({ShieldAlert:l.jsx(Ng,{size:50}),AlertTriangle:l.jsx(dd,{size:50}),Users:l.jsx(Rd,{size:50}),Scan:l.jsx(ud,{size:50}),Zap:l.jsx(_d,{size:50}),Bell:l.jsx(es,{size:50}),ShieldCheck:l.jsx(Zt,{size:50}),Activity:l.jsx(Xl,{size:50}),Smartphone:l.jsx(ts,{size:50}),Lock:l.jsx(qi,{size:50})})[i]||l.jsx(Xt,{size:50}),u4=()=>{const{language:i}=as(),s=ns[i].categoryDetails,{id:u}=xd(),[c,f]=A.useState(null),[p,h]=A.useState(!0),v=window.location.hostname==="localhost"?"http://localhost:5001":"",x={prevention:Ve.useRef(null),emergency:Ve.useRef(null),tracking:Ve.useRef(null),products:Ve.useRef(null)},g=(y,k)=>{y.current&&y.current.scrollBy({left:k==="next"?400:-400,behavior:"smooth"})};if(A.useEffect(()=>{(async()=>{try{const D=(await ta.get("/categories")).data?.categories?.find(_=>_.id===u);D&&(D.features=typeof D.features=="string"?JSON.parse(D.features||"[]"):D.features||[],D.preventionCards=typeof D.preventionCards=="string"?JSON.parse(D.preventionCards||"[]"):D.preventionCards||[],D.emergencyCards=typeof D.emergencyCards=="string"?JSON.parse(D.emergencyCards||"[]"):D.emergencyCards||[],D.trackingCards=typeof D.trackingCards=="string"?JSON.parse(D.trackingCards||"[]"):D.trackingCards||[],f(D))}catch(k){console.error("Failed to fetch category details:",k)}finally{h(!1)}})()},[u]),p)return l.jsx("div",{style:{height:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"#0b1a33",color:"white"},children:l.jsxs("div",{style:{textAlign:"center"},children:[l.jsx(O2,{size:50,className:"animate-spin",color:"#C9A84C"}),l.jsx("p",{style:{marginTop:"25px",fontWeight:800,letterSpacing:"3px",fontSize:"1.2rem"},children:s.initializing})]})});if(!c)return l.jsx("div",{style:{padding:"150px 20px",textAlign:"center",fontSize:"1.5rem",fontWeight:800,color:"#0b1a33"},children:s.notFound});const b=y=>{if(!y)return"Category Details";const k=y.split(" ");return k.length===1?y:l.jsxs(l.Fragment,{children:[k.slice(0,-1).join(" ")," ",l.jsx("span",{children:k[k.length-1]})]})};return l.jsxs("div",{style:{background:"#fcfcfc"},children:[l.jsxs(VS,{children:[l.jsx(XS,{children:c4(c.icon)}),l.jsx(KS,{children:b(c.name)}),l.jsx(ZS,{children:i==="hi"&&c.description_hi||c.description})]}),c.preventionHeading&&l.jsxs(Qe,{bg:"transparent",children:[l.jsxs(Mo,{children:[l.jsx("h2",{children:b(i==="hi"&&c.preventionHeading_hi||c.preventionHeading)}),l.jsx("p",{children:i==="hi"&&c.preventionText_hi||c.preventionText})]}),l.jsxs(_o,{children:[l.jsx("button",{className:"nav-btn prev",onClick:()=>g(x.prevention,"prev"),children:l.jsx(Ln,{})}),l.jsx(Ro,{ref:x.prevention,children:c.preventionCards.map((y,k)=>l.jsxs(Wu,{children:[l.jsx("div",{className:"img-wrapper",children:l.jsx("img",{src:y.image?`${v}${y.image}`:"/assets/car_qr_tag_mockup_1776107740073.png",alt:y.title})}),l.jsxs("div",{className:"content",children:[l.jsx("h4",{children:i==="hi"&&y.title_hi||y.title}),l.jsx("p",{children:i==="hi"&&y.text_hi||y.text})]})]},k))}),l.jsx("button",{className:"nav-btn next",onClick:()=>g(x.prevention,"next"),children:l.jsx(hn,{})})]})]}),c.emergencyHeading&&l.jsxs(Qe,{bg:"#ffffff",children:[l.jsxs(Mo,{children:[l.jsx("h2",{children:b(i==="hi"&&c.emergencyHeading_hi||c.emergencyHeading)}),l.jsx("p",{children:i==="hi"&&c.emergencyText_hi||c.emergencyText})]}),l.jsxs(_o,{children:[l.jsx("button",{className:"nav-btn prev",onClick:()=>g(x.emergency,"prev"),children:l.jsx(Ln,{})}),l.jsx(Ro,{ref:x.emergency,children:c.emergencyCards.map((y,k)=>l.jsxs(Wu,{children:[l.jsx("div",{className:"img-wrapper",children:l.jsx("img",{src:y.image?`${v}${y.image}`:"/assets/car_qr_tag_mockup_1776107740073.png",alt:y.title})}),l.jsxs("div",{className:"content",children:[l.jsx("h4",{children:i==="hi"&&y.title_hi||y.title}),l.jsx("p",{children:i==="hi"&&y.text_hi||y.text})]})]},k))}),l.jsx("button",{className:"nav-btn next",onClick:()=>g(x.emergency,"next"),children:l.jsx(hn,{})})]})]}),(c.howItWorksHeading||c.howItWorksText)&&l.jsx(Qe,{bg:"#f8f9fa",children:l.jsxs(l4,{children:[l.jsxs("div",{className:"video-box",children:[l.jsx("img",{src:"/assets/car_qr_tag_mockup_1776107740073.png",alt:"How it works"}),l.jsx("div",{className:"play-btn",children:l.jsx(y5,{size:40,fill:"white"})})]}),l.jsxs("div",{className:"content-box",children:[l.jsx("h3",{children:i==="hi"&&c.howItWorksHeading_hi||c.howItWorksHeading}),l.jsx("p",{children:i==="hi"&&c.howItWorksText_hi||c.howItWorksText}),l.jsx(qe,{as:"a",href:"#",style:{background:"#B51B2E",borderColor:"#B51B2E"},children:"DISCOVER MORE"})]})]})}),c.trackingHeading&&l.jsxs(Qe,{bg:"#fdfdfd",children:[l.jsxs(Mo,{children:[l.jsx("h2",{children:b(i==="hi"&&c.trackingHeading_hi||c.trackingHeading)}),l.jsx("p",{children:i==="hi"&&c.trackingText_hi||c.trackingText})]}),l.jsxs(_o,{children:[l.jsx("button",{className:"nav-btn prev",onClick:()=>g(x.tracking,"prev"),children:l.jsx(Ln,{})}),l.jsx(Ro,{ref:x.tracking,children:c.trackingCards.map((y,k)=>l.jsxs(Wu,{children:[l.jsx("div",{className:"img-wrapper",children:l.jsx("img",{src:y.image?`${v}${y.image}`:"/assets/car_qr_tag_mockup_1776107740073.png",alt:y.title})}),l.jsxs("div",{className:"content",children:[l.jsx("h4",{children:i==="hi"&&y.title_hi||y.title}),l.jsx("p",{children:i==="hi"&&y.text_hi||y.text})]})]},k))}),l.jsx("button",{className:"nav-btn next",onClick:()=>g(x.tracking,"next"),children:l.jsx(hn,{})})]})]}),c.products&&c.products.length>0&&l.jsxs(Qe,{bg:"#fdfdfd",children:[l.jsxs(Mo,{children:[l.jsx("h2",{children:s.relatedProducts}),l.jsx("p",{children:s.productsDesc})]}),l.jsxs(_o,{children:[l.jsx("button",{className:"nav-btn prev",onClick:()=>g(x.products,"prev"),children:l.jsx(Ln,{})}),l.jsx(r4,{ref:x.products,children:c.products.map(y=>{const k=typeof y.photos=="string"?JSON.parse(y.photos||"[]"):y.photos||[],D=typeof y.dynamicData=="string"?JSON.parse(y.dynamicData||"[]"):y.dynamicData||[],_=k[0]?k[0].startsWith("http")?k[0]:`${v}${k[0]}`:"/assets/car_qr_tag_mockup_1776107740073.png";return l.jsxs(JS,{children:[l.jsxs(FS,{children:[l.jsx("img",{src:_,alt:y.name}),l.jsx(IS,{children:"Features"})]}),l.jsx(PS,{children:D.slice(0,4).map((q,Y)=>l.jsx(e4,{title:q.value,children:q.label},Y))}),l.jsx(t4,{children:l.jsx("h4",{children:i==="hi"&&y.name_hi||y.name})}),l.jsxs(a4,{children:[l.jsxs("span",{className:"current",children:["₹",y.mrp]}),l.jsxs("span",{className:"old",children:["₹",Math.round(y.mrp*1.5)]})]}),l.jsx(n4,{children:"40% OFF* (Pack of 3)"}),l.jsxs(i4,{children:[l.jsx(Ze,{to:`/product/${y.id}`,className:"view-btn",children:"View Details"}),l.jsx("button",{className:"cart-btn",title:"Add to Cart",children:l.jsx(er,{size:20})})]})]},y.id)})}),l.jsx("button",{className:"nav-btn next",onClick:()=>g(x.products,"next"),children:l.jsx(hn,{})})]})]}),l.jsx(Qe,{bg:"#ffffff",children:l.jsxs(WS,{children:[l.jsxs("div",{children:[l.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"15px",marginBottom:"25px"},children:[l.jsx("div",{style:{width:"40px",height:"3px",background:"#C9A84C",borderRadius:"2px"}}),l.jsx("span",{style:{fontSize:"0.9rem",fontWeight:900,color:"#C9A84C",letterSpacing:"0.2em",textTransform:"uppercase"},children:s.precisionSecurity})]}),l.jsxs("h2",{style:{fontSize:"3.2rem",fontWeight:900,color:"#0b1a33",marginBottom:"40px",letterSpacing:"-1.5px",lineHeight:1.1},children:[s.advancedProtocols.split(" ")[0]," ",l.jsx("span",{style:{color:"#C9A84C"},children:s.advancedProtocols.split(" ").slice(1).join(" ")})]}),l.jsx(Ro,{style:{marginTop:0},children:c.features.map((y,k)=>l.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"15px",background:"#f8f9fa",padding:"20px",borderRadius:"16px"},children:[l.jsx("div",{style:{color:"#C9A84C"},children:l.jsx(Zt,{size:24})}),l.jsx("h4",{style:{margin:0,fontWeight:700,color:"#0b1a33",fontSize:"1rem"},children:i==="hi"?y.name_hi||y.name||y:y.name||y})]},k))}),c.features.length===0&&l.jsx("p",{style:{color:"#777",padding:"30px",background:"#f8f9fa",borderRadius:"16px",borderLeft:"4px solid #C9A84C"},children:s.standardProtocols}),l.jsxs(o4,{children:[l.jsxs("h3",{children:[l.jsx(vg,{size:28})," ",s.strategicProtection]}),l.jsx("p",{children:i==="hi"&&c.benefits_hi||c.benefits})]})]}),l.jsxs(s4,{children:[l.jsxs("div",{className:"image-container",children:[l.jsx("img",{src:c.heroImage?`${v}${c.heroImage}`:"/assets/car_qr_tag_mockup_1776107740073.png",alt:c.name}),l.jsxs("div",{style:{position:"absolute",bottom:"30px",right:"-30px",background:"white",padding:"20px 30px",borderRadius:"20px",boxShadow:"0 20px 40px rgba(0,0,0,0.1)",display:"flex",alignItems:"center",gap:"15px"},children:[l.jsx("div",{style:{color:"#27ae60",background:"#eafaf1",padding:"10px",borderRadius:"12px"},children:l.jsx(jg,{size:28})}),l.jsxs("div",{children:[l.jsx("div",{style:{fontSize:"1rem",fontWeight:900,color:"#0b1a33"},children:s.verifiedSecurity}),l.jsx("div",{style:{fontSize:"0.7rem",color:"#888",fontWeight:800,marginTop:"2px"},children:s.certifiedHardware})]})]})]}),l.jsxs("div",{className:"stats",children:[l.jsxs("div",{className:"stat-item",children:[l.jsx("div",{className:"value",children:"99.9%"}),l.jsx("div",{className:"label",children:s.stats.scanRate})]}),l.jsxs("div",{className:"stat-item",children:[l.jsx("div",{className:"value",children:"<2s"}),l.jsx("div",{className:"label",children:s.stats.alertSpeed})]}),l.jsxs("div",{className:"stat-item",children:[l.jsx("div",{className:"value",children:"AES-256"}),l.jsx("div",{className:"label",children:s.stats.encryption})]})]})]})]})})]})},$g=St`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`,d4=St`
  0% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
  100% { transform: translateY(0); }
`,f4=C.div`
  background: linear-gradient(135deg, #0b1a33 0%, #1a2a44 100%);
  padding: 60px 0 100px;
  color: white;
  position: relative;
  overflow: hidden;

  &::before {
    content: '';
    position: absolute;
    top: -50%; left: -50%; width: 200%; height: 200%;
    background: radial-gradient(circle at 50% 50%, rgba(201, 168, 76, 0.05) 0%, transparent 50%);
    animation: ${d4} 20s linear infinite;
    pointer-events: none;
  }
`,h4=C.div`
  margin-bottom: 40px;
  font-size: 0.85rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  color: rgba(255,255,255,0.6);
  position: relative;
  z-index: 10;
  
  a { 
    color: white; 
    text-decoration: none; 
    transition: color 0.3s;
    &:hover { color: #C9A84C; }
  }
`,p4=C.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 60px;
  align-items: start;
  position: relative;
  z-index: 10;

  @media (min-width: 1024px) {
    grid-template-columns: 1fr 1fr;
  }
`,m4=C.div`
  animation: ${$g} 0.8s ease-out;

  .main-img-wrapper {
    position: relative;
    border-radius: 32px;
    background: white;
    padding: 30px;
    box-shadow: 0 40px 80px rgba(0,0,0,0.2);
    margin-bottom: 25px;

    &::after {
      content: '';
      position: absolute;
      top: 0; left: 0; width: 100%; height: 100%;
      border-radius: 32px;
      box-shadow: inset 0 0 0 1px rgba(0,0,0,0.05);
      pointer-events: none;
    }
  }

  .main-img {
    width: 100%;
    height: 400px;
    object-fit: contain;
    transition: transform 0.5s ease;
    &:hover { transform: scale(1.05); }
  }

  .thumbs {
    display: flex;
    gap: 15px;
    overflow-x: auto;
    padding-bottom: 10px;

    img {
      width: 90px;
      height: 90px;
      object-fit: cover;
      border-radius: 16px;
      border: 2px solid transparent;
      background: rgba(255,255,255,0.1);
      cursor: pointer;
      transition: all 0.3s ease;

      &:hover {
        border-color: #C9A84C;
        transform: translateY(-5px);
      }
    }
  }
`,g4=C.div`
  animation: ${$g} 0.8s ease-out 0.2s both;

  .badge {
    display: inline-block;
    background: rgba(201, 168, 76, 0.2);
    color: #C9A84C;
    padding: 8px 16px;
    border-radius: 100px;
    font-size: 0.8rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 20px;
  }

  h1 { 
    font-size: 3.5rem; 
    color: white; 
    font-weight: 900; 
    margin-bottom: 15px; 
    line-height: 1.1;
    letter-spacing: -1px;
  }

  .reviews {
    display: flex;
    align-items: center;
    gap: 10px;
    color: rgba(255,255,255,0.8);
    font-size: 0.9rem;
    margin-bottom: 30px;
    .stars { color: #C9A84C; display: flex; gap: 2px; }
  }

  .price-card {
    background: rgba(255,255,255,0.03);
    backdrop-filter: blur(20px);
    padding: 35px;
    border-radius: 28px;
    border: 1px solid rgba(255,255,255,0.05);
    margin-bottom: 30px;
  }
`,x4=C.div`
  display: flex;
  align-items: baseline;
  gap: 20px;
  margin-bottom: 20px;
  
  .current { 
    font-size: 3rem; 
    font-weight: 900; 
    color: white; 
  }
  .old { 
    font-size: 1.4rem; 
    color: rgba(255,255,255,0.4); 
    text-decoration: line-through; 
  }
  .discount { 
    background: #27ae60;
    color: white;
    padding: 6px 12px;
    border-radius: 8px;
    font-weight: 800; 
    font-size: 0.9rem;
  }
`,y4=C.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 15px;
  margin-bottom: 30px;
  padding-top: 25px;
  border-top: 1px solid rgba(255,255,255,0.1);

  .spec-item {
    display: flex;
    align-items: center;
    gap: 10px;
    color: white;

    .icon {
      color: #C9A84C;
    }
    .text {
      display: flex;
      flex-direction: column;
      .label { font-size: 0.75rem; color: rgba(255,255,255,0.5); text-transform: uppercase; font-weight: 700; }
      .value { font-size: 1rem; font-weight: 800; }
    }
  }
`,b4=C.div`
  background: #fcfcfc;
  padding: 80px 0;
`,v4=C.div`
  max-width: 1000px;
  margin: 0 auto;

  .tabs {
    display: flex;
    gap: 40px;
    border-bottom: 2px solid rgba(0,0,0,0.05);
    margin-bottom: 50px;
    justify-content: center;

    button {
      background: none;
      border: none;
      padding: 20px 0;
      font-size: 1.2rem;
      font-weight: 900;
      color: #999;
      cursor: pointer;
      position: relative;
      text-transform: uppercase;
      letter-spacing: 1px;
      transition: color 0.3s;

      &:hover { color: #0b1a33; }

      &.active {
        color: #0b1a33;
        &::after {
          content: '';
          position: absolute;
          bottom: -2px;
          left: 0;
          right: 0;
          height: 3px;
          background: #C9A84C;
          border-radius: 3px 3px 0 0;
        }
      }
    }
  }
`,j4=C.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 30px;

  .feature-card {
    background: white;
    padding: 30px;
    border-radius: 20px;
    border: 1px solid rgba(0,0,0,0.03);
    box-shadow: 0 10px 30px rgba(0,0,0,0.02);
    display: flex;
    align-items: flex-start;
    gap: 15px;

    .icon-box {
      width: 48px;
      height: 48px;
      background: #f8f9fa;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #C9A84C;
      flex-shrink: 0;
    }

    h4 { font-size: 1.1rem; font-weight: 800; color: #0b1a33; margin-bottom: 5px; }
    p { font-size: 0.95rem; color: #666; line-height: 1.5; }
  }
`,S4=()=>{const{language:i}=as(),s=ns[i].productDetails,{id:u}=xd(),{addToCart:c}=tr(),[f,p]=A.useState("features"),[h,v]=A.useState(null),[x,g]=A.useState(!0),[b,y]=A.useState(""),k=()=>{if(!localStorage.getItem("admin_token")){na.error("Please login to add items to your cart.",{icon:"🔒",style:{borderRadius:"100px",background:"#0b1a33",color:"#fff"}}),window.location.href="/login?redirect=/product/"+u;return}h&&(c(h),na.success(i==="hi"?`${i==="hi"&&h.name_hi||h.name} कार्ट में जोड़ा गया!`:`${h.name} added to cart!`,{icon:"🛒",style:{borderRadius:"100px",background:"#0b1a33",color:"#fff"}}))};if(A.useEffect(()=>{y(window.location.hostname==="localhost"?"http://localhost:5001":""),(async()=>{try{const Y=(await ta.get(`/products/${u}`)).data?.product;Y&&(Y.photos=typeof Y.photos=="string"?JSON.parse(Y.photos||"[]"):Y.photos||[],Y.dynamicData=typeof Y.dynamicData=="string"?JSON.parse(Y.dynamicData||"[]"):Y.dynamicData||[],v(Y))}catch(q){console.error("Failed to fetch product details:",q)}finally{g(!1)}})()},[u]),x)return l.jsx("div",{style:{height:"80vh",display:"flex",alignItems:"center",justifyContent:"center",background:"#0b1a33",color:"white"},children:l.jsxs("div",{style:{textAlign:"center"},children:[l.jsx(Xl,{size:50,className:"animate-pulse",color:"#C9A84C"}),l.jsx("p",{style:{marginTop:"25px",fontWeight:800,letterSpacing:"3px",fontSize:"1.2rem",textTransform:"uppercase"},children:s.initializing})]})});if(!h)return l.jsx("div",{style:{padding:"150px 20px",textAlign:"center",fontSize:"1.5rem",fontWeight:800,color:"#0b1a33"},children:s.notFound});const D=()=>"https://img.icons8.com/fluency/400/security-checked.png";return l.jsxs(l.Fragment,{children:[l.jsx(f4,{children:l.jsxs(Qe,{bg:"transparent",children:[l.jsxs(h4,{children:[l.jsx(Ze,{to:"/",children:"Ecosystem"})," / ",l.jsx(Ze,{to:"/products",children:"Hardware"})," / ",l.jsx("span",{style:{color:"#C9A84C"},children:i==="hi"&&h.name_hi||h.name})]}),l.jsxs(p4,{children:[l.jsxs(m4,{children:[l.jsx("div",{className:"main-img-wrapper",children:(()=>{let _=h.photos[0]?h.photos[0].startsWith("http")?h.photos[0]:`${b}${h.photos[0]}`:D();return _.includes("images.icons8.com")&&(_=_.replace("images.icons8.com","img.icons8.com").replace("/bubbles/","/fluency/")),l.jsx("img",{src:_,alt:h.name,className:"main-img"})})()}),l.jsx("div",{className:"thumbs",children:h.photos.filter(_=>_).length>0?h.photos.filter(_=>_).map((_,q)=>{let Y=_.startsWith("http")?_:`${b}${_}`;return Y.includes("images.icons8.com")&&(Y=Y.replace("images.icons8.com","img.icons8.com").replace("/bubbles/","/fluency/")),l.jsx("img",{src:Y,alt:"thumb"},q)}):l.jsx("img",{src:D(),alt:"thumb fallback"})})]}),l.jsxs(g4,{children:[l.jsx("div",{className:"badge",children:s.badge}),l.jsx("h1",{children:i==="hi"&&h.name_hi||h.name}),l.jsxs("div",{className:"reviews",children:[l.jsxs("div",{className:"stars",children:[l.jsx(Ll,{fill:"#C9A84C",size:16}),l.jsx(Ll,{fill:"#C9A84C",size:16}),l.jsx(Ll,{fill:"#C9A84C",size:16}),l.jsx(Ll,{fill:"#C9A84C",size:16}),l.jsx(Ll,{fill:"#C9A84C",size:16})]}),l.jsx("span",{children:"4.9/5 (128+ Verifications)"})]}),l.jsxs("div",{className:"price-card",children:[l.jsxs(x4,{children:[l.jsxs("span",{className:"current",children:["₹",h.mrp||0]}),l.jsxs("span",{className:"old",children:["₹",Math.round((h.mrp||0)*1.5)]}),l.jsx("span",{className:"discount",children:i==="hi"?"विशेष ऑफर":"SPECIAL OFFER"})]}),l.jsxs(y4,{children:[h.dynamicData.slice(0,4).map((_,q)=>l.jsxs("div",{className:"spec-item",children:[l.jsx(Zt,{size:24,className:"icon"}),l.jsxs("div",{className:"text",children:[l.jsx("span",{className:"label",children:i==="hi"&&_.label_hi||_.label}),l.jsx("span",{className:"value",children:i==="hi"&&_.value_hi||_.value})]})]},q)),h.dynamicData.length===0&&l.jsxs(l.Fragment,{children:[l.jsxs("div",{className:"spec-item",children:[l.jsx(Zt,{size:24,className:"icon"}),l.jsxs("div",{className:"text",children:[l.jsx("span",{className:"label",children:s.encryption}),l.jsx("span",{className:"value",children:"AES-256"})]})]}),l.jsxs("div",{className:"spec-item",children:[l.jsx(Xl,{size:24,className:"icon"}),l.jsxs("div",{className:"text",children:[l.jsx("span",{className:"label",children:s.delivery}),l.jsx("span",{className:"value",children:"24h"})]})]})]})]}),l.jsxs(qe,{size:"large",style:{width:"100%",height:"60px",fontSize:"1.2rem",borderRadius:"16px",boxShadow:"0 20px 40px rgba(201, 168, 76, 0.3)"},onClick:k,children:[s.addToCart," ",l.jsx(er,{size:24,style:{marginLeft:"12px"}})]})]}),l.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"10px",color:"rgba(255,255,255,0.5)",fontSize:"0.9rem",fontWeight:600},children:[l.jsx(Xt,{size:18})," Verified V-KAWACH Security Hardware. Ships in 24 Hours."]})]})]})]})}),l.jsx(b4,{children:l.jsx(Qe,{bg:"transparent",children:l.jsxs(v4,{children:[l.jsxs("div",{className:"tabs",children:[l.jsx("button",{className:f==="features"?"active":"",onClick:()=>p("features"),children:s.keyFeatures}),l.jsx("button",{className:f==="description"?"active":"",onClick:()=>p("description"),children:s.description})]}),f==="description"&&l.jsxs("div",{style:{background:"white",padding:"50px",borderRadius:"24px",boxShadow:"0 20px 40px rgba(0,0,0,0.02)",border:"1px solid rgba(0,0,0,0.03)"},children:[l.jsx("h3",{style:{fontSize:"1.8rem",color:"#0b1a33",fontWeight:900,marginBottom:"20px"},children:"Ecosystem Integration"}),l.jsx("p",{style:{lineHeight:1.8,color:"#555",fontSize:"1.15rem"},children:h.description||"This advanced V-KAWACH security module integrates seamlessly into your digital ecosystem. Designed with military-grade precision, it provides instant verification and tracking capabilities to ensure maximum safety for your assets and loved ones."}),l.jsxs("div",{style:{marginTop:"30px",display:"flex",gap:"20px",flexWrap:"wrap"},children:[l.jsxs("div",{style:{background:"#f8f9fa",padding:"15px 25px",borderRadius:"12px",fontWeight:700,color:"#0b1a33"},children:[l.jsx(vg,{size:18,style:{display:"inline",marginRight:"10px",color:"#C9A84C"}})," ISO Certified"]}),l.jsxs("div",{style:{background:"#f8f9fa",padding:"15px 25px",borderRadius:"12px",fontWeight:700,color:"#0b1a33"},children:[l.jsx(ts,{size:18,style:{display:"inline",marginRight:"10px",color:"#C9A84C"}})," App Compatible"]})]})]}),f==="features"&&l.jsxs(j4,{children:[h.dynamicData.map((_,q)=>l.jsxs("div",{className:"feature-card",children:[l.jsx("div",{className:"icon-box",children:l.jsx(_d,{size:24})}),l.jsxs("div",{children:[l.jsx("h4",{children:i==="hi"&&_.label_hi||_.label}),l.jsx("p",{children:i==="hi"&&_.value_hi||_.value})]})]},q)),h.dynamicData.length===0&&l.jsxs(l.Fragment,{children:[l.jsxs("div",{className:"feature-card",children:[l.jsx("div",{className:"icon-box",children:l.jsx(Zt,{size:24})}),l.jsxs("div",{children:[l.jsx("h4",{children:"Smart QR Protocol"}),l.jsx("p",{children:"High-quality smart sticker with instant scan detection."})]})]}),l.jsxs("div",{className:"feature-card",children:[l.jsx("div",{className:"icon-box",children:l.jsx(qi,{size:24})}),l.jsxs("div",{children:[l.jsx("h4",{children:"Privacy Masking"}),l.jsx("p",{children:"Call and message masking to protect your personal details."})]})]}),l.jsxs("div",{className:"feature-card",children:[l.jsx("div",{className:"icon-box",children:l.jsx(Xl,{size:24})}),l.jsxs("div",{children:[l.jsx("h4",{children:"Live Notifications"}),l.jsx("p",{children:"Real-time alerts directly to your mobile ecosystem."})]})]})]})]})]})})})]})};function w4(){const{pathname:i}=Ua();return A.useEffect(()=>{window.scrollTo(0,0)},[i]),null}const Od=St`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`,Tm=C.div`
  padding: 120px 0 80px;
  min-height: 90vh;
  background: #f8f9fa;
  background-image: radial-gradient(circle at 10% 20%, rgba(11, 26, 51, 0.03) 0%, transparent 80%);
`,C4=C.div`
  margin-bottom: 50px;
  animation: ${Od} 0.6s ease-out;
  h1 { 
    font-size: 3rem; 
    font-weight: 900; 
    color: #0b1a33; 
    margin-bottom: 10px;
    letter-spacing: -1px;
  }
  .breadcrumb {
    display: flex;
    gap: 10px;
    color: #999;
    font-size: 0.9rem;
    font-weight: 600;
    span.active { color: #C9A84C; }
  }
`,A4=C.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 50px;
  animation: ${Od} 0.8s ease-out;
  @media (min-width: 1024px) {
    grid-template-columns: 1.8fr 1fr;
  }
`,z4=C.div`
  background: white;
  border-radius: 32px;
  overflow: hidden;
  box-shadow: 0 10px 40px rgba(0,0,0,0.03);
  border: 1px solid rgba(0,0,0,0.04);
`,E4=C.div`
  display: flex;
  align-items: center;
  gap: 30px;
  padding: 40px;
  border-bottom: 1px solid rgba(0,0,0,0.03);
  transition: all 0.3s ease;
  &:last-child { border-bottom: none; }
  &:hover { background: #fafbfc; }

  .img-box {
    width: 140px;
    height: 140px;
    background: white;
    border-radius: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(0,0,0,0.04);
    img { width: 100%; height: 100%; object-fit: cover; }
  }

  .info {
    flex: 1;
    h4 { margin: 0 0 12px; color: #0b1a33; font-size: 1.4rem; font-weight: 800; letter-spacing: -0.5px; }
    .badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 0.75rem;
      background: rgba(39, 174, 96, 0.1);
      color: #27ae60;
      padding: 6px 12px;
      border-radius: 100px;
      font-weight: 800;
      letter-spacing: 0.5px;
    }
  }

  .qty-control {
    display: flex;
    align-items: center;
    gap: 15px;
    background: #f1f3f5;
    padding: 10px 20px;
    border-radius: 100px;
    
    button {
      background: white;
      border: none;
      color: #0b1a33;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 28px;
      height: 28px;
      border-radius: 50%;
      box-shadow: 0 2px 5px rgba(0,0,0,0.05);
      &:hover { color: #C9A84C; transform: scale(1.1); }
      &:disabled { opacity: 0.3; cursor: not-allowed; transform: none; }
    }
    
    span { font-weight: 900; min-width: 30px; text-align: center; font-size: 1.1rem; }
  }

  .price { 
    font-weight: 900; 
    color: #0b1a33; 
    font-size: 1.5rem; 
    text-align: right;
    min-width: 120px;
  }

  .remove {
    background: transparent;
    color: #ff4d4d;
    border: 2px solid #ffe5e5;
    width: 45px;
    height: 45px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    margin-left: 10px;
    &:hover { background: #ff4d4d; color: white; border-color: #ff4d4d; transform: scale(1.05) rotate(5deg); }
  }

  @media (max-width: 768px) {
    flex-wrap: wrap;
    padding: 25px;
    .img-box { width: 100px; height: 100px; }
    .info { min-width: 150px; }
    .qty-control { margin-right: auto; }
  }
`,T4=C.div`
  background: linear-gradient(145deg, #0b1a33 0%, #112240 100%);
  border-radius: 32px;
  padding: 45px;
  height: fit-content;
  color: white;
  position: sticky;
  top: 120px;
  box-shadow: 0 30px 60px rgba(11, 26, 51, 0.2);
  border: 1px solid rgba(255,255,255,0.05);
  
  h3 { 
    margin-bottom: 35px; 
    color: white; 
    font-size: 1.6rem; 
    font-weight: 900;
    display: flex;
    align-items: center;
    gap: 12px;
    letter-spacing: -0.5px;
  }
  
  .row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 22px;
    font-weight: 600;
    font-size: 1.05rem;
    color: rgba(255,255,255,0.7);
    
    &.total {
      margin-top: 35px;
      padding-top: 35px;
      border-top: 1px dashed rgba(255,255,255,0.2);
      color: #C9A84C;
      font-weight: 900;
      font-size: 2rem;
      align-items: center;
    }
  }

  .protection {
    margin-top: 40px;
    background: rgba(0,0,0,0.2);
    padding: 25px;
    border-radius: 24px;
    display: flex;
    gap: 15px;
    align-items: center;
    font-size: 0.85rem;
    line-height: 1.5;
    color: rgba(255,255,255,0.6);
    border: 1px solid rgba(255,255,255,0.03);
    svg { flex-shrink: 0; color: #C9A84C; }
  }
`,N4=C.div`
  text-align: center;
  padding: 100px 20px;
  max-width: 600px;
  margin: 0 auto;
  animation: ${Od} 0.8s ease-out;

  .icon-glow {
    width: 150px;
    height: 150px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 40px;
    color: #C9A84C;
    position: relative;
    box-shadow: 0 20px 40px rgba(0,0,0,0.05);
    &::after {
      content: '';
      position: absolute;
      width: 100%; height: 100%;
      border: 2px dashed #C9A84C;
      border-radius: 50%;
      animation: rotate 20s linear infinite;
    }
  }

  @keyframes rotate { from { transform: rotate(0); } to { transform: rotate(360deg); } }

  h2 { font-size: 2.5rem; font-weight: 900; color: #0b1a33; margin-bottom: 15px; }
  p { color: #666; font-size: 1.1rem; line-height: 1.6; margin-bottom: 40px; }
`,k4=()=>{const{cart:i,removeFromCart:s,updateQuantity:u,cartTotal:c,clearCart:f}=tr(),p=gn(),h=window.location.hostname==="localhost"?"http://localhost:5001":"",v=()=>{p("/checkout")};return i.length===0?l.jsx(Tm,{children:l.jsxs(N4,{children:[l.jsx("div",{className:"icon-glow",children:l.jsx(Yo,{size:60})}),l.jsx("h2",{children:"Your Cart is Empty"}),l.jsx("p",{children:"It looks like you haven't added any Smart Safety IDs to your cart yet. Protect your world today."}),l.jsx(qe,{as:Ze,to:"/",size:"large",children:"EXPLORE SMART TAGS"})]})}):l.jsx(Tm,{children:l.jsxs(Qe,{children:[l.jsxs(C4,{children:[l.jsxs("div",{className:"breadcrumb",children:["SHOPPING ",l.jsx("span",{children:"/"})," ",l.jsx("span",{className:"active",children:"CART"})]}),l.jsx("h1",{children:"Shopping Cart"})]}),l.jsxs(A4,{children:[l.jsx(z4,{children:i.map(x=>l.jsxs(E4,{children:[l.jsx("div",{className:"img-box",children:l.jsx("img",{src:x.image?`${h}${x.image}`:"/assets/car_qr_tag_mockup_1776107740073.png",alt:x.name})}),l.jsxs("div",{className:"info",children:[l.jsx("h4",{children:x.name}),l.jsxs("div",{className:"badge",children:[l.jsx(Zt,{size:14})," SECURE QR ID"]})]}),l.jsxs("div",{className:"qty-control",children:[l.jsx("button",{onClick:()=>u(x.productId,x.quantity-1),disabled:x.quantity<=1,children:l.jsx(f5,{size:18})}),l.jsx("span",{children:x.quantity}),l.jsx("button",{onClick:()=>u(x.productId,x.quantity+1),children:l.jsx(v5,{size:18})})]}),l.jsxs("div",{className:"price",children:["₹",x.price*x.quantity]}),l.jsx("button",{className:"remove",onClick:()=>s(x.productId),children:l.jsx(Y5,{size:18})})]},x.productId))}),l.jsxs(T4,{children:[l.jsxs("h3",{children:[l.jsx(er,{})," Order Summary"]}),l.jsxs("div",{className:"row",children:[l.jsx("span",{children:"Subtotal"}),l.jsxs("span",{children:["₹",c]})]}),l.jsxs("div",{className:"row",children:[l.jsx("span",{children:"Shipping"}),l.jsx("span",{style:{color:"#C9A84C"},children:"FREE"})]}),l.jsxs("div",{className:"row",children:[l.jsx("span",{children:"Platform Fee"}),l.jsx("span",{children:"₹0.00"})]}),l.jsxs("div",{className:"row total",children:[l.jsx("span",{children:"Total"}),l.jsxs("span",{children:["₹",c]})]}),l.jsxs("button",{onClick:v,style:{width:"100%",marginTop:"35px",padding:"22px",fontSize:"1.1rem",borderRadius:"20px",background:"linear-gradient(135deg, #C9A84C 0%, #D4B86A 100%)",color:"#0b1a33",boxShadow:"0 15px 30px rgba(201,168,76,0.2)",border:"none",cursor:"pointer",display:"flex",justifyContent:"center",alignItems:"center",fontWeight:900,transition:"all 0.3s ease"},children:["PROCEED TO CHECKOUT ",l.jsx(m2,{size:22,style:{marginLeft:"12px"}})]}),l.jsxs("div",{className:"protection",children:[l.jsx(Zt,{size:40}),l.jsx("p",{children:"Your purchase is protected by Tarkshya Security Protocol. 100% data privacy guaranteed."})]})]})]})]})})},R4=St`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`,_4=C.div`
  padding: 120px 0 80px;
  background: #f8f9fa;
  min-height: 90vh;
  background-image: radial-gradient(circle at 90% 10%, rgba(201, 168, 76, 0.05) 0%, transparent 60%);
`,M4=C.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 50px;
  animation: ${R4} 0.6s ease-out;
  @media (min-width: 1024px) {
    grid-template-columns: 1.2fr 0.8fr;
  }
`,D4=C.div`
  background: white;
  padding: 40px;
  border-radius: 32px;
  box-shadow: 0 20px 50px rgba(0,0,0,0.05);
  border: 1px solid rgba(0,0,0,0.05);

  h2 { 
    font-size: 1.8rem; 
    font-weight: 900; 
    color: #0b1a33; 
    margin-bottom: 30px;
    display: flex;
    align-items: center;
    gap: 15px;
    letter-spacing: -0.5px;
  }
`,Ri=C.div`
  margin-bottom: 25px;
  label { 
    display: block; 
    margin-bottom: 8px; 
    font-weight: 800; 
    color: #0b1a33; 
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    opacity: 0.6;
  }
  input, textarea {
    width: 100%;
    padding: 15px 20px;
    border: 2px solid #f0f2f5;
    border-radius: 18px;
    font-family: inherit;
    font-size: 1rem;
    transition: all 0.3s ease;
    background: #f8f9fa;
    color: #0b1a33;
    font-weight: 600;
    &:focus {
      outline: none;
      border-color: #C9A84C;
      background: white;
      box-shadow: 0 10px 30px rgba(201, 168, 76, 0.1);
    }
    &::placeholder { color: #ccc; font-weight: 400; }
  }
`,O4=C.div`
  background: #0b1a33;
  padding: 45px;
  border-radius: 40px;
  color: white;
  height: fit-content;
  position: sticky;
  top: 120px;
  box-shadow: 0 40px 80px rgba(11, 26, 51, 0.3);

  h3 { 
    font-size: 1.8rem; 
    font-weight: 900; 
    margin-bottom: 35px;
    color: #C9A84C;
  }
`,H4=C.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 25px;
  padding-bottom: 15px;
  border-bottom: 1px solid rgba(255,255,255,0.05);
  .name { 
    font-weight: 700; 
    font-size: 1rem;
    span { opacity: 0.5; margin-left: 10px; font-weight: 400; }
  }
  .price { font-weight: 900; color: white; }
`,U4=C.div`
  margin-top: 35px;
  .row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 18px;
    opacity: 0.6;
    font-weight: 600;
    font-size: 0.95rem;
  }
  .grand-total {
    display: flex;
    justify-content: space-between;
    margin-top: 30px;
    padding-top: 30px;
    border-top: 1px solid rgba(255,255,255,0.1);
    font-size: 2.2rem;
    font-weight: 900;
    color: #C9A84C;
    letter-spacing: -1px;
  }
`,B4=C.div`
  margin-top: 40px;
  background: rgba(255,255,255,0.03);
  padding: 30px;
  border-radius: 24px;
  border: 1px solid rgba(201, 168, 76, 0.2);
  
  .title {
    display: flex;
    align-items: center;
    gap: 12px;
    font-weight: 900;
    margin-bottom: 12px;
    color: #C9A84C;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }
  p { font-size: 0.9rem; opacity: 0.5; line-height: 1.6; font-weight: 500; }
`,L4=()=>{const{cart:i,cartTotal:s,clearCart:u}=tr(),c=gn(),[f,p]=A.useState(!1),[h,v]=A.useState({name:"",email:"",phone:"",address:"",city:"",pincode:""});A.useEffect(()=>{const g=localStorage.getItem("admin_token"),b=localStorage.getItem("user_profile");if(!g){na.error("Please login to complete your purchase"),c("/login?redirect=checkout");return}if(b)try{const y=JSON.parse(b);v(k=>({...k,name:y.name||"",email:y.email||"",phone:y.phone||""}))}catch(y){console.error("Invalid user profile in localStorage",y)}},[c]);const x=async g=>{if(g&&g.preventDefault(),i.length!==0){p(!0);try{const b={customerName:h.name,customerEmail:h.email,customerPhone:h.phone,shippingAddress:`${h.address}, ${h.city} - ${h.pincode}`,items:i,totalAmount:s},y=await ta.post("/orders",b);y.data.success&&(u(),c(`/order-success/${y.data.order.orderNumber}`))}catch(b){console.error(b),na.error(b.response?.data?.error||"Failed to place order")}finally{p(!1)}}};return l.jsx(_4,{children:l.jsxs(Qe,{children:[l.jsx("div",{style:{marginBottom:"40px"},children:l.jsxs("button",{onClick:()=>c("/cart"),style:{background:"none",border:"none",color:"#0b1a33",display:"flex",alignItems:"center",gap:"8px",fontWeight:900,cursor:"pointer",opacity:.6},children:[l.jsx(bg,{size:20})," RETURN TO CART"]})}),l.jsxs(M4,{children:[l.jsx("div",{children:l.jsxs(D4,{children:[l.jsxs("h2",{children:[l.jsx(Q5,{size:32,color:"#C9A84C"})," Shipping Logistics"]}),l.jsxs("form",{onSubmit:x,children:[l.jsxs(Ri,{children:[l.jsx("label",{children:"Consignee Name"}),l.jsx("input",{required:!0,type:"text",placeholder:"Full name of recipient",value:h.name,onChange:g=>v({...h,name:g.target.value})})]}),l.jsxs("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"25px"},children:[l.jsxs(Ri,{children:[l.jsx("label",{children:"Digital Contact"}),l.jsx("input",{required:!0,type:"email",placeholder:"email@tarkshya.in",value:h.email,onChange:g=>v({...h,email:g.target.value})})]}),l.jsxs(Ri,{children:[l.jsx("label",{children:"Secure Phone"}),l.jsx("input",{required:!0,type:"tel",placeholder:"+91 00000 00000",value:h.phone,onChange:g=>v({...h,phone:g.target.value})})]})]}),l.jsxs(Ri,{children:[l.jsx("label",{children:"Destination Address"}),l.jsx("textarea",{required:!0,rows:4,placeholder:"Detailed building, street and landmark info",value:h.address,onChange:g=>v({...h,address:g.target.value})})]}),l.jsxs("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"25px"},children:[l.jsxs(Ri,{children:[l.jsx("label",{children:"Urban Center"}),l.jsx("input",{required:!0,type:"text",placeholder:"City / District",value:h.city,onChange:g=>v({...h,city:g.target.value})})]}),l.jsxs(Ri,{children:[l.jsx("label",{children:"Postal Zone"}),l.jsx("input",{required:!0,type:"text",placeholder:"6-digit PIN",value:h.pincode,onChange:g=>v({...h,pincode:g.target.value})})]})]})]})]})}),l.jsxs(O4,{children:[l.jsx("h3",{children:"Manifest Summary"}),i.map(g=>l.jsxs(H4,{children:[l.jsxs("div",{className:"name",children:[g.name," ",l.jsxs("span",{children:["x ",g.quantity]})]}),l.jsxs("div",{className:"price",children:["₹",g.price*g.quantity]})]},g.productId)),l.jsxs(U4,{children:[l.jsxs("div",{className:"row",children:[l.jsx("span",{children:"Items Subtotal"}),l.jsxs("span",{children:["₹",s]})]}),l.jsxs("div",{className:"row",children:[l.jsx("span",{children:"Secure Logistics"}),l.jsx("span",{style:{color:"#C9A84C"},children:"COMPLIMENTARY"})]}),l.jsxs("div",{className:"grand-total",children:[l.jsx("span",{children:"Total"}),l.jsxs("span",{children:["₹",s]})]})]}),l.jsxs(B4,{children:[l.jsxs("div",{className:"title",children:[l.jsx(U2,{size:20})," Verified COD"]}),l.jsx("p",{children:"Payment will be collected upon successful delivery of your Smart Safety IDs. No upfront payment required."})]}),l.jsxs(qe,{onClick:x,disabled:f||i.length===0,style:{width:"100%",marginTop:"45px",background:"#C9A84C",color:"#0b1a33",height:"70px",fontSize:"1.3rem",borderRadius:"24px",boxShadow:"0 15px 30px rgba(201, 168, 76, 0.3)"},children:[f?"SECURING ORDER...":"FINALIZE SHIPMENT"," ",l.jsx(hn,{size:24,style:{marginLeft:"10px"}})]}),l.jsxs("div",{style:{marginTop:"35px",display:"flex",alignItems:"center",gap:"12px",justifyContent:"center",opacity:.4,fontSize:"0.85rem",fontWeight:600},children:[l.jsx(Zt,{size:18})," END-TO-END ENCRYPTED TRANSACTION"]})]})]})]})})},q4=St`
  0% { transform: scale(0.8); opacity: 0; }
  100% { transform: scale(1); opacity: 1; }
`,Y4=St`
  0% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
  100% { transform: translateY(0); }
`,$4=C.div`
  padding: 140px 0 100px;
  text-align: center;
  min-height: 90vh;
  background: #f8f9fa;
  background-image: 
    radial-gradient(circle at 10% 20%, rgba(39, 174, 96, 0.03) 0%, transparent 50%),
    radial-gradient(circle at 90% 80%, rgba(201, 168, 76, 0.03) 0%, transparent 50%);
`,G4=C.div`
  max-width: 700px;
  margin: 0 auto;
  background: white;
  padding: 80px 50px;
  border-radius: 48px;
  box-shadow: 0 40px 100px rgba(0,0,0,0.06);
  position: relative;
  overflow: hidden;
  animation: ${q4} 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  
  &::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0; height: 8px;
    background: linear-gradient(90deg, #27ae60, #2ecc71);
  }
`,Q4=C.div`
  width: 120px;
  height: 120px;
  background: #f0fdf4;
  color: #27ae60;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 40px;
  animation: ${Y4} 3s ease-in-out infinite;
  box-shadow: 0 20px 40px rgba(39, 174, 96, 0.1);
`,V4=C.div`
  display: inline-flex;
  align-items: center;
  gap: 10px;
  background: #0b1a33;
  color: #C9A84C;
  padding: 10px 25px;
  border-radius: 100px;
  font-family: 'Courier New', Courier, monospace;
  font-weight: 900;
  font-size: 1.2rem;
  margin-bottom: 40px;
  box-shadow: 0 10px 20px rgba(11, 26, 51, 0.2);
`,X4=C.div`
  background: #fcfdfe;
  border: 2px dashed #e0e6ed;
  padding: 35px;
  border-radius: 32px;
  margin-bottom: 50px;
  text-align: left;
  
  h4 { 
    color: #0b1a33; 
    font-size: 1.2rem; 
    font-weight: 800; 
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 12px;
  }
  
  .step {
    display: flex;
    gap: 15px;
    margin-bottom: 15px;
    font-size: 0.95rem;
    color: #555;
    font-weight: 600;
    &:last-child { margin-bottom: 0; }
    span { color: #C9A84C; font-weight: 900; }
  }
`,K4=()=>{const{orderNumber:i}=xd();return l.jsx($4,{children:l.jsx(Qe,{children:l.jsxs(G4,{children:[l.jsx(Q4,{children:l.jsx(N2,{size:60,strokeWidth:3})}),l.jsxs("h1",{style:{fontSize:"3rem",fontWeight:900,color:"#0b1a33",marginBottom:"15px",letterSpacing:"-1px"},children:["Mission ",l.jsx("span",{style:{color:"#27ae60"},children:"Accomplished"})]}),l.jsx("p",{style:{color:"#666",fontSize:"1.2rem",marginBottom:"30px",fontWeight:500},children:"Your Smart Safety ecosystem has been successfully provisioned."}),l.jsxs(V4,{children:["#",i]}),l.jsxs(X4,{children:[l.jsxs("h4",{children:[l.jsx(sd,{size:24,color:"#C9A84C"})," Fulfillment Protocol"]}),l.jsxs("div",{className:"step",children:[l.jsx("span",{children:"01"})," Verification call from Jiyo India HQ within 4 hours."]}),l.jsxs("div",{className:"step",children:[l.jsx("span",{children:"02"})," QR Tag laser engraving and quality assurance."]}),l.jsxs("div",{className:"step",children:[l.jsx("span",{children:"03"})," Dispatch via priority secure logistics."]})]}),l.jsxs("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"20px"},children:[l.jsxs(qe,{as:Ze,to:"/",variant:"secondary",style:{height:"60px",borderRadius:"18px"},children:[l.jsx(bg,{size:20,style:{marginRight:"10px"}})," RETURN HOME"]}),l.jsxs(qe,{as:Ze,to:"/dashboard",style:{height:"60px",borderRadius:"18px",background:"#C9A84C",color:"#0b1a33"},children:["PROCEED TO DASHBOARD ",l.jsx(k5,{size:20,style:{marginLeft:"10px"}})]})]}),l.jsxs("div",{style:{marginTop:"50px",borderTop:"1px solid #eee",paddingTop:"30px",display:"flex",justifyContent:"center",gap:"30px",opacity:.5},children:[l.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"8px",fontSize:"0.8rem",fontWeight:700},children:[l.jsx(Zt,{size:16})," 100% SECURE"]}),l.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"8px",fontSize:"0.8rem",fontWeight:700},children:[l.jsx(wg,{size:16})," DOWNLOAD INVOICE"]})]})]})})})};function Z4(){return l.jsxs(t2,{theme:r2,children:[l.jsx(l2,{}),l.jsx(P5,{children:l.jsxs(Xb,{children:[l.jsx(w4,{}),l.jsxs(Sb,{children:[l.jsxs(dt,{path:"/",element:l.jsx(yj,{}),children:[l.jsx(dt,{index:!0,element:l.jsx(w3,{})}),l.jsx(dt,{path:"smart-qr",element:l.jsx(k3,{})}),l.jsx(dt,{path:"cloud-monitoring",element:l.jsx(U3,{})}),l.jsx(dt,{path:"gps-tracking",element:l.jsx($3,{})}),l.jsx(dt,{path:"social-initiative",element:l.jsx(K3,{})}),l.jsx(dt,{path:"category/:id",element:l.jsx(u4,{})}),l.jsx(dt,{path:"product/:id",element:l.jsx(S4,{})}),l.jsx(dt,{path:"cart",element:l.jsx(k4,{})}),l.jsx(dt,{path:"checkout",element:l.jsx(L4,{})}),l.jsx(dt,{path:"order-success/:orderNumber",element:l.jsx(K4,{})}),l.jsx(dt,{path:"login",element:l.jsx(P3,{})}),l.jsx(dt,{path:"signup",element:l.jsx(lS,{})})]}),l.jsx(dt,{path:"/dashboard",element:l.jsx(OS,{})}),l.jsx(dt,{path:"/admin/dashboard",element:l.jsx(vS,{})}),l.jsx(dt,{path:"/scan/:id",element:l.jsx(GS,{})})]})]})})]})}Sy.createRoot(document.getElementById("root")).render(l.jsx(A.StrictMode,{children:l.jsx(Z4,{})}));
